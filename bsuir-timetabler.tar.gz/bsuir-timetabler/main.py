#!/usr/bin/python
from os import *
import sys

system('rm *.xml *.html')
system('rm -r out')
system('mkdir out')

print 'Splitting tables'
for x in listdir('.'):
    if x.endswith('.xls'):
        print '*', x
        system('python split.py ' + x)
    
print ''    
print 'Building HTMLs'
for x in listdir('.'):
    if x.endswith('.xml'):
        print '*', x
        system('python html.py ' + x)

    
    
