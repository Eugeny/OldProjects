from lxml import etree
import sys
  

xslt = etree.XSLT(etree.parse('transform.xslt'))
xml = etree.parse(sys.argv[1])
open('out/'+sys.argv[1]+'.html', 'w').write(etree.tostring(xslt(xml), method="html"))
 
