#!/bin/bash
./clean.sh
python main.py
./clean.sh

