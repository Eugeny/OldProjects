from OpenGL.GLUT import *
from OpenGL.GLU import *
from OpenGL.GLX import *
from OpenGL.GL import *
import sys
import glut 
import pygame
import uielements
import time
import ui
import threading
import log

Slowdown = False #We're slowing GL down while playing video

def Init():
	log.info('GL', 'Initializing OpenGL')
	
	glEnable(GL_TEXTURE_2D)
	glEnable(GL_BLEND)
	
	glDisable(GL_DEPTH_TEST)
	glDisable(GL_CULL_FACE)
    
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
	
	glShadeModel(GL_FLAT)
	
	glMatrixMode(GL_PROJECTION)
	glLoadIdentity()
	glOrtho(-glut.HalfWidth, glut.HalfWidth, glut.HalfHeight, -glut.HalfHeight, -100000, 100000);
	return
	
def OnRender():
	global Slowdown

	glClear(GL_COLOR_BUFFER_BIT)
	if (not Slowdown): 
		ui.Update()
		ui.Render()
		time.sleep(.02)
		pygame.display.flip()
		TexQueueProcess()
	else:
		time.sleep(.3)
	return
	
	

class Texture(object):
	Handle = 0
	Width = 0
	Height = 0
	__file = ''
	
	def __init__(self, file):
		self.__file = file
		surface = pygame.image.load(file)
		data = pygame.image.tostring(surface, "RGBA", True)
		self.Handle = glGenTextures(1)
		self.Bind()
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
		self.Width, self.Height = surface.get_rect().size
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, self.Width, self.Height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
		self.Bind()
		return
		
	def GetFile(self):
		return self.__file
		
	def Bind(self):
		glBindTexture(GL_TEXTURE_2D, self.Handle)
		return


class Sprite(object):
	Texture = None
	Width = 0
	Height = 0
	Alpha = 0.0
	Angle = 0
	X = 0
	Y = 0
	
	def __init__(self, tex):
		self.Texture = tex
		self.Width = self.Texture.Width
		self.Height = self.Texture.Height
		return
		
	def Render(self):
		if (self.Alpha <= 0):
			return
		
		glMatrixMode(GL_MODELVIEW)
		glRotate(self.Angle, 0, 0, 1)
		glTranslate(self.X + self.Width / 2 - glut.HalfWidth, self.Y + self.Height / 2 - glut.HalfHeight, 0)
		gluLookAt(0,0,1,
				0,0,0,
				0,-1,0)
		
		self.Texture.Bind()
		glColor4f(1.,1.,1.,self.Alpha)
		
		glBegin(GL_QUADS)
		glTexCoord2f(0,0)
		glVertex2i(self.Width / 2, -self.Height / 2)
		glTexCoord2f(1,0)
		glVertex2i(-self.Width / 2, -self.Height / 2)
		glTexCoord2f(1,1)
		glVertex2i(-self.Width / 2, self.Height / 2)
		glTexCoord2f(0,1)
		glVertex2i(self.Width / 2, self.Height / 2)
		glEnd()
		return


#Syncronous texture loading queue mechanism
Tex = None
TexFile = ''
TexLock = threading.Lock()

def TexQueueProcess():
	global TexFile, Tex
	
	try:
		if (not TexFile == '' and Tex == None):
			log.info('TexQueue', 'Loading texture: ' + TexFile)
			Tex = Texture(TexFile)
	except:
		log.warn('TexQueue', 'Failed to load texture: ' + TexFile)
		import resources
		Tex = resources.Textures['black']	
	return
	
def TexQueueWaitReady():
	global Tex
	
	while (not Tex == None):
		time.sleep(0.1)
	return
	
def TexQueueWaitDone():
	global Tex

	while (Tex == None):
		time.sleep(0.1)
	return
	
def TexQueuePush(file):
	global TexLock, TexFile
	
	TexLock.acquire()
	TexQueueWaitReady()
	TexFile = file
	log.info('TexQueue', 'Added: ' + file)
	return
	
def TexQueuePop():
	global TexFile, Tex, TexLock
	
	TexQueueWaitDone()
	r = Tex
	TexFile = ''
	Tex = None
	TexLock.release()
	return r
	
