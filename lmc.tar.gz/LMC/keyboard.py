import ui

def HandleKey(code, uc):
	key = ''
	if (code == 65):
		key = 'space'
	if (code == 36):
		key = 'ok'
	if (code == 22):
		key = 'back'
	if (code == 38):
		key = 'a'
	if (code == 28):
		key = 'text'
	if (code == 113):
		key = 'left'
	if (code == 111):
		key = 'up'
	if (code == 114):
		key = 'right'
	if (code == 116):
		key = 'down'
		
	if (len(uc)==1 and uc!='\r' and uc!='\x08'): key = uc
	
	ui.HandleKey(key)
	return
