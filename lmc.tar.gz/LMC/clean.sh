#!/bin/sh
rm *.pyc
