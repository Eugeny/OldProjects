#!/usr/bin/python

import sys

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

import FTGL

fonts = None

  
def on_display():
    glClear(GL_COLOR_BUFFER_BIT)
    glMatrixMode(GL_PROJECTION)
    glOrtho(-300,300,-300,300, -100000.0, 100000.0)
    glColor4f(1.0, 1.0, 1.0, 0.5)
    glRasterPos(0,0)
    fonts.Render('asd')
    glutSwapBuffers()

if __name__ == '__main__':
    glutInitWindowSize(600, 600)
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_RGBA|GLUT_DOUBLE)
    glutCreateWindow("PyFTGL Demo")
    glClearColor(0.0, 0.0, 0.0, 0.0)

    fonts = FTGL.PixmapFont(sys.argv[1])
    fonts.FaceSize(24)
    
    
    glutDisplayFunc(on_display)
    
    glutMainLoop()
