from OpenGL.GL import *
import sys
import keyboard
import mouse
import gl
import pygame
import settings
import log

Width = 0
Height = 0
HalfWidth = 0
HalfHeight = 0


def CreateWindow():
	global Width, Height
	global HalfWidth, HalfHeight
	
	log.info('Window', 'Creating window')
	
	#May require forced size on older systems
	#Width = 1280
	#Height = 720
	
	pygame.init()
	s = pygame.display.set_mode((Width, Height),  pygame.HWSURFACE|pygame.NOFRAME|pygame.DOUBLEBUF|pygame.OPENGL)#pygame.FULLSCREEN|
	
	Width = s.get_width()
	Height = s.get_height()
	HalfWidth = Width / 2
	HalfHeight = Height / 2

	pygame.key.set_repeat(180, 60)
	return
	
def MainLoop():
	log.info('Window', 'Main loop started')
	
	while (True):
		gl.OnRender()
		for event in pygame.event.get():
			if event.type == pygame.KEYDOWN: 
				OnKeyPress(event.scancode, event.unicode)
				if (event.scancode == 9): sys.exit()
			if event.type == pygame.MOUSEBUTTONDOWN: 
				OnMousePress(event.button)
			if event.type == pygame.QUIT: 
				sys.exit()
	return
		
def OnKeyPress(code, uc):
	keyboard.HandleKey(code, uc)
	return

def OnMousePress(button):
	mouse.HandlePress(button)
	return

