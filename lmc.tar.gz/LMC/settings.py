from lang import *
import sys
import log

Folders = []
FolderCats = []

VideoExts = ['.AVI', '.MPG', '.MPEG', '.MP4', '.3GP', '.MKV', '.FLV', '.WMV']
AudioExts = ['.WAV', '.MP3', '.FLAC', '.OGG', '.AMR', '.WMA']
PhotoExts = ['.PNG', '.BMP', '.JPEG', '.JPG', '.GIF', '.RAW']

Language = 'en-US English'
Wallpaper = 'def.png'
Fetch = True
Skin = 'oxygen'
Iconset = 'oxygen'
Path = '/'
Logo = True

def ApplySetting(key, val):
	log.info('Settings', 'Configuring ' + key + ' = ' + val)
	
	if (key == 'lang'):
		global Language
		Language = val
		import lang
		LoadLang(Language)
	if (key == 'wallpaper'):
		global Wallpaper
		Wallpaper = val
	if (key == 'skin'):
		global Skin
		Skin = val
		import resources
		resources.LoadSkin(Skin)
	if (key == 'iconset'):
		global Iconset
		Iconset = val
		import resources
		resources.LoadIconset(Iconset)
	if (key == 'fetch'):
		global Fetch
		Fetch = __tobool(val)
	if (key == 'logo'):
		global Logo
		Logo = __tobool(val)
	if (key == 'folders'):
		global Folders, FolderCats
		s = val.split(';')
		for i in range(len(s)/2):
			if (s[i*2]!=''):
				Folders.append(s[i*2])
				FolderCats.append(s[i*2+1])
	return
	
def __frombool(b):
	if (b): return 1
	return 0
	
def __tobool(i):
	return (i=='1')
	
def Save():
	global Path, Language, Folders, FolderCats

	log.info('Settings', 'Saving configuration')
	
	f = open(Path + 'lmc.conf', 'w')
	
	f.write('%s = %s\n' % ('lang', Language))
	f.write('%s = %s\n' % ('wallpaper', Wallpaper))
	f.write('%s = %s\n' % ('fetch', __frombool(Fetch)))
	f.write('%s = %s\n' % ('skin', Skin))
	f.write('%s = %s\n' % ('iconset', Iconset))
	
	fldrs = ''

	for x in range(len(Folders)):
		fldrs += Folders[x] + ';' + FolderCats[x] + ';'
		
	f.write('%s = %s\n' % ('folders', fldrs))
	
	f.close()
	return
	
def Load():
	global Path
	
	log.info('Settings', 'Loading configuration')

	Path = sys.path[0] + '/'
	
	f = open(Path + 'lmc.conf')
	s = f.readlines()
	f.close()
	
	i = 0
	while (i < len(s)):
		if ('=' in s[i]):
			try:
				k,v = s[i].split('=')
				v = v.strip()
				k = k.strip()
				ApplySetting(k,v)
			except:
				log.warn('Settings', 'Couldn\'t apply setting: ' + k + ' = ' + v)
		i += 1
	
	return
