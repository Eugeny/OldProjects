import os
import util
import audio
import uicustom
import resources
import ui
import random
import log

Files = []
Current = 0

def Clear():
	Files = []
	Current = 0
	ui.Screens['Playlist'].List.Clear()
	return
	
def LoadFolder(f):
	global Files, Current
	
	log.info('Playlist', 'Loading folder: ' + f)

	ss = os.listdir(f)
	Clear()
		
	for s in ss:
		if (util.GetFileType(s) == 'Audio'):
			Add(f,s)
	return
	
def Add(f,s):
	Files.append([util.FixPath(f + '/' + s), s])
	ui.Screens['Playlist'].List.AddItem(s, resources.Textures['file_audio'])
	return
	
def JumpToFile(n):
	global Files

	for i in range(0, len(Files)):
		if Files[i][0]==n:
			JumpTo(i)
	return
	
def JumpTo(i):
	global Files, Current
	
	log.info('Playlist', 'Jumping to: ' + Files[i][0])

	Current = i
	audio.Stop()
	audio.OpenFile(Files[i][0])
	return
	
def Shuffle():
	global Files

	log.info('Playlist', 'Shuffling')

	random.shuffle(Files)
	ui.Screens['Playlist'].List.Clear()
	for x in Files:
		ui.Screens['Playlist'].List.AddItem(x[1], resources.Textures['file_audio'])
	return
	
def Next():
	global Current, Files
	
	log.info('Playlist', 'Next track')

	Current += 1
	
	if (Current == len(Files)):
		Current = 0
		Shuffle() #TODO: make swichable
		
	JumpTo(Current)
	return
		
def Prev():
	global Current, Files
	
	log.info('Playlist', 'Previous track')

	Current -= 1
	
	if (Current == -1):
		Current = len(Files) - 1
		Shuffle() #TODO: make swichable
	
	JumpTo(Current)
	return	
	
