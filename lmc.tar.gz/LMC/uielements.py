import FTGL
from OpenGL.GL import *
from OpenGL.GLU import *
import glut 
import gl
import ui
import resources
from lang import *

class Element(object):
	Obsolete = False
	Visible = True
	Removing = False
	Alpha = 1.
	_Alpha = 0.
	MaxAlpha = 1
	
	def Render(self):
		return
		
	def Update(self):
		if (self.Alpha > 1.):
			self.Alpha = 1.
		if (self._Alpha >= 0.96):
			self._Alpha = 1.
		
		ta = self.Alpha
		if (ta > self.MaxAlpha):
			ta = self.MaxAlpha
			
		if (not self.Visible):
			ta = 0
		if (abs(ta - self._Alpha)<0.06):
			self._Alpha = ta
			
		a = self._Alpha
		if (a > ta):
			self._Alpha -= 0.06
		if (a < ta):
			self._Alpha += 0.06
		if (self.Removing and self._Alpha <= 0):
			self.Obsolete = True
		return
		
	def HandleKey(self, code):
		return
		
	def __str__(self):
		return 'Element'
	
	
class Container(Element):
	Elements = []
	
	def __init__(self):
		self.Elements = []
		return
		
	def __str__(self):
		return 'Container (' + str(len(self.Elements)) + ' elements)'

	def Clear(self):
		self.Elements = []
		return
		
	def AddElement(self, e):
		self.Elements.append(e)
		return
		
	def RemoveElement(self, e):
		e.Removing = True
		e.Visible = False
		return
		
	def RemoveElementNow(self, e):
		self.Elements.remove(e)
		return
		
	def Render(self):
		if (self._Alpha == 0): return
		
		for e in self.Elements:
			if (e._Alpha > 0):
				e.Render()
			
		return
		
	def HandleKey(self, code):
		if (not self.Visible):
			return False
		
		for e in self.Elements:
			if (e.Visible and e.HandleKey(code)):
				return True
			
		return False
		
	def Update(self):
		Element.Update(self)
		
		if (self._Alpha == 0): return
		
		for e in self.Elements:
			if (e.Visible and self._Alpha > 0):
				e.Alpha = self._Alpha
				
			if (e.Visible or e.Alpha>0):
				e.Update()
			if (e.Obsolete):
				e.Obsolete = False
				self.Elements.remove(e)
		
		return
		

class Label(Element):
	Text = ''
	X = 0    
	Y = 0
	Width = 0
	Height = 0
	Font = None
	Align = 0
	VAlign = 0
	__size = 0
	R = 1.
	G = 1.
	B = 1.
	
	def __str__(self):
		return 'Label (' + self.Text + ')'

	def __init__(self):	
		self.Font = ui.Font
		self.SetSize(24)
		return
	
	def SetSize(self, size):
		self.Font = ui.Fonts[size]
		self.__size = size
		self.Height = int(self.Font.line_height)
		return
		
	def Render(self):
		if (self.Text == ''): return
		
		glMatrixMode(GL_MODELVIEW)
		glLoadIdentity()
		dx = 0
		if (self.Align == 1):
			dx = self.Font.Advance(self.Text) / 2
		if (self.Align == 2):
			dx = self.Font.Advance(self.Text)
		dy = 0
		if (self.VAlign == 1):
			dy = self.Height / 4
		if (self.VAlign == 2):
			dy = self.Height / 2
		
		glColor4f(self.R, self.G, self.B, self._Alpha)
		glMatrixMode(GL_MODELVIEW)
		glTranslate(self.X - glut.HalfWidth - dx, self.Y + self.Height / 2 - glut.HalfHeight - dy, 0)
		gluLookAt(0,0,-1,
				0,0,0,
				0,-1,0)
		
		self.Font.Render(self.Text)
		return
	
	def ForceAlpha(self, a):
		self.Alpha = a
		self.__Alpha = a
		return
		
	def Update(self):
		Element.Update(self)
		if (self.Text != ''):
			self.Width = int(self.Font.Advance(self.Text))
		return
		

class Image(Element):
	X = 0    
	Y = 0
	Width = 100
	Height = 100
	Texture = None
	Align = 0
	VAlign = 0
	Sprite = None
	Angle = 0.0
	__Shadow = None
	Shadow = False
	
	def __str__(self):
		return 'Image (' + self.Texture.GetFile() + ')'

	def __init__(self):	
		self.__Shadow = None
		return
	
	def SetFullscreen(self):
		self.Width = glut.Width
		self.Height = glut.Height
		self.X = 0
		self.Y = 0
		return
		
	def SetTexture(self, tex):
		self.Width = tex.Width
		self.Height = tex.Height
		self.Texture = tex
		self.Sprite = gl.Sprite(tex)
		return
		
	def Scale(self, sx, sy):
		self.Width = int(self.Texture.Width * sx)
		self.Height = int(self.Texture.Height * sy)
		return
	
	def ScaleBy(self, ox, oy, sx, sy):
		self.Width = int(ox * sx)
		self.Height = int(oy * sy)
		return
	
	def Render(self):
		glMatrixMode(GL_MODELVIEW)
		glLoadIdentity()
		dx = 0
		if (self.Align == 1):
			dx = self.Width / 2
		if (self.Align == 2):
			dx = self.Width
		dy = 0
		if (self.VAlign == 1):
			dy = self.Height / 2
		if (self.VAlign == 2):
			dy = self.Height
		
		self.Sprite.X = self.X - dx
		self.Sprite.Y = self.Y - dy
		self.Sprite.Width = self.Width
		self.Sprite.Height = self.Height
		
		self.Sprite.Render()
		
		if (self.Shadow):
			self.__Shadow.Render()
		return
	
	def ForceAlpha(self, a):
		self.Alpha = a
		self._Alpha = a
		return
		
	def Update(self):
		Element.Update(self)
		
		self.Sprite.Angle = self.Angle
		self.Sprite.Alpha = self._Alpha
		
		if (self.Shadow):
			if (self.__Shadow == None):
				self.__Shadow = Image()
				self.__Shadow.SetTexture(resources.Textures['shadow'])
		
			self.__Shadow.Alpha = self.Alpha
			self.__Shadow._Alpha = self._Alpha
			self.__Shadow.Visible = self.Visible
			self.__Shadow.Update()
			
			self.__Shadow.Width = int(10.0 * self.Width / 9) - 1
			self.__Shadow.Height = int(10.0 * self.Height / 9) - 1
			dx = 0
			if (self.Align == 1):
				dx = self.Width / 2
			if (self.Align == 2):
				dx = self.Width
			dy = 0
			if (self.VAlign == 1):
				dy = self.Height / 2
			if (self.VAlign == 2):
				dy = self.Height
			
			self.__Shadow.X = self.X - dx + self.Width / 2
			self.__Shadow.Y = self.Y - dy + self.Height / 2 
			self.__Shadow.Angle = self.Angle
			self.__Shadow.Align = 1
			self.__Shadow.VAlign = 1
		return


class List(Container):
	__labels = []
	__icons = []
	Selected = 0
	__dx = 0
	__hl = None
	__dy = 0
	Scroll = 0
	Items = []
	
	def __init__(self):
		self.Elements = []
		
		h = Image()
		h.SetTexture(resources.Textures['file_hl'])
		h.Width = glut.Width - 400
		h.X = 295
		h.VAlign = 1
		self.__hl = h
		
		self.AddElement(h)
		
		self.__labels = []
		self.__icons = []
		self.Clear()
		return

	
	def Clear(self):
		for e in self.__labels:
			self.RemoveElement(e)
		for e in self.__icons:
			self.RemoveElement(e)
			
		self.Items = []
		self.__labels = []
		self.__icons = []
		self.Selected = 0
		self.__dy = 0
		self.Scroll = 0
		self.__dx = 0
	
	def SetText(self, idx, text):
		self.__labels[idx].Text = text
		return
		
	def AddItem(self, name, tex):
		l = Label()
		l.Text = name
		l.X = 300
		l.SetSize(18)
		l.VAlign = 1
		self.__labels.append(l)
		self.AddElement(l)
				
		p = Image()
		p.SetTexture(tex)
		p.X = 260
		p.Width = 32
		p.Height = 32
		p.VAlign = 1
		self.__icons.append(p)
		self.AddElement(p)
		
		self.Items.append(name)
		
		return
		
	def Update(self):
		Container.Update(self)
		Container.Update(self)
		Container.Update(self)
		
		dxt = self.Selected * 32
		if (self.__dx < dxt):
			self.__dx += 5
		if (self.__dx > dxt):
			self.__dx -= 5
		if (self.__dx < dxt - 20):
			self.__dx += 5
		if (self.__dx > dxt + 20):
			self.__dx -= 5
		if (self.__dx < dxt - 40):
			self.__dx += 15
		if (self.__dx > dxt + 40):
			self.__dx -= 15
			
		dyt = self.Scroll * 32
		if (self.__dy < dyt):
			self.__dy += 5
		if (self.__dy > dyt):
			self.__dy -= 5
		if (self.__dy < dyt - 20):
			self.__dy += 10
		if (self.__dy > dyt + 20):
			self.__dy -= 10
		if (self.__dy < dyt - 40):
			self.__dy += 15
		if (self.__dy > dyt + 40):
			self.__dy -= 15
		
		self.__hl.Y = 100 + self.__dx - self.__dy
		
		for i in range(0, len(self.__labels)):
			self.__labels[i].Visible = False
			self.__labels[i].Y = 100 + i * 32 - self.__dy
			
		for i in range(self.Scroll, min(len(self.__labels), self.Scroll + (glut.Height - 150) / 32 + 1)):
			self.__labels[i].Visible = True
			
		for i in range(0, len(self.__labels)):
			self.__icons[i].Visible = False
			self.__icons[i].Y = 100 + i * 32 - self.__dy
		
		for i in range(self.Scroll, min(len(self.__labels), self.Scroll + (glut.Height - 150) / 32 + 1)):
			self.__icons[i].Visible = True
		
		return
		
	
	def HandleKey(self, code):
		if (Container.HandleKey(self, code)):
			return True
		
		if (code == 'up' and self.Selected > 0):
			self.Selected -= 1
			if (self.Scroll + 5 > self.Selected and self.Scroll > 0):
				self.Scroll -= 1
			return True
			
		if (code == 'down' and self.Selected < len(self.__labels) - 1):
			self.Selected += 1
			if (self.Scroll + (glut.Height - 150) / 32 - 5 < self.Selected and self.Scroll + (glut.Height - 150) / 32 < len(self.__labels) - 1):
				self.Scroll += 1
			return True

		return False
	
