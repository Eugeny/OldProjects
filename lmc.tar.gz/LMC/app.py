from OpenGL.GLUT import *
import glut 
import gl
import ui
import resources
import settings
import video
import audio
import lang
import log
import mouse

Version = 'Alpha 3'
Origin = 'Original'

class LMC:
	def __init__(self):
		global Version, Origin
		log.info('Application', 'Linux Media Center ' + Version + ' '+ Origin)
		
		glut.CreateWindow()
		gl.Init()
		settings.Load()
		resources.LoadCommon()
		video.Init()
		ui.Init()
		audio.Init()
		mouse.Init()
		
		glut.MainLoop()
		return
