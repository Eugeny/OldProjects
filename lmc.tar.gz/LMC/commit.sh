#!/bin/bash
git add -u .
git commit
git push origin master

