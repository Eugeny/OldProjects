import ui
import uielements
import uispecial
import os
import util
import playlist
import audio
import video
import resources
import glut
import math
import settings
from lang import *

class MainMenu(uielements.Container):
	__ring = None
	
	def __init__(self):
		self.Elements = []
		
		r = uispecial.Ring()
		r.AddItem('icon_walls',lang('appearance'))
		r.AddItem('icon_files',lang('browse'))
		r.AddItem('icon_options',lang('configure'))
		self.__ring = r
		
		m = uispecial.MenuName()
		m.TextBig = lang('mainmenu')
		m.TextSmall = lang('appname')
		
		self.AddElement(r)
		self.AddElement(m)
		
		self.__ring.SetSelected(1)
		return

	def HandleKey(self, code):
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		if (code == 'ok'):
			if (self.__ring.Selected == 0):
				ui.SetScreen(ui.Screens['AppearanceMenu'])
				return True
			if (self.__ring.Selected == 1):
				ui.SetScreen(ui.Screens['MovieBrowser'])
				return True
			if (self.__ring.Selected == 2):
				ui.SetScreen(ui.Screens['Settings'])
				return True

		return False



class WallpaperBrowser(uielements.Container):
	__ring = None
	__sl = 0
	
	def __init__(self):
		self.Elements = []
		
		r = uispecial.PhotoBrowser()
		self.__ring = r
		self.__ring.Navigate(settings.Path + 'wallpapers')
		
		m = uispecial.MenuName()
		m.TextBig = lang('appearance')
		m.TextSmall = '< ' + lang('mainmenu')
		
		self.AddElement(m)
		self.AddElement(r)
		return

	def Update(self):
		uielements.Container.Update(self)
		if (self.__sl != self.__ring.Selected):
			ui.SwitchBackground(self.__ring.Icons[self.__ring.Selected].Texture)
			self.__sl = self.__ring.Selected
		return
		
	def HandleKey(self, code):
		if (code == 'ok'):
			settings.ApplySetting('wallpaper', self.__ring.Files[self.__ring.Selected])
			settings.Save()
			ui.GoBack()
			return True
				
		if (code == 'back'):
			settings.ApplySetting('wallpaper', self.__ring.Files[self.__ring.Selected])
			settings.Save()
			ui.GoBack()
			return True
		
		if (uielements.Container.HandleKey(self, code)):
			return True

		return False


class FileBrowser(uielements.Container):
	__fb = None
	
	def __init__(self, text):
		self.Elements = []
		
		f = uispecial.FileBrowser(text)
		self.__fb = f
		
		self.AddElement(f)
		return
		
	def Navigate(self, s):
		self.__fb.Navigate(s)
		return
		
	def HandleKey(self, code):
		if (code == 'back' and self.__fb.Root == ''):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			if (self.__fb.SelectedFile != '' and not os.path.isdir(self.__fb.SelectedFile) and util.GetFileType(self.__fb.SelectedFile) == 'Video'):
				video.OpenFile(self.__fb.SelectedFile)
				return True

			if (self.__fb.SelectedFile != '' and not os.path.isdir(self.__fb.SelectedFile) and util.GetFileType(self.__fb.SelectedFile) == 'Audio'):
				audio.Show()
				playlist.LoadFolder(self.__fb.Root + '/' + self.__fb.Path)
				playlist.JumpToFile(self.__fb.SelectedFile)
				return True

			if (self.__fb.SelectedFile != '' and not os.path.isdir(self.__fb.SelectedFile) and util.GetFileType(self.__fb.SelectedFile) == 'Image'):
				ui.SetScreen(ui.Screens['PhotoBrowser'])
				ui.Screens['PhotoBrowser'].Navigate(self.__fb.Root + self.__fb.Path, self.__fb.SelectedFile)
				return True
				
		if (uielements.Container.HandleKey(self, code)):
			 return True
		
		return False
		
class PhotoBrowser(uielements.Container):
	__ring = None
	__sl = 0
	
	def __init__(self):
		self.Elements = []
		
		r = uispecial.PhotoBrowser()
		self.__ring = r
		self.__ring.Navigate(settings.Path + 'wallpapers')
		
		m = uispecial.MenuName()
		m.TextBig = lang('slideshow')
		m.TextSmall = '< ' + lang('browser')
		
		self.AddElement(m)
		self.AddElement(r)
		return

	def Navigate(self, folder, file):
		self.__ring.Navigate(folder)
		
		for i in range(0, len(self.__ring.Files)):
			if (util.FixPath(self.__ring.Folder + '/' + self.__ring.Files[i]) == file):
				self.__ring.SetSelected(i)
		return
		
	def Update(self):
		uielements.Container.Update(self)
		return
		
	def HandleKey(self, code):
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		if (code == 'back'):
			ui.GoBack()
			return True
		
		return False

class AudioPlayer(uielements.Container):
	Bands = []
	Bands2 = []
	th = []
	Title = None
	Artist = None
	Cover = None
	PbrBg = None
	Pbr = None
	
	def __init__(self):
		self.Elements = []
		self.Bands = []
		self.Bands2 = []
		self.th = [0] * 20
		
		for i in range(0,20):
			x = uielements.Image()
			x.VAlign = 2
			x.SetTexture(resources.Textures['spectrum'])
			x.Width = 25
			x.X = glut.HalfWidth - 280 + i * 30
			x.Y = glut.HalfHeight + 100
			self.AddElement(x)
			self.Bands.append(x)
			x = uielements.Image()
			x.SetTexture(resources.Textures['spectrum2'])
			x.Width = 25
			x.X = glut.HalfWidth - 280 + i * 30
			x.Y = glut.HalfHeight + 101
			self.AddElement(x)
			self.Bands2.append(x)
			
		self.Title = uielements.Label()
		self.Title.SetSize(48)
		self.Title.X = glut.HalfWidth - 290
		self.Title.Y = glut.HalfHeight - 160
		self.Artist = uielements.Label()
		self.Artist.SetSize(24)
		self.Artist.X = glut.HalfWidth - 290
		self.Artist.Y = glut.HalfHeight - 110
	
		self.Cover = uielements.Image()
		self.Cover.X = glut.HalfWidth - 520
		self.Cover.Y = glut.HalfHeight - 160
		self.Cover.Shadow = True
		self.Cover.SetTexture(resources.Textures['cover'])
		m = uispecial.MenuName()
		m.TextBig = lang('music')
		m.TextSmall = '< ' + lang('goback')
		
		k = uispecial.KeyBar()
		k.AddKey('left', lang('prevtrack'))
		k.AddKey('ok', lang('pause'))
		k.AddKey('a', lang('playlist'))
		k.AddKey('back', lang('goback'))
		k.AddKey('right', lang('nexttrack'))
		
		self.AddElement(k)
		self.AddElement(m)
		
		self.Pbr = uielements.Image()
		self.Pbr.SetTexture(resources.Textures['progress'])
		self.Pbr.X = glut.HalfWidth - 290
		self.Pbr.Y =  glut.HalfHeight - 80
		self.Pbr.Width = 350
		
		self.PbrBg = uielements.Image()
		self.PbrBg.SetTexture(resources.Textures['progressbg'])
		self.PbrBg.X = glut.HalfWidth - 290
		self.PbrBg.Y = glut.HalfHeight - 80
		self.PbrBg.Width = 650
		
		self.AddElement(self.Artist)
		self.AddElement(self.Title)
		self.AddElement(self.Cover)
		self.AddElement(self.PbrBg)
		self.AddElement(self.Pbr)
		return

	def HandleKey(self, code):
		if (uielements.Container.HandleKey(self, code)):
			return True
	
		if (audio.HandleKey(code)):
			return True
	
		return False

	def Set(self, levels):
		for i in range(0,20):
			self.th[i] = int((math.sqrt(60)-math.sqrt(-levels[i]))*30) + 4
		for i in range(0,20):
			if (self.Bands[i].Height > self.th[i]): self.Bands[i].Height -= 2
			if (self.Bands[i].Height < self.th[i]): self.Bands[i].Height += 10;#self.th[i]
			if (abs(self.Bands[i].Height - self.th[i])<10): self.Bands[i].Height = self.th[i]
			self.Bands2[i].Height = self.Bands[i].Height
		return


class Playlist(uielements.Container):
	List = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('playlist')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewtracks'))
		k.AddKey('ok', lang('play'))
		k.AddKey('back', lang('backtoplayer'))
		
		self.AddElement(k)
		return
		
	def HandleKey(self, code):
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			playlist.JumpTo(self.List.Selected)
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False
		
class Settings(uielements.Container):
	List = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('configure')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewitems'))
		k.AddKey('ok', lang('select'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(k)
		
		f.AddItem(lang('locale'), resources.Textures['locale'])
		f.AddItem(lang('contentfetching'), resources.Textures['internet'])
		f.AddItem(lang('folders'), resources.Textures['folder_files'])
		self.HandleKey('')
		return
		
	def Upd(self):
		if (settings.Fetch):
			self.List.SetText(1, lang('contentfetching') + ': ' + lang('on'))
		else:
			self.List.SetText(1, lang('contentfetching') + ': ' + lang('off'))
		return
		
	def HandleKey(self, code):
		self.Upd()
		
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			if (self.List.Selected == 0):
				ui.SetScreen(ui.Screens['LocaleChooser'])
				
			if (self.List.Selected == 1):
				settings.Fetch = not settings.Fetch
				settings.Save()
				
			if (self.List.Selected == 2):
				ui.SetScreen(ui.Screens['FoldersEditor'])
			
			self.Upd()
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False
		
		
class LocaleChooser(uielements.Container):
	List = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('configure')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewitems'))
		k.AddKey('ok', lang('select'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(k)
		
		for x in os.listdir(settings.Path + 'lang/'):
			n, e = os.path.splitext(os.path.split(x)[1])
			if (e=='.lang'):
				f.AddItem(n, resources.Textures['locale'])
		
		return
		
	def HandleKey(self, code):
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			ui.GoBack()
			import settings
			settings.ApplySetting('lang', self.List.Items[self.List.Selected])
			settings.Save()
			ui.ShowMessage(lang('needrestart'))
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False
		
class AppearanceMenu(uielements.Container):
	List = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('configure')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewitems'))
		k.AddKey('ok', lang('select'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(k)
		
		f.AddItem(lang('wallpapers'), resources.Textures['icon_walls'])
		f.AddItem(lang('skins'), resources.Textures['icon_walls'])
		f.AddItem(lang('iconsets'), resources.Textures['icon_walls'])
		self.HandleKey('')
		return
		
	def Upd(self):
		return
		
	def HandleKey(self, code):
		self.Upd()
		
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			if (self.List.Selected == 0):
				ui.SetScreen(ui.Screens['WallpaperBrowser'])
				
			if (self.List.Selected == 1):
				ui.SetScreen(ui.Screens['SkinBrowser'])
				
			if (self.List.Selected == 2):
				ui.SetScreen(ui.Screens['IconBrowser'])
				
			self.Upd()
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False
		
		
class Logo(uielements.Container):
	__ring = None
	imgs = []
	t = -50
	ss = []
	
	def __init__(self):
		self.Elements = []
		self.imgs = []
		
		for i in range(2):
			img = uielements.Image()
			img.Align = 1
			img.VAlign = 1
			img.X = glut.HalfWidth
			img.Y = glut.HalfHeight
			img.MaxAlpha = 0
			img.SetTexture(resources.Textures['logo_'+str(i)])
			self.imgs.append(img)
			self.ss.append(0.0)
			self.AddElement(img)
			
		return

	def Update(self):
		if (not self.Visible): return
		d = [0, 50]
		ui.Loader.Visible = False
		
		
		uielements.Container.Update(self)
		self.t += 1
		if (self.t < 0): return
		
		for i in range(2):
			if (self.t > d[i]):
				self.imgs[i].MaxAlpha = 1.0 * (self.t - d[i]) / 100.0
				self.imgs[i].Alpha = self.imgs[i].MaxAlpha
				s = min(1.0, 1.0 * (self.t - d[i]) / 10.0)
				if (self.ss[i] < s): self.ss[i] += 0.2
				if (self.ss[i] < s-0.2): self.ss[i] += 0.2
				if (self.ss[i] > s-0.09)and(self.ss[i] != 1): self.ss[i] = s
				
		if (self.t==150):
			self.imgs[0].Visible = False
			self.imgs[1].Visible = False
			
		if (self.t==200):
			ui.SetScreen(ui.Screens['MainMenu'])
			ui.Background.Visible = True
			ui.OldBackground.Visible = True
			
		return
	

class SkinBrowser(uielements.Container):
	List = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('skins')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewitems'))
		k.AddKey('ok', lang('select'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(k)
		
		for x in os.listdir(settings.Path + 'skins/'):
			f.AddItem(x, resources.Textures['icon_walls'])
			
		return
		
	def HandleKey(self, code):
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			ui.GoBack()
			import settings
			settings.ApplySetting('skin', self.List.Items[self.List.Selected])
			settings.Save()
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False
		
class IconBrowser(uielements.Container):
	List = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('iconsets')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewitems'))
		k.AddKey('ok', lang('select'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(k)
		
		for x in os.listdir(settings.Path + 'icons/'):
			f.AddItem(x, resources.Textures['icon_walls'])
			
		return
		
	def HandleKey(self, code):
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			ui.GoBack()
			import settings
			settings.ApplySetting('iconset', self.List.Items[self.List.Selected])
			settings.Save()
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False
		
class FoldersEditor(uielements.Container):
	List = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('folders')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewitems'))
		k.AddKey('ok', lang('edit'))
		k.AddKey('a', lang('add'))
		k.AddKey('b', lang('changeicon'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(k)
		
		self.Reload()	
		return
		
	def Reload(self):
		t = self.List.Selected
		self.List.Clear()
		for x in range(len(settings.Folders)):
			self.List.AddItem(settings.Folders[x], resources.Textures['folder_' + settings.FolderCats[x]])
			
		self.List.Selected = min(len(self.List.Items)-1, t)
		return
		
		
	def HandleKey(self, code):
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'a'):
			settings.Folders.append('/')
			settings.FolderCats.append('files')
			self.List.Selected = len(settings.Folders) - 1
			self.on_edit()
			return True
			
		if (code == 'b'):
			t = ['video', 'photo', 'audio', 'files']
			settings.FolderCats[self.List.Selected] = t[(t.index(settings.FolderCats[self.List.Selected])+1) % len(t)] 
			self.Reload()
			ui.Screens['MovieBrowser'].Navigate('/')
			settings.Save()
			return True
		
		if (code == 'ok'):
			ui.Screens['ItemContext'].Visible = True
			ui.Screens['ItemContext'].CbDelete = self.on_delete
			ui.Screens['ItemContext'].CbEdit = self.on_edit
			ui.Screens['ItemContext'].CbUp = self.on_up
			ui.Screens['ItemContext'].CbDown = self.on_down
			ui.SetScreen(ui.Screens['ItemContext'])
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False
		
	def on_edit(self):
		ui.ShowInput(lang('path'), settings.Folders[self.List.Selected], self.on_editdone)
		return
		
	def on_editdone(self, s):
		settings.Folders[self.List.Selected] = s
		self.Reload()
		ui.Screens['MovieBrowser'].Navigate('/')
		settings.Save()
		return
		
	def on_up(self):
		if (self.List.Selected == 0): return
		settings.Folders[self.List.Selected], settings.Folders[self.List.Selected-1] = settings.Folders[self.List.Selected-1], settings.Folders[self.List.Selected]
			
		self.Reload()
		ui.Screens['MovieBrowser'].Navigate('/')
		settings.Save()
		return
	
	def on_down(self):
		if (self.List.Selected == len(settings.Folders)-1): return
		settings.Folders[self.List.Selected], settings.Folders[self.List.Selected+1] = settings.Folders[self.List.Selected+1], settings.Folders[self.List.Selected]
			
		self.Reload()
		ui.Screens['MovieBrowser'].Navigate('/')
		settings.Save()
		return
	
	def on_delete(self):
		if (len(settings.Folders) == 1):
			ui.ShowMessage(lang('cantdelall'))
			return
		settings.Folders.remove(settings.Folders[self.List.Selected])
		settings.FolderCats.remove(settings.FolderCats[self.List.Selected])
		self.Reload()
		ui.Screens['MovieBrowser'].Navigate('/')
		settings.Save()
		return
		
class ItemContext(uielements.Container):
	List = None
	CbEdit = None
	CbUp = None
	CbDown = None
	CbDelete = None
	
	def __init__(self):
		self.Elements = []
		
		m = uispecial.MenuName()
		m.TextBig = lang('folders')
		m.TextSmall = '< ' + lang('goback')
		
		f = uielements.List()
		self.List = f
		
		self.AddElement(f)
		self.AddElement(m)
		
		k = uispecial.KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewitems'))
		k.AddKey('ok', lang('edit'))
		k.AddKey('a', lang('add'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(k)
		
		f.AddItem(lang('edit'), resources.Textures['item_edit'])
		f.AddItem(lang('up'), resources.Textures['item_up'])
		f.AddItem(lang('down'), resources.Textures['item_down'])
		f.AddItem(lang('delete'), resources.Textures['item_delete'])
			
		return
		
	def HandleKey(self, code):
		if (code == 'back'):
			ui.GoBack()
			return True
		
		if (code == 'ok'):
			ui.GoBack()
			if (self.List.Selected == 0):
				self.CbEdit()
			if (self.List.Selected == 1):
				self.CbUp()
			if (self.List.Selected == 2):
				self.CbDown()
			if (self.List.Selected == 3):
				self.CbDelete()
				
			return True
				
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		return False

