import settings
import log

dict = {}

def lang(index):
	global dict
	if (dict.has_key(index)):
		return dict[index]
	return '[%s]' % index

def LoadLang(name):
	global dict
	dict = {}
	
	log.info('Language', 'Loading: ' + name)
	f = open(settings.Path + 'lang/' + name + '.lang')
	s = f.readlines()
	f.close()
	
	for i in range(0,len(s)/2):
		k = s[i*2]
		k = k[0:len(k)-1]
		v = s[i*2+1]
		v = v[0:len(v)-1]
		dict[k] = v
	
	return
	
