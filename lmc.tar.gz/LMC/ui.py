import uielements
import uispecial
import uicustom
import glut 
import gl
import resources
import FTGL
import video
import settings
import log
from lang import *

UIRoot = None
ActiveLayer = None
CurrentScreen = None
LastScreen = None
Loader = None
TopBar = None

Background = None
OldBackground = None

Screens = {}

Font = None
Fonts = {}

ScreenStack = []

def Init():
	global UIRoot, ActiveLayer, CurrentScreen, Loader, OldBackground, TopBar
	
	log.info('UI', 'Initializing')
	
	UIRoot = uielements.Container()
	ActiveLayer = uielements.Container()
	
	InitFonts()
	InitScreens()
	
	UIRoot.AddElement(OldBackground)
	UIRoot.AddElement(Background)
	UIRoot.AddElement(TopBar)
	UIRoot.AddElement(ActiveLayer)
	UIRoot.AddElement(Loader)
	
	if (settings.Logo):
		global Logo
		CurrentScreen = Screens['Logo']
		SetScreen(Screens['Logo'])
	else:
		global MainMenu
		CurrentScreen = Screens['MainMenu']
		SetScreen(Screens['MainMenu'])
	return
	
def InitFonts():
	global Fonts
	
	log.info('UI', 'Loading fonts')

	s = [12, 14, 16, 18, 24, 48]
	for i in s:
		Fonts[i] = FTGL.TextureFont(settings.Path + 'FreeSans.ttf')
		Fonts[i].FaceSize(i)
	return
		
def InitScreens():
	global Screens, Background, OldBackground, Loader, TopBar, Message, ActiveLayer
	
	log.info('UI', 'Creating screens')

	Background = uielements.Image()
	Background.SetTexture(resources.Textures['bg'])
	Background.SetFullscreen()
	OldBackground = uielements.Image()
	OldBackground.SetTexture(resources.Textures['bg'])
	OldBackground.SetFullscreen()
	
	if (settings.Logo):
		Background.Visible = False
		OldBackground.Visible = False
	
	TopBar = uispecial.StatusBar()
	
	Loader = uielements.Image()
	Loader.SetTexture(resources.Textures['loader'])
	Loader.Visible = False
	Loader.X = glut.HalfWidth
	Loader.Y = glut.HalfHeight
	Loader.Align = 1
	Loader.VAlign = 1
	
	Screens['MainMenu'] = uicustom.MainMenu()
	Screens['WallpaperBrowser'] = uicustom.WallpaperBrowser()
	Screens['MovieBrowser'] = uicustom.FileBrowser(lang('media'))
	Screens['PhotoBrowser'] = uicustom.PhotoBrowser()
	Screens['AudioPlayer'] = uicustom.AudioPlayer()
	Screens['Playlist'] = uicustom.Playlist()
	Screens['Settings'] = uicustom.Settings()
	Screens['LocaleChooser'] = uicustom.LocaleChooser()
	Screens['Message'] = uispecial.Message()
	Screens['Input'] = uispecial.Input()
	Screens['AppearanceMenu'] = uicustom.AppearanceMenu()
	Screens['SkinBrowser'] = uicustom.SkinBrowser()
	Screens['IconBrowser'] = uicustom.IconBrowser()
	Screens['FoldersEditor'] = uicustom.FoldersEditor()
	Screens['ItemContext'] = uicustom.ItemContext()
	Screens['Logo'] = uicustom.Logo()
	
	for x in Screens:
		ActiveLayer.AddElement(Screens[x])
		Screens[x].Visible = False
	
	return
	
def SwitchBackground(tex):
	global OldBackground, Background
	
	log.info('UI', 'Changed background: ' + tex.GetFile())

	OldBackground.SetTexture(resources.Textures['bg'])
	OldBackground._Alpha = 1
	OldBackground.Visile = False
	OldBackground.Update()
	OldBackground.SetFullscreen()
	resources.Textures['bg'] = tex
	Background.SetTexture(tex)
	Background.ForceAlpha(0)
	Background.SetFullscreen()
	return
	
def SetScreen(e):
	global CurrentScreen, ScreenStack
	
	ScreenStack.append(e)
	CurrentScreen.Visible = False
	CurrentScreen = e
	CurrentScreen.Visible = True
	return

def GoBack():
	global CurrentScreen, ScreenStack
	
	#Needs double pop
	ScreenStack.pop()
	e = ScreenStack.pop()
	SetScreen(e)
	return
	
def SetLastScreen():
	global LastScreen
	
	SetScreen(LastScreen)
	return
	
def Render():
	global UIRoot
	
	UIRoot.Render()
	return
	
def Update():
	global UIRoot, Loader
	Loader.Angle += 1
	
	UIRoot.Update()
	return
	
def HandleKey(name):
	global Screens
	
	if (video.Active):
		video.HandleKey(name)
	elif (Screens['Message'].Visible):
		Screens['Message'].HandleKey(name)
	elif (Screens['Input'].Visible):
		Screens['Input'].HandleKey(name)
	else:
		UIRoot.HandleKey(name)
	return

def ShowLoader():
	global Loader
	
	Loader.Visible = True
	return

def HideLoader():
	global Loader
	
	Loader.Visible = False
	return
		
def ShowMessage(text):
	global Screens
	
	Screens['Message'].Setup(text)
	Screens['Message'].Visible = True
	return
	
def ShowInput(text, itext, cb):
	global Screens
	
	Screens['Input'].Callback = cb
	Screens['Input'].Setup(text, itext)
	Screens['Input'].Visible = True
	return
	
