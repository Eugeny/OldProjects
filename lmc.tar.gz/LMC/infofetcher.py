import urllib
import urllib2
from BeautifulSoup import BeautifulSoup
import settings
import random
import log

#May be needed in future
"""def FetchMovieCover(name):
	ia = imdb.IMDb() # by default access the web.
	
	s_result = ia.search_movie('Hot Fuzz')
	i = s_result[0]
	ia.update(i)
	print vars(i)
	print i['long imdb canonical title']
	return i['cover url']
"""
	
def FetchAudioCover(name):
	log.info('Meta', 'Fetching audio cover: ' + name)
	
	try:
		page = urllib2.urlopen('http://images.yandex.ru/yandsearch?text=' + name.replace(' ','+') + '&stype=image')
		soup = BeautifulSoup(page)
		td = soup.find(attrs={"class" : "b-image"})
		h = td.find('a')['href']
		h = h.split('&')
		r = ''
		for s in h:
			if (s[0]=='i'):
				r = s[8:]
				
		log.info('Meta', 'Found audio cover: ' + urllib.unquote(r))
		return urllib.unquote(r)
	except:
		log.err('Meta', 'Couldn\'t find cover')
		return ''
		
	
def GetAudioCover(name):
	log.info('Meta', 'Downloading')
	try:
		r = settings.Path + 'temp/' + str(random.random()) + '.jpg'
		f = open(r, 'w')
		u = urllib2.urlopen('http://' + FetchAudioCover(name))
		d = u.read()
		while d!='':
			f.write(d)
			d = u.read()
	except:
		log.err('Meta', 'Couldn\'t download cover')

	finally:
		f.close()
		u.close()
	return r
