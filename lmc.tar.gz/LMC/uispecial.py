import uielements
import resources
import glut
import ui
import util
import os
import settings
import threading
import time
import gl
import thread
from lang import *

class KeyBar(uielements.Container):
	__bg = None
	Keys = []
	Names = []
	
	def __init__(self):
		self.Elements = []
		
		self.__bg = uielements.Image();
		self.__bg.SetTexture(resources.Textures['keybar'])
		self.__bg.Width = int(glut.Width * 0.8)
		self.__bg.X = glut.HalfWidth
		self.__bg.Y = glut.Height - self.__bg.Height / 2
		self.__bg.Align = 1
		
		self.AddElement(self.__bg)
		
		self.Names = []
		self.Keys = []
		return
	
	def Reset(self):
		for e in self.Keys:
			self.RemoveElement(e)
		for e in self.Names:
			self.RemoveElement(e)
		self.Names = []
		self.Keys = []
		return
		
	def AddKey(self, key, name):
		k = uielements.Image()
		k.SetTexture(resources.Textures['key_' + key])
		
		l = uielements.Label()
		l.Text = name
		l.SetSize(18)
		l.Update()
		
		self.Keys.append(k)
		self.AddElement(k)
		self.Names.append(l)
		self.AddElement(l)
		return
		
	def Update(self):
		uielements.Container.Update(self)
		
		fw = 0
		for i in range(0, len(self.Keys)):
			if (self.Names[i].Text == ''):
				fw += 25
			else:
				fw += 20 + self.Names[i].Width + 30
				
		x = glut.HalfWidth - int(fw / 2)
		
		for i in range(0, len(self.Keys)):
			k = self.Keys[i]
			l = self.Names[i]
			
			k.X = x
			k.Y = glut.Height - 14
			k.VAlign = 1
			l.X = x + 25
			l.Y = glut.Height - 14
			l.VAlign = 1
			
			if (l.Text == ''):
				x += 25
			else:
				x += 20 + l.Width + 30
			
		return
		
		
class StatusBar(uielements.Container):
	Clock = None
	Volume = ''
	__u = 0
	iOnline = None
	iOffline = None
	
	def __init__(self):
		self.__bg = uielements.Image();
		self.__bg.SetTexture(resources.Textures['statusbar'])
		self.__bg.X = glut.Width
		self.__bg.Y = 0
		self.__bg.Align = 2
		
		self.Clock = uielements.Label()
		self.Clock.X = glut.Width - 6
		self.Clock.Y = 5
		self.Clock.Align = 2
		self.Clock.SetSize(18)
		
		self.iOnline = uielements.Image()
		self.iOnline.SetTexture(resources.Textures['online'])
		self.iOnline.X = glut.Width - 450
		self.iOnline.Y = 0
		self.iOffline = uielements.Image()
		self.iOffline.SetTexture(resources.Textures['offline'])
		self.iOffline.X = glut.Width - 450
		self.iOffline.Y = 0
		
		self.Volume = uielements.Label()
		self.Volume.X = glut.Width - 390
		self.Volume.SetSize(18)
		self.Volume.Y = 5
		
		i =  uielements.Image()
		i.SetTexture(resources.Textures['volume'])
		i.X = glut.Width - 420
		i.Y = 0
		
		self.AddElement(self.__bg)
		self.AddElement(self.Clock)
		self.AddElement(self.iOnline)
		self.AddElement(self.iOffline)
		self.AddElement(self.Volume)
		self.AddElement(i)
		
		return
	
	def Update(self):
		uielements.Container.Update(self)
		self.__u += 1
		self.__u %= 101
		
		import audio
		self.Volume.Text = str(int(audio.Volume*100)) + '%'

		if (self.__u % 50 == 0):
			import datetime
			now = datetime.datetime.now()
			self.Clock.Text = now.strftime("%d %B %Y    %H:%M")
	
		if (self.__u == 100):
			import commands
			r = commands.getstatusoutput('ip link | grep eth0 | grep LOWER_UP')[0] == 0
			self.iOnline.Visible = r
			self.iOffline.Visible = not r
			
		return


class Ring(uielements.Container):
	__bg = None
	Icons = []
	Names = []
	Labels = []
	Selected = 0
	__dx = 0
	
	def __init__(self):
		self.Elements = []
		self.Reset()
		
		self.__bg = uielements.Image();
		self.__bg.SetTexture(resources.Textures['ringbg'])
		self.__bg.SetFullscreen()
		
		k = KeyBar()
		k.AddKey('left', '')
		k.AddKey('right', lang('viewitems'))
		k.AddKey('ok', lang('select'))
		
		self.AddElement(self.__bg)
		self.AddElement(k)
		return
	
	def Reset(self):
		self.Icons = []
		self.Names = []
		
	def AddItem(self, icon, name):
		i = uielements.Image()
		i.SetTexture(resources.Textures[icon])
		i.X = glut.HalfWidth
		i.Y = glut.HalfHeight
		i.VAlign = 1
		i.Align = 1
		i.Width = 128
		i.Height = 128
		
		l = uielements.Label()
		l.Text = name
		l.Align = 1
		l.X = glut.HalfWidth
		l.Y = glut.HalfHeight + 150
		l.SetSize(48)
		l.VAlign = 2
		l.Visible = False
		
		self.Icons.append(i)
		self.Names.append(name)
		self.Labels.append(l)
		
		self.AddElement(i)
		self.AddElement(l)
		
		self.SetSelected(len(self.Names)/2)
		if (len(self.Names)==1):
			self.SetSelected(0)
			
		return
		
	def SetSelected(self, idx):
		self.Labels[self.Selected].Visible = False
		self.Selected = idx
		self.Labels[self.Selected].Visible = True
		return
		
	def HandleKey(self, code):
		if (code == 'left' and self.Selected > 0):
			self.SetSelected(self.Selected - 1)
			return True
		
		if (code == 'right' and self.Selected < len(self.Names) - 1):
			self.SetSelected(self.Selected + 1)
			return True
		return False
		
	def Update(self):
		uielements.Container.Update(self)
		
		dxt = self.Selected * 256
		if (self.__dx < dxt):
			self.__dx += 10
		if (self.__dx > dxt):
			self.__dx -= 10
		if (self.__dx < dxt - 20):
			self.__dx += 10
		if (self.__dx > dxt + 20):
			self.__dx -= 10
		if (self.__dx < dxt - 40):
			self.__dx += 10
		if (self.__dx > dxt + 40):
			self.__dx -= 10
		
		dx = self.__dx
		
		for i in range(0, len(self.Names)):
			self.Icons[i].X = glut.HalfWidth - dx + i * 256
			if (abs(self.Icons[i].X - glut.HalfWidth) < 256):
				s = 1.5 * 512
				s -= abs(self.Icons[i].X - glut.HalfWidth)
				s /= 512
				self.Icons[i].ScaleBy(128, 128, s, s)
			else:
				self.Icons[i].ScaleBy(128, 128, 1, 1)
			
		return
		
		
class MenuName(uielements.Container):
	__lblbig = None
	__lblsmall = None
	TextBig = ''
	TextSmall = ''
	
	def __init__(self):
		self.Elements = []
		
		self.__lblbig = uielements.Label()
		self.__lblbig.SetSize(48)
		self.__lblbig.Text = 'Main menu'
		self.__lblbig.X = 20
		self.__lblbig.Y = 100
		
		self.__lblsmall = uielements.Label()
		self.__lblsmall.SetSize(24)
		self.__lblsmall.Text = '<'
		self.__lblsmall.X = 20
		self.__lblsmall.Y = 147
		self.__lblsmall.R = 0.7
		self.__lblsmall.G = 0.7
		self.__lblsmall.B = 0.7
		
		self.AddElement(self.__lblsmall)
		self.AddElement(self.__lblbig)
		return
		
	def Update(self):
		uielements.Container.Update(self)
		self.__lblbig.Text = self.TextBig
		self.__lblsmall.Text = self.TextSmall
		return
		
		
class FileBrowser(uielements.Container):
	__labels = []
	__icons = []
	Path = '/'
	Root = ''
	Selected = 0
	__dx = 0
	__hl = None
	_files = []
	__dy = 0
	Scroll = 0
	Busy = False
	__info = None
	__bigicon = None
	__fn = ' '
	__infoname = None
	__infosize = None
	SelectedFile = ''
	
	def __init__(self, text):
		self.Elements = []
		
		m = MenuName()
		m.TextBig = text
		m.TextSmall = '< ' + lang('mainmenu')
		
		h = uielements.Image()
		h.SetTexture(resources.Textures['file_hl'])
		h.Width = glut.Width - 400
		h.X = 295
		h.VAlign = 1
		self.__hl = h
		
		i = uielements.Image()
		i.SetTexture(resources.Textures['infobar'])
		i.Y = glut.Height - 100
		i.X = 0
		i.Width = glut.Width
		self.__info = i
		
		bi = uielements.Image()
		bi.SetTexture(resources.Textures['folder_files'])
		bi.X = 50
		bi.Y = glut.Height - 90
		bi.Width = 80
		bi.Height = 80
		self.__bigicon = bi
		
		i1 = uielements.Label()
		i1.SetSize(24)
		i1.X = 150
		i1.Y = glut.Height - 80
		self.__infoname = i1
		
		i2 = uielements.Label()
		i2.SetSize(14)
		i2.X = 150
		i2.Y = glut.Height - 50
		i2.R = 0.8
		i2.G = 0.8
		i2.B = 0.8
		self.__infosize = i2
		
		k = KeyBar()
		k.AddKey('up', '')
		k.AddKey('down', lang('viewfiles'))
		k.AddKey('ok', lang('open'))
		k.AddKey('back', lang('goback'))
		
		self.AddElement(m)
		self.AddElement(h)
		self.AddElement(i)
		self.AddElement(bi)
		self.AddElement(i1)
		self.AddElement(i2)
		self.AddElement(k)
		
		self.SetRoot('')
		return
		
	def HandleKey(self, code):
		if (uielements.Container.HandleKey(self, code)):
			return True
		return False
		
	def SetRoot(self, root):
		self.Root = root
		self.BeginNavigate('/')
		return
		
	def BeginNavigate(self, path):
		t = threading.Thread(None, FileBrowser.Navigate, None, (self, path))
		t.setDaemon(True)
		t.start()
		
	def Navigate(self, path):
		self.Busy = True
		ui.ShowLoader()
		
		while (path[len(path)-1] == '/' and len(path)>1):
			path = path[0:len(path)-1]
			
		self.Path = path
		for e in self.__labels:
			self.RemoveElement(e)
		for e in self.__icons:
			self.RemoveElement(e)
			
		self.__labels = []
		self.__icons = []
		self.Selected = 0
		self.__dy = 0
		self.Scroll = 0
		self.__dx = 0
		
		if (self.Root == ''):
			for i in range(0, len(settings.Folders)):
				l = uielements.Label()
				l.Text = os.path.split(settings.Folders[i])[1]
				l.X = 300
				l.Y = 100 + i * 32
				l.SetSize(18)
				l.VAlign = 1
				self.__labels.append(l)
				self.AddElement(l)
				
				p = uielements.Image()
				p.SetTexture(resources.Textures['folder_' + settings.FolderCats[i]])
				p.X = 260
				p.Y = 100 + i * 32
				p.Width = 32
				p.Height = 32
				p.VAlign = 1
				self.__icons.append(p)
				self.AddElement(p)
				
				i += 1
		else:
			try:
				f = os.listdir(self.Root + self.Path)
			except:
				ui.HideLoader()
				ui.ShowMessage(lang('navigationerror'))
				self.Busy = False
				self.HandleKey('back')
				return
		
			f.sort(self.FileCompare)
			if len(f)==0:
				ui.HideLoader()
				self.Busy = False
				self.HandleKey('back')
				ui.ShowMessage(lang('emptyfolder'))
				return
			self._files = f
			
			i = 0
			for s in self._files:
				l = uielements.Label()
				l.Text = s
				l.X = 300
				l.Y = 100 + i * 32
				l.SetSize(18)
				l.VAlign = 1
				self.__labels.append(l)
				self.AddElement(l)
				
				p = uielements.Image()
				p.SetTexture(resources.Textures[self.GetFileIcon(s)])
				p.X = 260
				p.Y = 100 + i * 32
				p.Width = 32
				p.Height = 32
				p.VAlign = 1
				self.__icons.append(p)
				self.AddElement(p)
				
				i += 1
				
		ui.HideLoader()
		self.Busy = False
		return
		
	def GetFileIcon(self, f):
		if (os.path.isdir(self.Root + self.Path + '/' + f)):
			return 'folder_files'
		e = os.path.splitext(f)[1].upper()
		
		if (e in settings.VideoExts):
			return 'file_video'
		
		if (e in settings.AudioExts):
			return 'file_audio'
		
		if (e in settings.PhotoExts):
			return 'file_photo'
			
		return 'file'
	
	def FileCompare(self, x, y):
		d1 = os.path.isdir(self.Root + self.Path + '/' + x)
		d2 = os.path.isdir(self.Root + self.Path + '/' + y)
		if (d1 and d2):
			return cmp(x,y)
		if (d1):
			return -1
		if (d2):
			return 1
		return cmp(x,y)
		
	def Update(self):
		if (not self.Busy):
			try:
				if (self.Root != '' and self._files[self.Selected] != self.__fn):
					self.__fn = self._files[self.Selected]
					self.__bigicon.SetTexture(resources.Textures[self.GetFileIcon(self.__fn)])
					self.__bigicon.Width = 80
					self.__bigicon.Height = 80
					self.__infoname.Text = self.__fn
					self.__infosize.Text = lang('ft_' + util.GetFileType(self.Root + self.Path + '/' + self.__fn)) + ', ' + util.GetSizeString(os.path.getsize(self.Root + self.Path + '/' + self.__fn))
					if (util.GetFileType(self.Root + self.Path + '/' + self.__fn) == 'Folder'):
						self.__infosize.Text = lang('folder')
			except:
				log.err('Debug','528')
				
		if (not self.Busy):
			if (self.Root == '' and self.__fn != ''):
				self.__fn = ''
				self.__bigicon.SetTexture(resources.Textures['folder_files'])
				self.__bigicon.Width = 80
				self.__bigicon.Height = 80
				self.__infoname.Text = lang('selectfolder')

		
		uielements.Container.Update(self)
		uielements.Container.Update(self)
		uielements.Container.Update(self)
		
		if (self.Busy):
			return
		
		try:
			if (self.Root == ''):
				self.SelectedFile = ''
			else:
				self.SelectedFile = util.FixPath(self.Root + self.Path + '/' + self._files[self.Selected])
		except:
			log.err('Debug','552')
			
		
			
		dxt = self.Selected * 32
		if (self.__dx < dxt):
			self.__dx += 5
		if (self.__dx > dxt):
			self.__dx -= 5
		if (self.__dx < dxt - 20):
			self.__dx += 5
		if (self.__dx > dxt + 20):
			self.__dx -= 5
		if (self.__dx < dxt - 40):
			self.__dx += 15
		if (self.__dx > dxt + 40):
			self.__dx -= 15
			
		dyt = self.Scroll * 32
		if (self.__dy < dyt):
			self.__dy += 5
		if (self.__dy > dyt):
			self.__dy -= 5
		if (self.__dy < dyt - 20):
			self.__dy += 10
		if (self.__dy > dyt + 20):
			self.__dy -= 10
		if (self.__dy < dyt - 40):
			self.__dy += 15
		if (self.__dy > dyt + 40):
			self.__dy -= 15
		
		self.__hl.Y = 100 + self.__dx - self.__dy
		
		for i in range(0, len(self.__labels)):
			self.__labels[i].Visible = False
			self.__labels[i].Y = 100 + i * 32 - self.__dy
			
		for i in range(self.Scroll, min(len(self.__labels), self.Scroll + (glut.Height - 250) / 32 + 1)):
			self.__labels[i].Visible = True
			
		for i in range(0, len(self.__labels)):
			self.__icons[i].Visible = False
			self.__icons[i].Y = 100 + i * 32 - self.__dy
		
		for i in range(self.Scroll, min(len(self.__labels), self.Scroll + (glut.Height - 250) / 32 + 1)):
			self.__icons[i].Visible = True
		
		return
		
	
	def HandleKey(self, code):
		if (self.Busy):
			return False
			
		if (uielements.Container.HandleKey(self, code)):
			return True
		
		
		if (code == 'up' and self.Selected > 0):
			self.Selected -= 1
			if (self.Scroll + 5 > self.Selected and self.Scroll > 0):
				self.Scroll -= 1
			return True
			
		if (code == 'down' and self.Root == '' and self.Selected < len(settings.Folders) - 1):
			self.Selected += 1
			if (self.Scroll + (glut.Height - 200) / 32 - 5 < self.Selected and self.Scroll + (glut.Height - 250) / 32 < len(settings.Folders) - 1):
				self.Scroll += 1
			return True
			
		if (code == 'down' and self.Root != '' and self.Selected < len(self._files) - 1):
			self.Selected += 1
			if (self.Scroll + (glut.Height - 200) / 32 - 5 < self.Selected and self.Scroll + (glut.Height - 250) / 32 < len(self._files) - 1):
				self.Scroll += 1
			return True

		if (code == 'ok'):
			if (self.Root == ''):
				self.SetRoot(settings.Folders[self.Selected])
				return True
			else:
				if (os.path.isdir(self.Root + self.Path + '/' + self._files[self.Selected])):
					self.BeginNavigate(self.Path + '/' + self._files[self.Selected])
				return True
				
		if (code == 'back'):
			if (self.Root != ''):
				s = os.path.split(self.Path)[0]
				if (self.Path == '/' or self.Path == '//'):
					self.SetRoot('')
				else:
					self.BeginNavigate(s)
				return True
				
		return False
	

class PhotoBrowser(uielements.Container):
	__bg = None
	Icons = []
	Labels = []
	Files = []
	Selected = 0
	__dx = 0
	Folder = settings.Path + 'wallpapers'
	Scaling = 0.0
	Scaling2 = 0.0
	Image = None
	Image2 = None
	Image3 = None
	OImage = None
	OImage2 = None
	OImage3 = None
	
	Blackout = None
	FS = False
	
	def __init__(self):
		self.Elements = []
		
		self.__bg = uielements.Image();
		self.__bg.SetTexture(resources.Textures['photosbg'])
		self.Scaling = 1.0 * glut.Width / self.__bg.Width
		self.__bg.Scale(1.0 * glut.Width / self.__bg.Width, 1.0)
		self.__bg.Y = glut.Height - 160
		k = KeyBar()
		k.AddKey('left', '')
		k.AddKey('right', lang('viewitems'))
		k.AddKey('ok', lang('fullscreen'))
		k.AddKey('back', lang('goback'))
	
		i = uielements.Image()
		i.X = glut.HalfWidth
		i.Y = glut.HalfHeight
		i.Align = 1
		i.VAlign = 1
		self.Image = i
		i = uielements.Image()
		i.X = glut.HalfWidth - 40
		i.Y = glut.HalfHeight
		i.Align = 1
		i.VAlign = 1
		i.Angle = -5.5
		self.Image2 = i
		i = uielements.Image()
		i.X = glut.HalfWidth + 40
		i.Y = glut.HalfHeight - 30
		i.Align = 1
		i.VAlign = 1
		i.Angle = 5.5
		self.Image3 = i
		
		i = uielements.Image()
		i.X = glut.HalfWidth
		i.Y = glut.HalfHeight
		i.Align = 1
		i.VAlign = 1
		self.OImage = i
		i = uielements.Image()
		i.X = glut.HalfWidth - 40
		i.Y = glut.HalfHeight
		i.Align = 1
		i.VAlign = 1
		i.Angle = -5.5
		self.OImage2 = i
		i = uielements.Image()
		i.X = glut.HalfWidth + 40
		i.Y = glut.HalfHeight - 30
		i.Align = 1
		i.VAlign = 1
		i.Angle = 5.5
		self.OImage3 = i
		
		
		self.Blackout = uielements.Image()
		self.Blackout.SetTexture(resources.Textures['black'])
		self.Blackout.SetFullscreen()
		self.Blackout.Visible = False
		
		self.AddElement(self.__bg)
		self.AddElement(k)
		self.AddElement(self.Blackout)
		self.AddElement(self.OImage2)
		self.AddElement(self.OImage3)
		self.AddElement(self.OImage)
		self.AddElement(self.Image2)
		self.AddElement(self.Image3)
		self.AddElement(self.Image)
		
		self.Navigate(settings.Path + 'wallpapers')
		thread.start_new_thread(self.Preloader, ())
		return
	
	def Preloader(self):
		while (True):
			try:
				time.sleep(0.1)
				for i in range(max(self.Selected - 3, 0), min(self.Selected + 3, len(self.Icons))):
					if (self.Icons[i].Texture.GetFile() == settings.Path + 'images/black.png'):
						
						for i in range(max(self.Selected - 8, 0), min(self.Selected + 8, len(self.Icons))):
							if (self.Icons[i].Texture.GetFile() == settings.Path + 'images/black.png'):
								ui.ShowLoader()
								im = self.Icons[i]
								gl.TexQueuePush(self.Folder + '/' + self.Files[i])
								im.SetTexture(gl.TexQueuePop())
								im.X = glut.HalfWidth
								im.Y = glut.Height - 150.0
								im.VAlign = 0
								im.Align = 1
								im.Scale(110.0 / im.Height, 110.0 / im.Height)
								im.Shadow = True
								if (abs(self.Selected-i)<2):
									self.SetSelected(self.Selected)
								ui.HideLoader()
			except:
				pass
		return
		
	def Navigate(self, folder):
		self.Folder = folder
		self.Labels = []
		
		for x in self.Icons:
			self.RemoveElement(x)
		
		ss = os.listdir(folder)
		ss.sort()
		
		self.Icons = []
		self.Files = []
		
		self.RemoveElementNow(self.Blackout)
		self.RemoveElementNow(self.Image)
		self.RemoveElementNow(self.OImage)
		
		for s in ss:
			if (util.GetFileType(s) == 'Image'):
				self.Files.append(s)
				
				i = uielements.Image()
				i.SetTexture(resources.Textures['black'])
				i.X = glut.HalfWidth
				i.Y = glut.Height - 150.0
				i.VAlign = 0
				i.Align = 1
				i.Scale(110.0 / i.Height, 110.0 / i.Height)
				i.Shadow = True
				
				self.Icons.append(i)
		
				self.AddElement(i)
				
				if (len(self.Icons)==1):
					self.SetSelected(0)
					
		self.AddElement(self.Blackout)
		self.AddElement(self.OImage)
		self.AddElement(self.Image)
		
		return
		
	def SetSelected(self, idx):
		self.Image, self.OImage = self.OImage, self.Image
		self.Image2, self.OImage2 = self.OImage2, self.Image2
		self.Image3, self.OImage3 = self.OImage3, self.Image3
		
		self.Image.Visible = True
		self.Image._Alpha = 0
		self.Image2.Visible = True
		self.Image2._Alpha = 0
		self.Image3.Visible = True
		self.Image3._Alpha = 0
		
		self.OImage.Visible = False
		self.OImage2.Visible = False
		self.OImage3.Visible = False
		
		
		self.Selected = idx
				
		i = self.Image
		t = self.Icons[self.Selected].Texture
		self.Scaling2 = 1.0 * glut.Height / t.Height * 0.5
		i.SetTexture(t)
		i.Scale(self.Scaling2, self.Scaling2)
		i.Shadow = True
		
		self.Image2.Visible = (not self.FS) and self.Selected > 0
		self.Image3.Visible = (not self.FS) and self.Selected < len(self.Icons) - 1
		
		self.Blackout.Visible = self.FS
		if (self.FS):
			s = 1.0
			i.SetTexture(t)
			if (1.0 * i.Width / glut.Width >= 1.0 * i.Height / glut.Height): s = 1.0 * glut.Width / i.Width
			if (1.0 * i.Width / glut.Width < 1.0 * i.Height / glut.Height): s = 1.0 * glut.Height / i.Height
			i.Scale(s, s)
		else:
			if (self.Image2.Visible):
				t = self.Icons[self.Selected-1].Texture
			else:
				t = self.Icons[self.Selected].Texture
			i = self.Image2
			self.Scaling2 = 1.0 * glut.Height / t.Height * 0.5
			i.SetTexture(t)
			i.Scale(self.Scaling2, self.Scaling2)
			i.Shadow = True
			if (self.Image3.Visible):
				t = self.Icons[self.Selected+1].Texture
			else:
				t = self.Icons[self.Selected].Texture
			i = self.Image3
			self.Scaling2 = 1.0 * glut.Height / t.Height * 0.5
			i.SetTexture(t)
			i.Scale(self.Scaling2, self.Scaling2)
			i.Shadow = True
		
		i.Visible = True
		
		return
		
	def HandleKey(self, code):
		if (code == 'left' and self.Selected > 0):
			self.SetSelected(self.Selected - 1)
			return True
		
		if (code == 'ok'):
			self.FS = not self.FS
			self.SetSelected(self.Selected)
			return True
			
		if (code == 'right' and self.Selected < len(self.Icons) - 1):
			self.SetSelected(self.Selected + 1)
			return True

		return False
		
	def Update(self):
		uielements.Container.Update(self)
		
		dxt = self.Selected * (130.0 / 9 * 20)
		if (self.__dx < dxt):
			self.__dx += 10
		if (self.__dx > dxt):
			self.__dx -= 10
		if (self.__dx < dxt - 20):
			self.__dx += 10
		if (self.__dx > dxt + 20):
			self.__dx -= 10
		if (self.__dx < dxt - 40):
			self.__dx += 20
		if (self.__dx > dxt + 40):
			self.__dx -= 20
		if (self.__dx < dxt - 180):
			self.__dx += 50
		if (self.__dx > dxt + 180):
			self.__dx -= 50
		
		dx = self.__dx
		
		for i in range(0, len(self.Icons)):
			self.Icons[i].X = glut.HalfWidth - dx + i * (130.0 / 9 * 20)
			self.Icons[i].Visible = abs(self.Icons[i].X - glut.Width/2) < glut.Width
			self.Icons[i].Update()
			
		return
		
		
class Message(uielements.Container):
	__bg = None
	Keys = None
	Text = None
	Blackout = None
	
	def __init__(self):
		self.Elements = []
		
		self.Blackout = uielements.Image()
		self.Blackout.SetTexture(resources.Textures['black'])
		self.Blackout.SetFullscreen()
		self.Blackout.Visible = True
		self.Blackout.MaxAlpha = 0.75
		
		self.__bg = uielements.Image();
		self.__bg.SetTexture(resources.Textures['message'])
		self.__bg.X = glut.HalfWidth
		self.__bg.Y = glut.HalfHeight
		self.__bg.Align = 1
		self.__bg.VAlign = 1
		
		self.Keys = KeyBar()
		self.Keys.Reset()
		self.Keys.AddKey('ok',lang('ok'))
		
		self.Text = uielements.Label()
		self.Text.Align = 1
		self.Text.X = glut.HalfWidth
		self.Text.Y = glut.HalfHeight
		self.Text.VAlign = 1
		self.Text.SetSize(18)
		
		self.AddElement(self.Blackout)
		self.AddElement(self.__bg)
		self.AddElement(self.Text)
		self.AddElement(self.Keys)
		return
	
	def Setup(self, name):
		self.Text.Text = name
		return
		
	def HandleKey(self, code):
		self.Visible = False
		return True
	
	
class Input(uielements.Container):
	__bg = None
	Keys = None
	Text = None
	Inp = None
	Blackout = None
	Callback = None
	
	def __init__(self):
		self.Elements = []
		
		self.Blackout = uielements.Image()
		self.Blackout.SetTexture(resources.Textures['black'])
		self.Blackout.SetFullscreen()
		self.Blackout.Visible = True
		self.Blackout.MaxAlpha = 0.75
		
		self.__bg = uielements.Image();
		self.__bg.SetTexture(resources.Textures['input'])
		self.__bg.X = glut.HalfWidth
		self.__bg.Y = glut.HalfHeight
		self.__bg.Align = 1
		self.__bg.VAlign = 1
		
		self.Keys = KeyBar()
		self.Keys.Reset()
		self.Keys.AddKey('ok',lang('ok'))
		
		self.Text = uielements.Label()
		self.Text.Align = 1
		self.Text.X = glut.HalfWidth
		self.Text.Y = glut.HalfHeight - 15
		self.Text.VAlign = 2
		self.Text.SetSize(18)
		
		self.Inp = uielements.Label()
		self.Inp.Align = 1
		self.Inp.X = glut.HalfWidth
		self.Inp.Y = glut.HalfHeight + 10
		self.Inp.VAlign = 0
		self.Inp.SetSize(18)
		self.Inp.R = 0
		self.Inp.G = 0
		self.Inp.B = 0
		
		self.AddElement(self.Blackout)
		self.AddElement(self.__bg)
		self.AddElement(self.Text)
		self.AddElement(self.Inp)
		self.AddElement(self.Keys)
		return
	
	def Setup(self, name, text):
		self.Text.Text = name
		self.Inp.Text = text
		return
		
	def HandleKey(self, code):
		if (len(code)==1):
			self.Inp.Text += code.encode('windows-1251')
			return True
			
		if (code == 'back'):
			if (len(self.Inp.Text) > 1):
				self.Inp.Text = self.Inp.Text[0:len(self.Inp.Text)-1]
			
		if (code == 'ok'):
			self.Visible = False
			if (self.Callback != None):
				self.Callback(self.Inp.Text)
		return True
	
