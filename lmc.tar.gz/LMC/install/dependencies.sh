#!/bin/sh
apt-get update
apt-get install python-opengl libftgl2 libboost-python1.40.0 python-pygame python-setuptools libgle3 python-gst0.10 python-beautifulsoup gstreamer0.10-x gstreamer0.10-alsa gstreamer0.10-plugins-base gstreamer0.10-plugins-good gstreamer0.10-x
easy_install PyOpenGL
