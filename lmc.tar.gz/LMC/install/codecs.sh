#!/bin/sh
apt-get install gstreamer0.10-ffmpeg  gstreamer0.10-plugins-ugly
