import thread
import pygame
import time
import ui

def Init():
	thread.start_new_thread(Run, ())
	return
	
def HandlePress(button):
	if (button == 1):
		ui.HandleKey('ok')
	if (button == 3):
		ui.HandleKey('back')
	if (button == 4):
		ui.HandleKey('up')
	if (button == 5):
		ui.HandleKey('down')
	if (button == 6):
		ui.HandleKey('left')
	if (button == 7):
		ui.HandleKey('right')
	if (button == 8):
		ui.HandleKey('a')
	if (button == 9):
		ui.HandleKey('b')
		
	return
	
	
ddx = False
ddy = False
threshold = 30

def Run():
	global ddx, ddy, threshold
	
	while (True):
		pygame.mouse.set_visible(False)
		time.sleep(0.05)
		dx, dy = pygame.mouse.get_rel()
		
		if (dx>threshold or dx<-threshold):
			if (not ddx):
				ddx = True
				if (dx>threshold):
					ui.HandleKey('right')
				else:
					ui.HandleKey('left')
		else:
			ddx = False
			
		if (dy>threshold or dy<-threshold):
			if (not ddy):
				ddy = True
				if (dy>threshold):
					ui.HandleKey('down')
				else:
					ui.HandleKey('up')
		else:
			ddy = False
			
	return
