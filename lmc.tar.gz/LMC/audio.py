import uielements
import uispecial
import uicustom
import ui
import gst
import os
import util
import thread
import gl
import playlist
import resources
import settings
import time
import log

time_format = None
player = None
Active = False
AudioStream = 0
ProgressBar = None
ExitUpdaterThread = False
Spectrum = None
Screen = None

Artist = ''
Title = ''
Album = ''

FetchIt = ''

Volume = 1.0


def Init():
	global player, time_format, Spectrum, Screen
	
	log.info('Audio', 'Using ' + gst.version_string())
	log.info('Audio', 'Creating pipeline')

	Spectrum = gst.element_factory_make("spectrum")
	Spectrum.set_property('bands', 20)
	Spectrum.set_property('interval', 10000000)
	
	sink = gst.Bin()
	asink = gst.element_factory_make('alsasink')
	sink.add(Spectrum, asink)
	Spectrum.link(asink)
	pad = gst.GhostPad('sink', Spectrum.get_pad('sink'))
	sink.add_pad(pad)
	player = gst.element_factory_make("playbin2")
	player.set_property('audio-sink', sink)
				
	bus = player.get_bus()
	bus.add_signal_watch()
	bus.enable_sync_message_emission()
	bus.set_sync_handler(on_message2)
	bus.connect("message", on_message)
	bus.connect("sync-message::element", on_sync_message)
		
	time_format = gst.Format(gst.FORMAT_TIME)

	Screen = ui.Screens['AudioPlayer']
	return
	
def Preloader():
	global FetchIt, Screen

	log.info('Audio', 'Fetching cover for: ' + FetchIt)

	if (not settings.Fetch):
		return
		
	file = FetchIt
	import infofetcher
	n = infofetcher.GetAudioCover(file)
	if (FetchIt != file):
		os.remove(n)
		return

	gl.TexQueuePush(n)
	Screen.Cover.SetTexture(gl.TexQueuePop())
	os.remove(n)
	Screen.Cover.Width = 200
	Screen.Cover.Height = 200
	return
	
def OpenFile(file):
	global player, time_format, Screen, Title, Artist, Album

	log.info('Audio', 'Opening file: ' + file)
	
	player.set_property('uri', 'file://' + file.replace('#','%23'))
	
	Play()
	player.seek_simple(time_format, gst.SEEK_FLAG_FLUSH, 0)
	
	Screen.Cover.SetTexture(resources.Textures['cover'])
	
	Title = os.path.splitext(os.path.split(file)[1])[0]
	Artist = ''
	Album = ''
	SetTags()
	return

def SetTags():
	global Artist, Title, Album, Screen
	
	log.info('Audio', 'Tags received: ' + Artist + ' - ' + Album + ' - ' + Title)

	Screen.Title.Text = Title
	Screen.Artist.Text = Artist
	if (not Artist == '') and (not Album == ''):
		Screen.Artist.Text += ' - '
	Screen.Artist.Text += Album
	return
	
def Show():
	global Screen
	
	ui.SetScreen(Screen)
	return
	
def Hide():
	ui.GoBack()
	return
	
def Stop():
	global player
	
	if (not gst.STATE_READY in player.get_state()):
		player.set_state(gst.STATE_READY)
	log.info('Audio', 'Stopping')
	return

def Pause():
	global player
	
	player.set_state(gst.STATE_PAUSED)
	log.info('Audio', 'Paused')
	return

def Play():
	global player
	
	player.set_state(gst.STATE_PLAYING)
	log.info('Audio', 'Playing')
	return
	
def TogglePause():
	global player
	
	if (gst.STATE_PLAYING in player.get_state()):
		player.set_state(gst.STATE_PAUSED)
	elif(gst.STATE_PAUSED in player.get_state()):
		player.set_state(gst.STATE_PLAYING)
	return

def VolumeUp():
	global Volume, player
	
	if (Volume < 2.0): Volume += 0.1
	player.set_property('volume', Volume)
	log.info('Audio', 'Volume: ' + str(Volume))
	return
	
def VolumeDown():
	global Volume, player
	
	if (Volume > 0.2): Volume -= 0.1
	player.set_property('volume', Volume)
	log.info('Audio', 'Volume: ' + str(Volume))
	return
	
def on_message(bus, message):
	global player
	
	t = message.type
	if t == gst.MESSAGE_ERROR:
		err, debug = message.parse_error()
		log.err('Audio', err)
		log.err('Audio', debug)
		player.set_state(gst.STATE_NULL)
	return
		
def NextTmr():
	time.sleep(0.5)
	playlist.Next()
	return
	
def on_message2(bus, message):
	global player
	t = message.type
	
	if t == gst.MESSAGE_EOS:
		thread.start_new_thread(NextTmr, ()) #Wait 0.5 sec for stream to stop fully
		
	if t == gst.MESSAGE_TAG:
		log.info('Audio', 'Tags arrived')

		c = False # Not found ID3 stuff yet
		try:
			global Title
			Title = util.DecodeString(str(message.structure['title']))
			c = True
		except:
			pass
			
		try:
			global Artist
			Artist = util.DecodeString(str(message.structure['artist']))
			c = True
		except:
			pass
			
		try:
			global Album
			Album = util.DecodeString(str(message.structure['album']))
			c = True
		except:
			pass
			
		SetTags()
		if (c):
			global FetchIt
			FetchIt = Artist + ' ' + Album
			thread.start_new_thread(Preloader, ()) #Fetch album cover
			
	return gst.BUS_PASS
	
def on_sync_message(bus, message):
	global Screen, time_format
	
	if message.structure is None:
		return
		
	message_name = message.structure.get_name()
	if (message_name == 'spectrum'):
		Screen.Set(message.structure['magnitude'])
	
	p = player.query_position(time_format, None)[0]
	d = player.query_duration(time_format, None)[0]
	Screen.Pbr.Width = int(650.0 * p / d) + 1
	return

def HandleKey(code):
	if (code == 'back'):
		Stop()
		Hide()
	
	if (code == 'a'):
		ui.SetScreen(ui.Screens['Playlist'])
		
	if (code == 'ok'):
		TogglePause()
	
	if (code == 'left'):
		playlist.Prev()
	
	if (code == 'right'):
		playlist.Next()
	
	if (code == 'up'):
		VolumeUp()
	
	if (code == 'down'):
		VolumeDown()
	
	return True
