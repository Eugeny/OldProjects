import app

def main():
	global Instance 
	Instance = app.LMC()
	return 0

if __name__ == '__main__':
	main()
