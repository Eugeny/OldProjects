# coding=utf-8
import settings
import os
from lang import *
import log

# 1251, да
EPICFAIL = 'éöóêåíãøùçõúôûâàïðîëäæýÿ÷ñìèòüáþÉÖÓÊÅÍÃØÙÇÕÚÔÛÂÀÏÐÎËÄÆÝß×ÑÌÈÒÜÁÞ'

def GetFileType(f):
	if (os.path.isdir(f)):
		return 'Folder'
	e = os.path.splitext(f)[1].upper()
	
	if (e in settings.VideoExts):
		return 'Video'
	
	if (e in settings.AudioExts):
		return 'Audio'
	
	if (e in settings.PhotoExts):
		return 'Image'
	
	return 'File'
	
def LinkFile(f):
	log.info('Util', 'Linked file: ' + f)
	os.symlink(f, settings.Path + 'temp/file.link')
	return settings.Path + 'temp/file.link'
	
def FixPath(s):
	for j in range(0,20):
		s = s.replace('//', '/')
	return s
	
def DecodeString(s):
	global fail
	
	try:
		f = False
		for i in range(0,min(10,len(s))):
			for j in range(0,len(EPICFAIL)):
				if s[i]==EPICFAIL[j]:
					f = True
					break
				
		if (f): return str(s.encode('iso-8859-1').decode('windows-1251'))
		return s
	except:
		return s

#NOT USED
def DecodeSubtitles(s):
	f = open(s, 'r')
	ss = f.readlines()
	f.close()
	
	for i in range(len(ss)):
		ss[i] = DecodeString(ss[i])
		
	f = open(settings.Path + 'temp/sub', 'w')
	f.writelines(ss)
	f.close()
	return settings.Path + 'temp/sub'
	
def GetSizeString(s):
	r = lang('sz_b')
	if (s > 1024):
		s /= 1024
		r = lang('sz_kb')
	if (s > 1024):
		s /= 1024
		r = lang('sz_mb')
	if (s > 1024):
		s /= 1024
		r = lang('sz_gb')
	return str(s) + ' ' + r
	
def GetTimeString(n):
	r = ''
	n = int(n/1000000000)
	
	s = n % 60
	n = int(n/60)
	
	m = n % 60
	n = int(n/60)
	
	h = n
	
	
	if (h<10): r += '0'
	r += str(h) + ':'
	
	if (m<10): r += '0'
	r += str(m) + ':'
	
	if (s<10): r += '0'
	r += str(s)
	
	return r
	
