import gl
import settings
import log

Textures = {}


def LoadTexture(name, file):
	global Textures
	log.info('Resources', 'Loading texture: ' + file + ' as ' + name)

	try:
		nt = gl.Texture(file)
	except:
		log.err('Resources', 'Failed to load texture: ' + file)

	if (Textures.has_key(name)):
		h = Textures[name].Handle
		import ui
		Retexturize(ui.UIRoot, h, nt)
		
	Textures[name] = nt
	return
	

def Retexturize(root, oldhandle, newtex):
	import uielements

	if (root == None): return
	
	try:
		if (root.Texture.Handle == oldhandle):
			root.Texture = newtex
			root.Sprite.Texture = newtex
	except:
		pass
		
	try:
		for x in root.Elements:
			Retexturize(x, oldhandle, newtex)
	except:
		pass
				
	return
	
def LoadIconset(name):
	folder = settings.Path + 'icons/' + name + '/'
	log.info('Resources', 'Loading iconset: ' + name)

	LoadTexture('icon_files', folder + 'files.png')
	LoadTexture('icon_options', folder + 'options.png')
	LoadTexture('icon_walls', folder + 'wallpapers.png')
	LoadTexture('folder_files', folder + 'folder.png')
	LoadTexture('folder_video', folder + 'folder_video.png')
	LoadTexture('folder_audio', folder + 'folder_audio.png')
	LoadTexture('folder_photo', folder + 'folder_photo.png')
	LoadTexture('file_video', folder + 'file_video.png')
	LoadTexture('file_audio', folder + 'file_audio.png')
	LoadTexture('file_photo', folder + 'file_photo.png')
	LoadTexture('file', folder + 'file.png')
	LoadTexture('locale', folder + 'locale.png')
	LoadTexture('internet', folder + 'internet.png')
	LoadTexture('item_delete', folder + 'item_delete.png')
	LoadTexture('item_up', folder + 'item_up.png')
	LoadTexture('item_down', folder + 'item_down.png')
	LoadTexture('item_edit', folder + 'item_edit.png')
	
	return
	
def LoadSkin(name):
	folder = settings.Path + 'skins/' + name + '/'
	log.info('Resources', 'Loading skin: ' + name)

	LoadTexture('ringbg', folder + 'ringbg.png')
	LoadTexture('photosbg', folder + 'photosbg.png')
	LoadTexture('file_hl', folder + 'file_highlight.png')
	LoadTexture('infobar', folder + 'infobar.png')
	LoadTexture('keybar', folder + 'keybar.png')
	LoadTexture('statusbar', folder + 'statusbar.png')
	LoadTexture('loader', folder + 'ldr0.png')
	LoadTexture('spectrum', folder + 'spectrum.png')
	LoadTexture('spectrum2', folder + 'spectrum2.png')
	LoadTexture('progress', folder + 'progress.png')
	LoadTexture('progressbg', folder + 'progressbg.png')
	LoadTexture('message', folder + 'message.png')
	LoadTexture('input', folder + 'input.png')
	
	LoadTexture('online', folder + 'online.png')
	LoadTexture('offline', folder + 'offline.png')
	LoadTexture('volume', folder + 'volume.png')
	
	LoadTexture('key_left', folder + 'keys/left_sm.png')
	LoadTexture('key_right', folder + 'keys/right_sm.png')
	LoadTexture('key_up', folder + 'keys/up_sm.png')
	LoadTexture('key_down', folder + 'keys/down_sm.png')
	LoadTexture('key_ok', folder + 'keys/ok_sm.png')
	LoadTexture('key_back', folder + 'keys/back_sm.png')
	LoadTexture('key_a', folder + 'keys/a_sm.png')
	LoadTexture('key_b', folder + 'keys/b_sm.png')
	return
	
def LoadCommon():
	log.info('Resources', 'Loading common textures')

	LoadTexture('black', settings.Path + 'images/black.png')
	LoadTexture('bg', settings.Path + 'wallpapers/' + settings.Wallpaper)
	LoadTexture('shadow', settings.Path + 'images/shadow.png')
	LoadTexture('cover', settings.Path + 'images/cover.png')
	LoadTexture('logo_0', settings.Path + 'images/logo1.png')
	LoadTexture('logo_1', settings.Path + 'images/logo2.png')
	return
	
def LoadAll():
	LoadCommon()
	LoadSkin('oxygen')
	LoadIconset('oxygen')
	return
	
