﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Security;
using Frontend.Models;
using DAL;
using DAL.Repositories;

namespace Frontend.Controllers
{
    [HandleError(ExceptionType = typeof(SecurityException), View = "SecurityError")]
    public class FilesController : BaseDALController
    {

        [OutputCache(Duration = 30, VaryByParam = "*", VaryByCustom = "user")]
        public ActionResult Directory()
        {
            var directory = getDirectory();
            if (directory == null)
                return RedirectToAction("LogOn", "Account");
            ViewData["isOwner"] = directory.Owner.Id == getUser().Id;
            if (Request.HttpMethod == "POST")
                return View("Directory", "~/Views/Shared/Ajax.master", directory);
            return View(directory);
        }

        [OutputCache(Duration = 30, VaryByParam = "*", VaryByCustom = "user")]
        public ActionResult File()
        {
            var file = getFile();
            if (file == null)
                return null;
            ViewData["isOwner"] = file.Directory.Owner.Id == getUser().Id;
            return View(file);
        }

        public ActionResult Download()
        {
            IFile file = getFile();
            if (!file.IsPublic && !Request.IsAuthenticated)
                throw new SecurityException();
            else if (file.IsPublic && getUser().Id != file.Directory.Owner.Id)
                throw new SecurityException();
            else
                return File(file.Content, "application/octet-stream", file.Name);
        }

        [Authorize]
        public ActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult Upload(HttpPostedFileBase file)
        {
            if (file != null)
            {
                MemoryStream ms = new MemoryStream(file.ContentLength);
                file.InputStream.CopyTo(ms);
                directories.CreateFile(getDirectory(checkWritePermission: true), file.FileName, ms.ToArray());
            }
            return RedirectToAction("Directory", new { id = getDirectory().Id });
        }

        [Authorize]
        public ActionResult CreateDirectory()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult CreateDirectory(DirectoryNameModel model)
        {
            var currentDirectory = getDirectory();
            if (ModelState.IsValid)
                directories.CreateSubdirectory(currentDirectory, model.Name);
            return RedirectToAction("Directory", new { id = currentDirectory.Id });
        }

        [HttpPost]
        [Authorize]
        public ActionResult RenameDirectory(IDirectory model)
        {
            var directory = getDirectory(checkWritePermission: true);
            if (ModelState.IsValid)
                directories.Rename(directory, model.Name);
            return RedirectToAction("Directory", new { id = directory.Parent.Id });
        }

        [Authorize]
        public ActionResult PublishDirectory()
        {
            var directory = getDirectory(checkWritePermission: true);
            directories.TogglePublic(directory);
            return RedirectToAction("Directory", new { id = directory.Parent.Id });
        }

        [Authorize]
        public ActionResult DeleteDirectory()
        {
            var directory = getDirectory(checkWritePermission: true);
            var redirectId = directory.Parent.Id;
            directories.Delete(directory);
            return RedirectToAction("Directory", new { id = redirectId });
        }

        [HttpPost]
        [Authorize]
        public ActionResult RenameFile(IFile model)
        {
            var file = getFile(checkWritePermission: true);
            if (ModelState.IsValid)
                files.Rename(file, model.Name);
            return RedirectToAction("Directory", new { id = file.Directory.Id });
        }

        [Authorize]
        public ActionResult PublishFile()
        {
            var file = getFile(checkWritePermission: true);
            files.TogglePublic(file);
            return RedirectToAction("Directory", new { id = file.Directory.Id });
        }

        [Authorize]
        public ActionResult DeleteFile()
        {
            var file = getFile(checkWritePermission: true);
            var redirectId = file.Directory.Id;
            files.Delete(file);
            return RedirectToAction("Directory", new { id = redirectId });
        }

        //--------------------------

        private IUser getUser()
        {
            try
            {
                return users.GetByEmail(User.Identity.Name);
            }
            catch (InvalidOperationException)
            {
                return users.GetAnonymous();
            }
        }

        private IDirectory getDirectory(bool checkWritePermission = false)
        {
            object directoryId = RouteData.Values["id"];
            var user = getUser();

            IDirectory directory = null;
            if (directoryId != null)
                directory = directories.GetById(int.Parse((string)directoryId));
            else
                if (user == users.GetAnonymous())
                    return null;
                else
                    directory = users.GetRootDirectory(user);
            if (directory.Owner.Id != user.Id && !directory.IsPublic)
                throw new SecurityException();
            if (checkWritePermission && directory.Owner.Id != user.Id)
                throw new SecurityException();
            return directory;
        }

        private IFile getFile(bool checkWritePermission = false)
        {
            object fileId = RouteData.Values["id"];
            var user = getUser();

            try
            {
                IFile file = files.GetById(int.Parse((string)fileId));
                if (file.Directory.Owner.Id != user.Id && !file.IsPublic)
                    throw new SecurityException();
                if (checkWritePermission && file.Directory.Owner.Id != user.Id)
                    throw new SecurityException();
                return file;
            }
            catch (FormatException) { return null; }
        }
    }
}
