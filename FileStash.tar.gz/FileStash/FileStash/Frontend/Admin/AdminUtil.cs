﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Security.Principal;
using System.Security;
using DAL;
using DAL.Repositories;

namespace Frontend
{
    public static class AdminUtil
    {
        public static bool IsAdmin(IPrincipal user)
        {
            try
            {
                if (DALConfig.Get<IUserRepository>().GetByEmail(user.Identity.Name).IsAdmin)
                    return true;
            }
            catch { }
            return false;
        }

        public static void VerifyAdminRights(IPrincipal user)
        {
            if (!IsAdmin(user))
                throw new SecurityException("Admin rights required");
        }
    }
}
