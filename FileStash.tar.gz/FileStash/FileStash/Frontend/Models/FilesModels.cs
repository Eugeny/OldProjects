﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace Frontend.Models
{
    public class DirectoryNameModel
    {
        [Required]
        [DisplayName("Name")]
        public string Name { get; set; }
    }

    public class UploadModel
    {
        [Required]
        [DisplayName("File")]
        public HttpPostedFileBase File { get; set; }
    }
}