﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.EF
{
    public static class Domain
    {
        private static DomainContainer domain = null;

        public static DomainContainer Instance
        {
            get
            {
                if (domain == null)
                    domain = new DomainContainer();
                return domain;
            }
        }
    }
}
