﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace DAL.EF
{
    public class Users : DAL.Repositories.IUserRepository
    {
        public IUser Anonymous = new User { Email = "" };

        public Users() { }

        public IDirectory GetRootDirectory(IUser self)
        {
            try
            {
                return Domain.Instance.Directories.Where(x => x.Parent == null).Where(x => x.Owner.Id == self.Id).First();
            }
            catch
            {
                Directory root = new Directory { Parent = null, Owner = (User)self };
                Domain.Instance.Users.Attach((User)self);
                Domain.Instance.Directories.AddObject(root);
                Domain.Instance.SaveChanges();
                return root;
            }
        }

        public IUser GetByEmail(string email)
        {
            return Domain.Instance.Users.First(x => x.Email == email);
        }

        public byte[] HashPassword(string password, byte[] salt)
        {
            byte[] passBytes = Encoding.UTF8.GetBytes(password);
            byte[] salted = new byte[passBytes.Length + salt.Length];
            Array.Copy(passBytes, salted, passBytes.Length);
            Array.Copy(salt, 0, salted, passBytes.Length, salt.Length);
            return SHA256.Create().ComputeHash(salted);
        }

        public bool CheckPassword(IUser self, string password)
        {
            byte[] hash = HashPassword(password, self.PasswordSalt);
            return Enumerable.SequenceEqual(hash, self.Password);
        }

        public IUser Create(string email, string password, bool admin)
        {
            User user = new User { Email = email, Role = new Role { IsAdmin = admin }, PasswordSalt = new byte[256] };
            new Random().NextBytes(user.PasswordSalt);
            user.Password = HashPassword(password, user.PasswordSalt);
            Domain.Instance.Users.AddObject(user);
            Domain.Instance.SaveChanges();
            return user;
        }

        public void Delete(IUser self)
        {
            Domain.Instance.DeleteObject(GetRootDirectory(self));
            Domain.Instance.DeleteObject((User)self);
            Domain.Instance.SaveChanges();
        }


        public IUser GetAnonymous()
        {
            return Anonymous;
        }
    }
}
