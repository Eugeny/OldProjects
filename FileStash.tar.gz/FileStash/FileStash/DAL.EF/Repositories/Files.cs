﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.EF
{
    public class Files : DAL.Repositories.IFileRepository
    {
        public Files() { }

        public IFile GetById(int id)
        {
            return Domain.Instance.Files.First(x => x.Id == id);
        }

        public void Rename(IFile file, string name)
        {
            ((File)file).Name = name;
            Domain.Instance.SaveChanges();
        }

        public void TogglePublic(IFile file)
        {
            ((File)file).IsPublic = !file.IsPublic;
            Domain.Instance.SaveChanges();
        }

        public void Delete(IFile file)
        {
            Domain.Instance.DeleteObject((File)file);
            Domain.Instance.SaveChanges();
        }
    }
}
