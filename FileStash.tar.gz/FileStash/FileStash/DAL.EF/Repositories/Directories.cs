﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.EF
{
    public class Directories : DAL.Repositories.IDirectoryRepository
    {
        public Directories() { }

        public IDirectory CreateSubdirectory(IDirectory self, string name)
        {
            Directory directory = new Directory { Parent = (Directory)self, Name = name, Owner = (User)self.Owner };
            Domain.Instance.Directories.AddObject((Directory)directory);
            Domain.Instance.SaveChanges();
            return directory;
        }

        public IFile CreateFile(IDirectory self, string name, byte[] content)
        {
            File IFile = new File { Directory = (Directory)self, Name = name, Content = content };
            Domain.Instance.Files.AddObject(IFile);
            Domain.Instance.SaveChanges();
            return IFile;
        }

        public IDirectory GetById(int id)
        {
            return Domain.Instance.Directories.First(x => x.Id == id);
        }

        public void Rename(IDirectory self, string name)
        {
            ((Directory)self).Name = name;
            Domain.Instance.SaveChanges();
        }

        public void TogglePublic(IDirectory self)
        {
            ((Directory)self).IsPublic = !self.IsPublic;
            Domain.Instance.SaveChanges();
        }

        public void Delete(IDirectory self)
        {
            Domain.Instance.DeleteObject(self);
            Domain.Instance.SaveChanges();
        }
    }
}
