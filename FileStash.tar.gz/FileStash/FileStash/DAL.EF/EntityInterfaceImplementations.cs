﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.EF
{
    public partial class User : IUser
    {
        public IEnumerable<IDirectory> DirectoriesList { get { return Directories; } }


        public bool IsAdmin
        {
            get { return Role.IsAdmin; }
        }
    }


    public partial class Directory : IDirectory
    {
        public IEnumerable<IDirectory> SubdirectoriesList { get { return Subdirectories; } }
        public IEnumerable<IFile> FilesList { get { return Files; } }
        IUser IDirectory.Owner { get { return this.OwnerReference.Value; } }
        IDirectory IDirectory.Parent { get { return this.ParentReference.Value; } }
    }


    public partial class File : IFile
    {
        IDirectory IFile.Directory { get { return DirectoryReference.Value; } }
    }
}
