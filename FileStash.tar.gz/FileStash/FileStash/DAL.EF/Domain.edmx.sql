
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 09/21/2012 12:30:34
-- Generated from EDMX file: D:\FileStash\FileStash\DAL\Domain.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [FileStash];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_UserDirectory]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Directories] DROP CONSTRAINT [FK_UserDirectory];
GO
IF OBJECT_ID(N'[dbo].[FK_DirectoryDirectory]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Directories] DROP CONSTRAINT [FK_DirectoryDirectory];
GO
IF OBJECT_ID(N'[dbo].[FK_DirectoryFile]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Files] DROP CONSTRAINT [FK_DirectoryFile];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Users]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Users];
GO
IF OBJECT_ID(N'[dbo].[Directories]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Directories];
GO
IF OBJECT_ID(N'[dbo].[Files]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Files];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Users'
CREATE TABLE [dbo].[Users] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Email] nvarchar(max)  NOT NULL,
    [Password] varbinary(max)  NOT NULL,
    [PasswordSalt] varbinary(max)  NOT NULL,
    [Role_IsAdmin] bit  NOT NULL
);
GO

-- Creating table 'Directories'
CREATE TABLE [dbo].[Directories] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NULL,
    [IsPublic] bit  NOT NULL,
    [Owner_Id] int  NOT NULL,
    [Parent_Id] int  NULL
);
GO

-- Creating table 'Files'
CREATE TABLE [dbo].[Files] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [IsPublic] bit  NOT NULL,
    [Content] varbinary(max)  NOT NULL,
    [Directory_Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [PK_Users]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Directories'
ALTER TABLE [dbo].[Directories]
ADD CONSTRAINT [PK_Directories]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Files'
ALTER TABLE [dbo].[Files]
ADD CONSTRAINT [PK_Files]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Owner_Id] in table 'Directories'
ALTER TABLE [dbo].[Directories]
ADD CONSTRAINT [FK_UserDirectory]
    FOREIGN KEY ([Owner_Id])
    REFERENCES [dbo].[Users]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_UserDirectory'
CREATE INDEX [IX_FK_UserDirectory]
ON [dbo].[Directories]
    ([Owner_Id]);
GO

-- Creating foreign key on [Parent_Id] in table 'Directories'
ALTER TABLE [dbo].[Directories]
ADD CONSTRAINT [FK_DirectoryDirectory]
    FOREIGN KEY ([Parent_Id])
    REFERENCES [dbo].[Directories]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DirectoryDirectory'
CREATE INDEX [IX_FK_DirectoryDirectory]
ON [dbo].[Directories]
    ([Parent_Id]);
GO

-- Creating foreign key on [Directory_Id] in table 'Files'
ALTER TABLE [dbo].[Files]
ADD CONSTRAINT [FK_DirectoryFile]
    FOREIGN KEY ([Directory_Id])
    REFERENCES [dbo].[Directories]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DirectoryFile'
CREATE INDEX [IX_FK_DirectoryFile]
ON [dbo].[Files]
    ([Directory_Id]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------