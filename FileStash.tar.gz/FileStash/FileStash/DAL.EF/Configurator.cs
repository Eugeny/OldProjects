﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using DAL.Repositories;
using Ninject;

namespace DAL.EF
{
    public class Configurator : IConfigurator
    {
        public void Configure(IKernel kernel)
        {
            kernel.Bind<IDirectoryRepository>().To<Directories>();
            kernel.Bind<IFileRepository>().To<Files>();
            kernel.Bind<IUserRepository>().To<Users>();
        }
    }
}
