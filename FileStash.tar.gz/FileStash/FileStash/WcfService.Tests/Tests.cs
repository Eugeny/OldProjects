﻿using System;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WcfService.Tests
{
    [TestClass]
    public class Tests
    {
        private WcfServiceReference.FileStorageServiceClient client;

        [TestInitialize]
        public void Init()
        {
            client = new WcfServiceReference.FileStorageServiceClient();
            client.Open();
            client.LogOn("test", "123456");
        }

        [TestCleanup]
        public void Finish()
        {
            client.Close();
        }

        [TestMethod]
        public void TestLogon()
        {
            Assert.IsFalse(client.LogOn("test", ""));
            Assert.IsTrue(client.LogOn("test", "123456"));
        }

        [TestMethod]
        public void TestDirectoryOperations()
        {
            int len = client.ListDirectories(null).Length;
            int newId = client.CreateDirectory(null, "test");
            Assert.AreEqual(len + 1, client.ListDirectories(null).Length);
            Assert.AreEqual(client.ListDirectories(null)[len].Name, "test");
            client.DeleteDirectory(newId);
            Assert.AreEqual(client.ListDirectories(null).Length, len);
        }

        [TestMethod]
        public void TestFileOperations()
        {
            int dirId = client.CreateDirectory(null, "test");
            byte[] content = Encoding.UTF8.GetBytes("TEST");
            int fileId = client.CreateFile(dirId, "test", content);
            Assert.IsTrue(client.ListFiles(dirId)[0].Content.SequenceEqual(content));
            client.DeleteDirectory(dirId);
        }
    }
}
