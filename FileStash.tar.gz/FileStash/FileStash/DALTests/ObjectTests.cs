﻿using System;
using System.Text;
using System.Linq;
using System.Data.Entity;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DAL;
using DAL.Repositories;

namespace DALTests
{
    [TestClass]
    public class ObjectTests
    {
        IUserRepository users;
        IFileRepository files;
        IDirectoryRepository directories;

        [TestInitialize]
        public void Init()
        {
            DALConfig.Configure(new DAL.EF.Configurator());
            try { new DAL.EF.DomainContainer().DeleteDatabase(); }
            catch { }
            new DAL.EF.DomainContainer().CreateDatabase();
            users = DALConfig.Get<IUserRepository>();
            files = DALConfig.Get<IFileRepository>();
            directories = DALConfig.Get<IDirectoryRepository>();
        }

        [TestMethod]
        public void TestUserCRUD()
        {
            IUser user = users.Create("qwe", "rty", false);
            try
            {
                users.GetByEmail("qwe");
            }
            catch
            {
                Assert.Fail();
            }
            users.Delete(user);
            try
            {
                users.GetByEmail("qwe");
                Assert.Fail();
            }
            catch
            {
            }
        }

        [TestMethod]
        public void TestUserPassword()
        {
            IUser user = users.Create("qwe", "rty", false);
            Assert.IsTrue(users.CheckPassword(user, "rty"));
            Assert.IsFalse(users.CheckPassword(user, "rty1"));
            users.Delete(user);
        }

        [TestMethod]
        public void TestDirectoryCRUD()
        {
            IUser user = users.Create("qwe", "rty", false);
            IDirectory root = users.GetRootDirectory(user);
            IDirectory sub = directories.CreateSubdirectory(root, "test");
            Assert.IsTrue(root.SubdirectoriesList.Contains(sub));
            Assert.IsTrue(users.GetRootDirectory(user).SubdirectoriesList.Count() == 1);

            directories.Rename(sub, "123");
            Assert.AreEqual<string>("123", sub.Name);

            directories.Delete(sub);
            Assert.IsTrue(root.SubdirectoriesList.Count() == 0);
            users.Delete(user);
        }

        [TestMethod]
        public void TestFileCRUD()
        {
            IUser user = users.Create("qwe", "rty", false);
            byte[] content = new byte[256];
            new Random().NextBytes(content);
            IFile file = directories.CreateFile(users.GetRootDirectory(user), "test.txt", content);
            Assert.IsTrue(users.GetRootDirectory(user).FilesList.First().Name == "test.txt");
            Assert.IsTrue(users.GetRootDirectory(user).FilesList.First().Content.SequenceEqual(content));
            files.Delete(file);
            Assert.IsTrue(users.GetRootDirectory(user).FilesList.Count() == 0);
            users.Delete(user);
        }

        [TestMethod]
        public void TestFilePublishing()
        {
            IUser user = users.Create("qwe", "rty", false);
            byte[] content = new byte[256];
            new Random().NextBytes(content);
            IFile file = directories.CreateFile(users.GetRootDirectory(user), "test.txt", content);
            files.TogglePublic(file);
            Assert.IsTrue(file.IsPublic);
            files.TogglePublic(file);
            Assert.IsFalse(file.IsPublic);
            users.Delete(user);
        }


        [TestMethod]
        public void TestDirectoryPublishing()
        {
            IUser user = users.Create("qwe", "rty", false);
            byte[] content = new byte[256];
            new Random().NextBytes(content);
            Assert.IsFalse(users.GetRootDirectory(user).IsPublic);
            directories.TogglePublic(users.GetRootDirectory(user));
            Assert.IsTrue(users.GetRootDirectory(user).IsPublic);
            directories.TogglePublic(users.GetRootDirectory(user));
            Assert.IsFalse(users.GetRootDirectory(user).IsPublic);
            users.Delete(user);
        }
    }
}
