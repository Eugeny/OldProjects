﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace DAL
{
    public interface IDirectory
    {
        Int32 Id { get; }
        String Name { get; }
        Boolean IsPublic { get; }
        IUser Owner { get; }
        IEnumerable<IDirectory> SubdirectoriesList { get; }
        IDirectory Parent { get; }
        IEnumerable<IFile> FilesList { get; }
    }

    public interface IFile
    {
        Int32 Id { get; }
        String Name { get; }
        Boolean IsPublic { get; }
        Byte[] Content { get; }
        IDirectory Directory { get; }
    }

    public interface IUser
    {
        Int32 Id { get; }
        String Email { get; }
        Byte[] Password { get; }
        Byte[] PasswordSalt { get; }
        IEnumerable<IDirectory> DirectoriesList { get; }
        bool IsAdmin { get; }
    }

}
