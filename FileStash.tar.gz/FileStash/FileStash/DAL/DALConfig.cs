﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ninject;
using DAL.Repositories;

namespace DAL
{
    public static class DALConfig
    {
        private static IKernel kernel;

        public static void Configure(IConfigurator configurator)
        {
            kernel = new StandardKernel();
            configurator.Configure(kernel);
        }

        public static T Get<T>()
        {
            return kernel.Get<T>();
        }
    }
}
