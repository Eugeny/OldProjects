﻿using System;
namespace DAL.Repositories
{
    public interface IFileRepository
    {
        void Delete(IFile self);
        IFile GetById(int id);
        void Rename(IFile self, string name);
        void TogglePublic(IFile self);
    }
}
