﻿using System;
namespace DAL.Repositories
{
    public interface IDirectoryRepository
    {
        IFile CreateFile(IDirectory self, string name, byte[] content);
        IDirectory CreateSubdirectory(IDirectory self, string name);
        void Delete(IDirectory self);
        IDirectory GetById(int id);
        void Rename(IDirectory self, string name);
        void TogglePublic(IDirectory self);
    }
}
