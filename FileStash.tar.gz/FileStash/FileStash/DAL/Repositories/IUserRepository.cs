﻿using System;
namespace DAL.Repositories
{
    public interface IUserRepository
    {
        bool CheckPassword(IUser self, string password);
        IUser Create(string email, string password, bool admin);
        void Delete(IUser self);
        IUser GetByEmail(string email);
        IDirectory GetRootDirectory(IUser self);
        byte[] HashPassword(string password, byte[] salt);

        IUser GetAnonymous();
    }
}
