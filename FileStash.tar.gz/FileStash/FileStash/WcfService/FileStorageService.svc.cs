﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using DAL;
using DAL.Repositories;

namespace WcfService
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class FileStorageService : IFileStorageService
    {
        private string token;
        private IUser user;
        private static IDirectoryRepository directories;
        private static IFileRepository files;
        private static IUserRepository users;

        static FileStorageService()
        {
            DALConfig.Configure(new DAL.EF.Configurator());
            directories = DALConfig.Get<IDirectoryRepository>();
            files = DALConfig.Get<IFileRepository>();
            users = DALConfig.Get<IUserRepository>();
        }

        public bool LogOn(string email, string password)
        {
            user = Auth.LogOn(email, password);
            return user != null;
        }


        public List<FileInfo> ListFiles(int? directoryId)
        {
            IDirectory dir = (directoryId.HasValue) ? directories.GetById(directoryId.Value) : users.GetRootDirectory(user);
            var result = new List<FileInfo>();
            foreach (IFile file in dir.FilesList)
                result.Add(new FileInfo(file));
            return result;
        }

        public List<DirectoryInfo> ListDirectories(int? directoryId)
        {
            IDirectory dir = (directoryId.HasValue) ? directories.GetById(directoryId.Value) : users.GetRootDirectory(user);
            var result = new List<DirectoryInfo>();
            foreach (IDirectory file in dir.SubdirectoriesList)
                result.Add(new DirectoryInfo(file));
            return result;
        }

        public int CreateDirectory(int? parentId, string name)
        {
            IDirectory parent = (parentId.HasValue) ? directories.GetById(parentId.Value) : users.GetRootDirectory(user);
            return directories.CreateSubdirectory(parent, name).Id;
        }

        public int CreateFile(int? parentId, string name, byte[] content)
        {
            IDirectory parent = (parentId.HasValue) ? directories.GetById(parentId.Value) : users.GetRootDirectory(user);
            return directories.CreateFile(parent, name, content).Id;
        }

        public void DeleteDirectory(int id)
        {
            directories.Delete(directories.GetById(id));
        }

        public void DeleteFile(int id)
        {
            files.Delete(files.GetById(id));
        }
    }
}
