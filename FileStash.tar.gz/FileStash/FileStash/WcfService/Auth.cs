﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DAL;
using DAL.Repositories;

namespace WcfService
{
    public static class Auth
    {
        private static IUserRepository userRepository;

        static Auth()
        {
            DALConfig.Configure(new DAL.EF.Configurator());
            userRepository = DALConfig.Get<IUserRepository>();
        }

        public static IUser LogOn(string email, string password)
        {
            IUser user = userRepository.GetByEmail(email);
            if (userRepository.CheckPassword(user, password))
            {
                return user;
            }
            return null;
        }
    }
}