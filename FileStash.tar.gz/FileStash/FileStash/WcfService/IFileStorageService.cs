﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService {
    [ServiceContract(SessionMode=SessionMode.Required)]
    public interface IFileStorageService
    {
        [OperationContract]
        bool LogOn(string email, string password);

        [OperationContract]
        List<FileInfo> ListFiles(int? directoryId);

        [OperationContract]
        List<DirectoryInfo> ListDirectories(int? directoryId);

        [OperationContract]
        int CreateDirectory(int? parentId, string name);

        [OperationContract]
        int CreateFile(int? parentId, string name, byte[] content);

        [OperationContract]
        void DeleteDirectory(int id);

        [OperationContract]
        void DeleteFile(int id);
    }
}
