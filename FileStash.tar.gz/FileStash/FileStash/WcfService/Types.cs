﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using DAL;

namespace WcfService
{
    [DataContract]
    public class FileInfo
    {
        public FileInfo(IFile file) {
            DirectoryId = file.Directory.Id;
            Name = file.Name;
            Content = file.Content;
        }

        [DataMember]
        public int DirectoryId;

        [DataMember]
        public string Name;

        [DataMember]
        public byte[] Content;
    }

    [DataContract]
    public class DirectoryInfo
    {
        public DirectoryInfo(IDirectory directory)
        {
            Name = directory.Name;
            DirectoryId = (directory.Parent == null) ? ((int?)null) : directory.Parent.Id;
            OwnerId = directory.Owner.Id;
        }

        [DataMember]
        public int OwnerId;

        [DataMember]
        public int? DirectoryId;

        [DataMember]
        public string Name;
    }
}