#!/usr/bin/env python
import subprocess
import sys
import options
import lib
import os
import memcache

u, r = sys.argv[1], sys.argv[2]
rf = os.path.join(options.REPOSITORY_LOCATION, u, r)
open('/tmp/log','w').write(repr(sys.argv))

up, i = lib.get_uib(u, r)
if up:
    uf = os.path.join(options.REPOSITORY_LOCATION, up, r)

lib.emit_push_news(u,r)


subprocess.Popen(['git', '--git-dir='+rf+'.git', 'checkout', i], cwd=rf).wait()
subprocess.Popen(['git', '--git-dir='+rf+'.git', 'clean', '-f', '-d'], cwd=rf).wait()
subprocess.Popen(['git', '--git-dir='+rf+'.git', 'reset', '--hard'], cwd=rf).wait()

mc = memcache.Client(['localhost:11211'], debug=0)
mc.delete('namespace:'+u+ ':'+r)
if up:
    mc.delete('namespace:'+up+':'+r)

if not up:
    sys.exit(0)

subprocess.Popen(['git', '--git-dir='+uf+'.git', 'remote', 'add', u, rf + '.git'], cwd=uf).wait()
subprocess.Popen(['git', '--git-dir='+uf+'.git', 'fetch', u], cwd=uf).wait()


