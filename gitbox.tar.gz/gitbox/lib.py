from datetime import *
import MySQLdb
import MySQLdb.converters
import options

db = MySQLdb.connect(**options.DB)
cur = db.cursor()

def Long2Str(s, d):
    return str(int(s))

converter = MySQLdb.converters.conversions
converter[long] = Long2Str

def get_uib(user, repo):
    cur.execute('SELECT id FROM auth_user WHERE username=%s', (user))
    uid = cur.fetchone()[0]
    cur.execute('SELECT upstream_id, integration FROM main_repository WHERE user_id=%s AND name=%s', (int(uid), repo))
    u,i = cur.fetchone()
    if not u:
        return None, i
    cur.execute('SELECT user_id FROM main_repository WHERE id=%s', int(u))
    u = cur.fetchone()[0]
    cur.execute('SELECT username FROM auth_user WHERE id=%s', int(u))
    return cur.fetchone()[0], i

def emit_push_news(user, repo):
    cur.execute('SELECT id FROM auth_user WHERE username=%s', (user))
    uid = cur.fetchone()[0]
    cur.execute('SELECT id FROM main_repository WHERE user_id=%s AND name=%s', (int(uid), repo))
    i = cur.fetchone()[0]
    cur.execute('INSERT INTO main_news SET subject_id=%s, objekt=%s, objekt_type=\'Repository\', date=%s, action=\'push\'', (uid, i, datetime.now()))

def check_access(user, repo, who):
    cur.execute('SELECT id FROM auth_user WHERE username=%s', (user))
    uid = cur.fetchone()[0]
    cur.execute('SELECT id FROM auth_user WHERE username=%s', (who))
    wid = cur.fetchone()[0]
    repo = repo.rsplit('.')[0]
    cur.execute('SELECT id, private FROM main_repository WHERE user_id=%s AND name=%s', (int(uid), repo))
    rid, priv = cur.fetchone()
    
    r = True
    w = False
    if priv:
        r = False
        w = False
        
    try:
        cur.execute('SELECT `read`, `write` FROM main_permission WHERE repository_id=%s', (int(rid)))
        r, w = cur.fetchone()
    except:
        pass
        
    if user == who:
        r = True
        w = True

    return r,w
    
