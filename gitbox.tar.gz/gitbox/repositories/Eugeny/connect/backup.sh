#!/bin/sh
mysqldump -u root -p bsuir > db
