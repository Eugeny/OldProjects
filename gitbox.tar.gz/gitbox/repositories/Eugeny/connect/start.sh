#!/bin/sh
1cd connect; ./manage.py runserver
