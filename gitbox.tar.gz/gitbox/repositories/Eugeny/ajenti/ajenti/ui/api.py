from ajenti.com import Interface


class IXSLTFunctionProvider(Interface):
    def get_funcs(self):
        pass

