from ajenti.com import Interface


class IDashboardWidget(Interface):
    def get_ui(self):
        pass
