function shellRecentClick() {
    document.getElementById("shell-command").value = document.getElementById("shell-recent").value;
}
