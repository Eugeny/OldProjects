from ajenti.app.plugins import require
require('sql')

from main import *
