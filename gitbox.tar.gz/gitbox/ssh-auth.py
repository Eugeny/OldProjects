#!/usr/bin/env python
import sys
import os
import subprocess

import options

import lib

user = sys.argv[1]

orig_command = os.getenv('SSH_ORIGINAL_COMMAND')

if not orig_command:
    print 'Hello %s! Sorry, but there\'s no shell access available.\n' % user
    sys.exit(1)
    
open('/gitbox/log','a').write('%s %s\n' % (sys.argv[1], orig_command))

u, r = orig_command.split()[1].split('/')
u = u.strip('\'')
r = r.strip('\'')
gitcmd = orig_command.split()[0]

r,w = lib.check_access(u,r,user)

if gitcmd.startswith('git-upload') and not r:
    sys.exit(1)
if gitcmd.startswith('git-receive') and not w:
    sys.exit(1)
    
subprocess.Popen(
    'git shell -c "%s"' % orig_command, 
    shell=True, 
    cwd=options.REPOSITORY_LOCATION
).wait()
