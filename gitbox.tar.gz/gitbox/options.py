GITBOX_LOCATION = '/gitbox/'
REPOSITORY_LOCATION = GITBOX_LOCATION + 'repositories/'
KEYS_LOCATION = GITBOX_LOCATION + 'keys/'
KEYFILE_LOCATION = GITBOX_LOCATION + '.ssh/authorized_keys'
GITBOX_SITE_PATH = '/gitbox-site'

DB = {
    'host': 'localhost',
    'user': 'root',
    'passwd': '123',
    'db': 'gitbox'
}
