import subprocess
import os


class State:
	tasks = []
	valac_opts = ''
	valac_packages = []
	fvapis = {}


class BuildError (Exception):
	def __str__(self):
		return 'Build failed'


class Task:
	def __init__(self):
		self.depends = []

	def depend(self, task):
		self.depends += [task]

	def needs_run(self):
		return True
	
	def can_run(self):
		return not any([x.needs_run() in State.tasks for x in self.depends])

	def run(self):
		pass


class FileTransformationTask (Task):
	def __init__(self):
		Task.__init__(self)
		self.src = None
		self.dest = None

	def needs_run(self):
		return (not os.path.exists(self.dest)) or \
			(os.path.getmtime(self.dest) < os.path.getmtime(self.src))


class FVAPITask (FileTransformationTask):
	def __init__(self):
		FileTransformationTask.__init__(self)
		self.options = None

	def run(self):
		log('valac', 'Reading ' + self.src)
		args = ['valac']
		args += State.valac_opts
		for pkg in State.valac_packages:
			args += ['--pkg', pkg]
		args += ['--fast-vapi', self.dest, self.src]
		if subprocess.call(args) != 0:
			raise BuildError()
		os.utime(self.dest, None)


class CompilationTask (FileTransformationTask):
	def __init__(self):
		FileTransformationTask.__init__(self)
		self.options = None
		self.deps = None

	def needs_run(self):
		if FileTransformationTask.needs_run(self):
			return True

		depsfile = os.path.splitext(self.dest)[0] + '.deps'
		if os.path.exists(depsfile):
			deps = open(depsfile).read().split(':', 1)[1].strip().split()
			for dep in deps:
				if os.path.getmtime(dep) > os.path.getmtime(self.dest):
					return True
		return False

	def can_run(self):
		if not FileTransformationTask.can_run(self):
			return False

		return not any([isinstance(x,FVAPITask) and x.needs_run() for x in State.tasks])

	def run(self):
		log('valac', 'Compiling ' + self.src)
		args = ['valac']
		args += State.valac_opts
		for pkg in State.valac_packages:
			args += ['--pkg', pkg]
		for fvapi in State.fvapis.keys():
			if fvapi != self.src:
				args += ['--use-fast-vapi', State.fvapis[fvapi]]
		args += ['-C', '-d', os.path.split(self.dest)[0], '-b', 'src', '--deps', self.deps, self.src]
		if subprocess.call(args) != 0:
			raise BuildError()
		os.utime(self.dest, None)


class BuildTask (Task):
	def __init__(self):
		self.srcs = None
		self.dest = None

	def needs_run(self):
		if not os.path.exists(self.dest):
			return True
		for s in self.srcs:
			if os.path.getmtime(self.dest) < os.path.getmtime(s):
				return True
		return False

	def can_run(self):
		return not any([isinstance(x,CompilationTask) and x.needs_run() for x in State.tasks])

	def run(self):
		log('valac', 'Building ' + self.dest)
		args = ['valac']
		args += State.valac_opts
		for pkg in State.valac_packages:
			args += ['--pkg', pkg]
		args += ['-o', self.dest]
		args += self.srcs
		if subprocess.call(args) != 0:
			raise BuildError()
		os.utime(self.dest, None)


def prepare_env():
	dirs = ['bin', 'build', 'vapi']
	for d in dirs:
		if not os.path.exists(d):
			log('vake', 'Creating ' + d + '/')
			os.mkdir(d)

def log(tag, text):
	print ' ' + tag.rjust(8) + ' | ' + text

def cflags(flags):
	State.valac_opts = flags

def use_package(*pkgs):
	State.valac_packages += pkgs

def compile(src, dest=None):
	if dest is None:
		dest = src.rsplit('.', 1)[0] + '.o'
	
	task = FVAPITask()
	task.src = 'src/'+src
	task.dest = 'vapi/' + src.rsplit('.', 1)[0] + '.vapi'
	State.fvapis['src/'+src] = task.dest
	ftask = task
	State.tasks.append(task)
	
	task = CompilationTask()
	task.src = 'src/'+src
	task.dest = 'build/' + src.rsplit('.', 1)[0] + '.c'
	task.deps = 'build/' + src.rsplit('.', 1)[0] + '.deps'
	task.depend(ftask)
	State.tasks.append(task)

def build(srcs, dest):
	task = BuildTask()
	task.srcs = ['build/'+os.path.splitext(x)[0]+'.c' for x in srcs]
	task.dest = dest
	State.tasks.append(task)	