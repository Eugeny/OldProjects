import os

DB_FILE = '/var/lib/uzuri.db'


class DB:
    def __init__(self):
        if not os.path.exists(DB_FILE):
            open(DB_FILE, 'w').close()
            
        self.sets = {}
        
        data = open(DB_FILE, 'r').read().split('\n')
        cset = None
        for l in data:
            if len(l) > 0:
                try:
                    if l.startswith('*'):
                        cset = ConfigSet(l[1:])
                        self.sets[cset.name] = cset
                    else:
                        cset.files[l] = File(l)
                except:
                    pass
        
    def save(self):
        d = ''
        for cset in self.sets.values():
            d += '*%s\n'%cset.name
            for f in cset.files.values():
                d += '%s\n'%f.name
        open(DB_FILE, 'w').write(d)
        
                
class ConfigSet:
    def __init__(self, name):
        self.name = name
        self.files = {}
        
        
class File:
    def __init__(self, name):
        self.name = name
        self.new = False
       
