from twisted.internet.protocol import Protocol, Factory
from twisted.internet.endpoints import TCP4ServerEndpoint
from twisted.internet import reactor
import logging
import random 
import os
import pickle
from StringIO import StringIO

from proto import *
from db import *


global log
log = None


class Agent:
    def __init__(self):
        global log
        log = logging.getLogger('uzuri-agent')
        log.setLevel(logging.DEBUG)
        sh = logging.StreamHandler()
        sh.setLevel(logging.DEBUG)
        fmt = logging.Formatter('%(asctime)s %(levelname)-6s %(module)s.%(funcName)s: %(message)s')
        sh.setFormatter(fmt)
        log.addHandler(sh)
            
    def run(self):
        log.info('Agent started')
        factory = Factory()
        factory.protocol = AgentProtocol
        endpoint = TCP4ServerEndpoint(reactor, 8008)
        endpoint.listen(factory)
        reactor.run()
       
       
class AgentProtocol (Protocol):
    def __init__(self):
        self.awaiting = None
        self.rcv_obj = False
        self.db = None
                
    def connectionMade(self):
        self.authenticated = False
        self.transport.write(SCMD_AUTH_REQ)
        self.transport.write(AUTH_SSH_FILE)
        self.challenge = random.randint(0,255)
        self.transport.write(chr(self.challenge))
        log.info('Connected: %s' % str(self.transport.client))
        
    def startObject(self):
        self.rcv_obj = True
        self.buf = ''
        
    def dataReceived(self, data):
        while len(data) > 0:
            if self.rcv_obj:
                self.buf += data
                break
                
            cmd = data[0]
            if self.awaiting is None:
                if cmd == CCMD_AUTH_DONE:
                    cf = '/tmp/uzuri-auth-%i'%self.challenge
                    if os.path.exists(cf):
                        self.authenticated = True
                        log.info('Client authenticated')
                        self.transport.write(SCMD_AUTH_COMPLETE)
                        os.unlink(cf)
                    else:
                        log.warn('Failed authentication')
                        self.transport.write(SCMD_AUTH_FAIL)
                        self.transport.loseConnection()
                    del self.challenge
                if cmd == CCMD_RCV_OBJECT:
                    self.startObject()
            data = data[1:]
            
        if self.rcv_obj:
            if len(self.buf) > 4:
                l = 0 
                for i in range(0,4):
                    l *= 256
                    l += ord(self.buf[i])
                if len(self.buf) >= 4 + l:
                    self.rcv_obj = False
                    sio = StringIO(self.buf[4:])
                    obj = pickle.Unpickler(sio).load()
                    sio.close()
                    self.objectReceived(obj)
                    self.dataReceived(self.buf[l+4:])
            
    def openDB(self):
        if self.db is None:
            self.db = DB()
        return self.db
                    
    def objectReceived(self, obj):
        try:
            db = self.openDB()
            if obj[0] == CCMD_RCV_FILE:
                cset = obj[1]
                if not cset in db.sets:
                    db.sets[cset] = ConfigSet(cset)
                cset = db.sets[cset]
                path = obj[2]
                cset.files[path] = File(path)
                cset.files[path].new = True
                data = obj[3]
                open(path, 'w').write(data)
                self.transport.write(SCMD_ACK)
                log.info('Received %s [%s]'%(path,cset.name))
            elif obj[0] == CCMD_COMMIT:
                cset = obj[1]
                if not cset in db.sets:
                    db.sets[cset] = ConfigSet(cset)
                cset = db.sets[cset]
                for f in cset.files.values():
                    if not f.new:
                        os.unlink(f.name)
                        log.info('Removed %s'%f.name)
                    f.new = False
                db.save()
                self.transport.write(SCMD_ACK)
                log.info('Commited %s'%cset.name)
            else:
                self.transport.write(SCMD_FAIL)
                self.transport.loseConnection()
                log.err('Unknown command')
        except Exception, e:
            self.transport.write(SCMD_FAIL)
            self.transport.loseConnection()
            log.error('Processing error')
            raise
            print e
            
