#!/usr/bin/env python

from distutils.core import setup
from setuptools import find_packages

setup(
    name='Uzuri agent',
    version='0.1',
    description='Cluster control agent',
    author='Eugeny Pankov',
    author_email='e@ajenti.org',
    url='http://ajenti.org/',
    packages = find_packages(),
    scripts=['uzuri-agent'],
    data_files=[
        ('/etc/init.d', ['packaging/uzuri-agent']),
    ],
)
