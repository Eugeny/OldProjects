SCMD_AUTH_REQ = chr(100)
SCMD_AUTH_FAIL = chr(102)
SCMD_AUTH_COMPLETE = chr(103)
SCMD_FAIL = chr(104)
SCMD_ACK = chr(105)

AUTH_SSH_FILE = chr(1)

CCMD_AUTH_DONE = chr(100)
CCMD_RCV_OBJECT = chr(101)
CCMD_RCV_FILE = chr(102)
CCMD_COMMIT = chr(103)


"""
>> client
<< server

<< SCMD_AUTH_REQ
<< AUTH_SSH_FILE
<< <auth challenge byte>
.. clients performs SSH auth
>> CCMD_AUTH_DONE
<< SCMD_AUTH_COMPLETE || SCMD_AUTH_FAIL
>> CCMD_RCV_OBJECT
>> <4-byte data length>
>> <pickled command object>
<< SCMD_ACK || SCMD_FAIL
"""
