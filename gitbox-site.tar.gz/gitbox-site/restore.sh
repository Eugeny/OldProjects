#!/bin/sh
mysqladmin -u root -p drop gitbox
mysqladmin -u root -p create gitbox --default-character-set=utf8
mysql -u root -p gitbox < db
