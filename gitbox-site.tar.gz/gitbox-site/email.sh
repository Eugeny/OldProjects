#!/bin/bash
python -m smtpd -n -c DebuggingServer localhost:1025
