import mimetypes


def parse(diff):
    r = Diff()
    f = None
    ll = diff
    
    hdr = True
    line = None
    
    fidx = 1
    lidx = 1

    if len(ll) == 0:
        return r
            
    while len(ll) > 0 and ll[0] == '':
        ll = ll[1:]
        
    for l in ll:
        if l.startswith('diff'):
            hdr = True
            if f:
                r.files.append(f)
                lidx = 1
                fidx += 1
            f = File()
            f.idx = str(fidx)
            f.name = l.split(' ')[2][2:]
        elif l.startswith('new'):
            f.created = True
        elif l.startswith('deleted'):
            f.deleted = True
        elif l.startswith('Binary'):
            f.binary = True
            try:
                f.image = 'image' in mimetypes.guess_type(f.name, False)[0]
            except:
                pass
        elif l.startswith('@@'):
            line = Line(l)
            line.idxa = ''
            line.idxb = ''
            line.idx = lidx
            lidx += 1
            line.cls = 'diff-hunk'
            f.lines.append(line)
            l = l.split()
            idxa = int(l[1].split(',')[0].strip('-+ '))
            idxb = int(l[2].split(',')[0].strip('-+ '))
        elif (l.startswith('+++') or l.startswith('---')):
            hdr = False
        elif l.startswith('+'):
            line = Line()
            line.idxb = idxb
            line.idxa = ''
            line.idx = lidx
            line.cls = 'diff-plus'
            idxb += 1
            lidx += 1
            line.text = l
            f.lines.append(line)
        elif l.startswith('-'):
            line = Line()
            line.idxa = idxa
            line.idxb = ''
            line.idx = lidx
            line.cls = 'diff-minus'
            idxa += 1
            lidx += 1
            line.text = l
            f.lines.append(line)
        elif l.startswith(' '):
            line = Line()
            line.idxa = idxa
            line.idxb = idxb
            line.idx = lidx
            line.cls = ''
            idxa += 1
            idxb += 1
            lidx += 1
            line.text = l
            f.lines.append(line)
        if line:
            line.idxa = str(line.idxa)
            line.idxb = str(line.idxb)
            line.idx = str(line.idx)
    if f:
        r.files.append(f)
    return r
    
    
class Diff:
    def __init__(self):
        self.files = []
    
    def apply_notes(self, notes):
        for n in notes:
            for f in self.files:
                if f.name == n.file:
                    try:
                        f.lines[n.line-1].notes.append(n)
                    except:
                        pass
                    
        
class File:
    def __init__(self):
        self.name = ''
        self.lines = []
        self.binary = False
        self.image = False
        self.created = False
        self.deleted = False
        
        
class Line:
    def __init__(self, text=''):
        self.idxa = None
        self.idxb = None
        self.idx = None
        self.text = text
        self.notes = []

