import os
import sys
import subprocess
import shutil
import settings

    
def repo_exists(u, r):
    if os.path.exists(os.path.join(settings.REPOSITORY_LOCATION, u, r+'.git')):
        if len(os.listdir(os.path.join(settings.REPOSITORY_LOCATION, u, r+'.git', 'refs', 'heads'))) == 0:
            return 2
        return 1
    return 0

def repo_add(u, r):
    if repo_exists(u, r) == 0:
        up = os.path.join(settings.REPOSITORY_LOCATION, u)
        if not os.path.exists(up):
            os.mkdir(up)
        p = os.path.join(up, r)
        os.mkdir(p)
        subprocess.Popen(['git', 'init'], cwd=p).wait()
        repo_setup(u, r)

def repo_clone(u, r, o):
    if repo_exists(u, r) == 0:
        up = os.path.join(settings.REPOSITORY_LOCATION, u)
        if not os.path.exists(up):
            os.mkdir(up)
        p = os.path.join(up, r)
        upstream = os.path.join(settings.REPOSITORY_LOCATION, o, r+'.git')
        os.mkdir(p)
        subprocess.Popen(['git', 'clone', upstream], cwd=up).wait()
        repo_setup(u, r)

def repo_setup(u, r):
    up = os.path.join(settings.REPOSITORY_LOCATION, u)
    p = os.path.join(up, r)
    subprocess.Popen(['ln', '-s', r+'/.git',  r+'.git'], cwd=up).wait()
    
    rchook = \
"""#!/bin/sh
%spostreceive.py %s %s
""" % (settings.GITBOX_LOCATION, u,r)
    open(os.path.join(p+'.git', 'config'), 'a').\
        write('\n[receive]\n\tdenyCurrentBranch = false\n')
    open(os.path.join(p+'.git', 'hooks', 'post-receive'), 'w').\
        write(rchook)

    subprocess.Popen(['chmod', '755', '-R', os.path.join(p+'.git', 'hooks', 'post-receive')], cwd=p).wait()
    subprocess.Popen(['chown', 'git:', '-R', '.'], cwd=p).wait()
    subprocess.Popen(['chown', 'git:', '-R', r+'.git'], cwd=up).wait()
            
def repo_delete(u, r):
    if repo_exists(u, r):
        shutil.rmtree(os.path.join(settings.REPOSITORY_LOCATION, u, r+'.git'))
    up = os.path.join(settings.REPOSITORY_LOCATION, u)
    if len(os.listdir(up)) == 0:
        os.rmdir(up)
        
