import tempfile
import subprocess
import settings
import os
import time
from main.models import *


def validate_key(key):
    f = tempfile.NamedTemporaryFile()
    f.write(key)
    f.flush()
    p = subprocess.Popen(['ssh-keygen', '-l', '-f', f.name], stdout=subprocess.PIPE)
    if p.wait() != 0:
        return None
    fp = p.stdout.read().split()[1]
    f.close()
    return fp

def add_key(user, title, data):
    fp = validate_key(data)
    if fp:
        k = PublicKey(
            name = title,
            key = data,
            user = user,
            fingerprint = fp
        )
        append_key(k)
        k.save()
    return fp
    
def delete_key(k):
    k.delete()
    rebuild_keys()    
    
    
def format_key(name, data):
    return 'command="%sssh-auth.py %s",no-port-forwarding,no-X11-forwarding,no-agent-forwarding,no-pty %s\n' % (settings.GITBOX_LOCATION, name, data)
    

def _lock():
    lock_file = os.path.join(settings.GITBOX_LOCATION, '.keylock')
    while os.path.exists(lock_file):
        time.sleep(0.5)
    open(lock_file, 'w').close()

def _unlock():
    lock_file = os.path.join(settings.GITBOX_LOCATION, '.keylock')
    os.unlink(lock_file)
    

def append_key(k):
    _lock()
    try:
        f = open(settings.KEYFILE_LOCATION, 'a')
        f.write(format_key(k.user.username, k.key))
        f.close()    
    finally:
        _unlock()
        
def rebuild_keys():
    _lock()
    try:
        f = open(settings.KEYFILE_LOCATION, 'w')
        for k in PublicKey.objects.all():
            f.write(format_key(k.user.username, k.key))
        f.close()    
    finally:
        _unlock()
