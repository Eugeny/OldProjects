import subprocess
import tempfile
from datetime import *
from dateutil.relativedelta import *
import dateutil
import dateutil.parser
import diff
import time
import os
import git
from mygit import *
from django.core.cache import cache
from django.template.defaultfilters import slugify
        
        
def parse_time(s):
    s = s.split()
    t = datetime.fromtimestamp(int(s[0]))
    d = relativedelta(hours=int(s[1][:-2]), minutes=int(s[1][-2:]))
    return t+d
    
    
class GitError(Exception): pass


class Repo:
    def __init__(self, path, model):
         self.path = path
         self.model = model
         self.repo = git.Repo(path)
         self.cachepfx = cache.get('namespace:' + self.model.cache_id())
         if not self.cachepfx:
            self.cachepfx = str(time.time())
            cache.set('namespace:' + self.model.cache_id(), self.cachepfx)
         
    def __getattr__(self, a):
        return getattr(self.repo, a)
    
    def __git(self, args, output=subprocess.PIPE, nocache=False, wt=False):
        cacheid = '%s-%s-%s'%(self.cachepfx,slugify(repr(args)),str(wt))
        if not nocache:
            cached = cache.get(cacheid)
            if cached:
                print '  [%s] Hit: %s' % (self.model.cache_id(),cacheid)
                return cached
            else:
                print '! [%s] Recaching: %s' % (self.model.cache_id(),cacheid)
                
        p = subprocess.Popen(['sudo', '-ugit', 'git'] + args, cwd=self.path+('' if wt else '.git'), stdout=output)
        if output == subprocess.PIPE:
            s = p.stdout.read()
        if p.wait() != 0:
            raise GitError()
        if output == subprocess.PIPE:
            s += p.stdout.read()
            cache.set(cacheid, s)
            return s
        
    def run_command(self, *args):
        return self.__git(list(args), wt=True, nocache=True)
        
    def disk_usage(self):
        p = subprocess.Popen(['du', '-b', '-s', '.'], stdout=subprocess.PIPE, cwd=self.path+'.git')
        p.wait()
        return int(p.stdout.read().split()[0])
            
    """def find_branch(self, commitish):
        s = self.__git(['branch', '--contains', commitish]).split('\n')[0].split()
        try:
            s = s[1] if s[0] == '*' else s[0]
        except:
            pass
        return s
    """
    
    def unmerged_branches(self):
        return [x.strip() for x in self.__git(['branch', '-a', '--no-merged']).split('\n')]
            
    """def rev_parse(self, spec):
        return self.__git(['rev-parse', spec])
    """
    
    def create_root_branch(self, name):
        self.model.drop_cache()
        self.__git(['symbolic-ref', 'HEAD', 'refs/heads/' + name], nocache=True, wt=True)
        try:
            os.unlink(os.path.join(self.path, '.git', 'index'))
        except OSError:
            pass
        self.__git(['clean', '-f', '-d', '-x'], nocache=True, wt=True)
        
    def setup_fork(self):
        for s in self.__git(['branch', '-r'], nocache=True, wt=True).split('\n'):
            if s == '':
                break
            s = s.split()
            if s[0] == '*':
                s = s[1:]
            br = s[0].split('/')[1]
            if br != 'HEAD':
                try:
                    self.__git(['branch', br, 'origin/'+br, '--track'], wt=True, nocache=True)
                except GitError:
                    pass
    
    def make_commit(self, msg, author='git@localhost'):
        self.model.drop_cache()
        self.__git(['add', '-A'], nocache=True, wt=True)
        self.__git(['commit', '--allow-empty', '-m %s'%msg, '--author=%s'%author], nocache=True, wt=True)
        
    def merge(self, commit):
        self.model.drop_cache()
        try:
            self.__git(['merge', commit], nocache=True, wt=True)
            return True
        except GitError:
            self.__git(['reset', '--hard'], nocache=True, wt=True)
            self.__git(['clean', '-f', '-d'], nocache=True, wt=True)
        return False 
        
    def remote_log(self, i, br, rem):
        if rem:
            ss = self.__git(['rev-list', '--first-parent', '--pretty=raw', '%s..remotes/%s/%s'%(i,rem,br)]).split('\n')
        else:
            ss = self.__git(['rev-list', '--first-parent', '--pretty=raw', '%s..%s'%(i,br)]).split('\n')
        c = None
        r = []
        for s in ss:
            if s.startswith('commit '):
                if c: r.append(c)
                c = [s.split()[1], '']
            if s.startswith(' '):
                c[1] += s.strip() + '\n'
        if c: r.append(c)
        return r
                  
    """def get_file(self, treeish, path):
        f = tempfile.TemporaryFile()
        self.__git(['show', '%s:%s'%(treeish,path)], nocache=True, output=f)
        f.seek(0)
        return f

    def extract_file(self, treeish, path):
        f = tempfile.NamedTemporaryFile()
        self.__git(['show', '%s:%s'%(treeish,path)], nocache=True, output=f)
        f.seek(0)
        return f

    def ls(self, treeish, path=''):
        ll = self.__git(['ls-tree', '-l', treeish, './%s/'%path]).split('\n')
        r = []
        for l in ll:
            if l != '':
                l, n = l.split('\t')
                l = l.split()
                if len(l) == 4:
                    b = Blob()
                    b.type, b.treeish = l[1], l[2]
                    b.mode = int(l[0], 8)
                    if l[3] != '-':
                        b.size = int(l[3]) 
                    b.name = n.split('/')[-1]
                    r.append(b)
        return r
    """
    
    def graph_data(self):
        return self.__git(['log', '-400', '--pretty=format:%H %d%n%P%n%an%n%ae%n%s---BOUND---', '--topo-order', '--all', '--parents', '--decorate'])
        
    """def log(self, treeish, path='.', start=0, limit=10):
        r = []
        ll = self.__git(['log', '--pretty=raw', '-%i'%limit, '--skip=%i'%start,  treeish, '--', path]).split('\n')
        c = None
        for l in ll:
            if l.startswith('commit '):
                if c:
                    r.append(c)
                c = Commit()
                c.treeish = l.split()[1]
            elif l.startswith('author '):
                l = l.split(' ', 1)[1]
                l = l.rsplit(' ', 2)
                c.author = l[0].strip()
                c.date = parse_time(l[1]+' '+l[2])
            elif l.startswith('parent '):
                if c.merge or c.parent:
                    c.merge.append(c.parent)
                    c.parent = None
                    c.merge.append(l.split()[1])
                else:
                    c.parent = l.split()[1]
            elif l.startswith('  '):
                c.message += l.strip() + '\n'
            elif l.startswith(' ') and '|' in l:
                l = l.split('|')
                c.stat[l[0].strip()] = l[1].strip()
            elif l.startswith(' '):
                c.message += l.strip() + '\n'
        if c:
            r.append(c)
        return r
        
    def branches(self):
        r = []
        for l in self.__git(['branch']).split('\n'):
            l = l.split()
            if l != []:
                r.append(l[0] if l[0] != '*' else l[1])
        return r
    
    def tags(self):
        return filter(lambda x:x, self.__git(['tag']).split('\n'))
        
    def __parse_commit(self, ll):
        c = Commit()
        d = ''
        stat = []
        for l in ll:
            if d != '':
                d += l + '\n'
                continue
            elif l.startswith('diff'):
                d += l + '\n'
            elif l.startswith('commit '):
                c.treeish = l.split()[1]
            elif l.startswith('author '):
                l = l.split(' ', 1)[1]
                l = l.rsplit(' ', 2)
                c.author = l[0].strip()
                c.date = parse_time(l[1]+' '+l[2])
            elif l.startswith('parent '):
                if c.merge or c.parent:
                    c.merge.append(c.parent)
                    c.parent = None
                    c.merge.append(l.split()[1])
                else:
                    c.parent = l.split()[1]
            elif l.startswith('  '):
                c.message += l.strip() + '\n'
            elif l.startswith(' ') and '|' in l:
                l = l.split('|')
                s = Stat()
                s.name = l[0].strip()
                s.count = l[1].strip().split()[0]
                try:
                    if s.count == 'Bin':
                        s.bin = l[1].strip().split(' ', 1)[1]
                    else:
                        s.stat = l[1].strip().split(' ', 1)[1]
                except:
                    pass
                stat.append(s)
        return c, stat, d
    
    def _diff_setup(self,c,s,d):
        for ff in s:
            for f in d.files:
                if f.name == ff.name:
                    if f.deleted:
                        ff.deleted = True
        for f in d.files:
            if f.created:
                st = Stat()
                st.name = f.name
                st.created = True
                st.count = None
                st.stat = ''
                s.append(st)
        for f in s:
            if '=>' in f.name:
                f.fa, f.fb = [x.strip(' >') for x in f.name.split('=', 1)]
                f.name = None
    """
    
    def diff(self, ish, patch=False):
        d = self.__git(['diff' if '..' in ish else 'show', '--pretty=format:', '-p', ish], wt=True)
        if not patch:
            d = diff.parse(d.split('\n'))
        return d

    def compare(self, ish, patch=False):
        d = self.__git(['diff', '-p', ish], wt=True)
        if not patch:
            d = diff.parse(d.split('\n'))
        return d

    def stat(self, ish):
        d = self.__git(['diff', '--numstat', ish], wt=True)
        return git.Stats._list_from_string(None, d)
        
    """def commit(self, treeish, patch=True):
        if patch:
            ll = self.__git(['show', '--pretty=raw', '-M', '--stat', '-p', treeish]).split('\n')
        else:
            ll = self.__git(['show', '--pretty=raw', treeish]).split('\n')
        c, s, d = self.__parse_commit(ll)
        if patch:
            d = diff.parse(d)
            self._diff_setup(c,s,d)
        return c, s, d
    
    def compare(self, ish):
        ll = self.__git(['diff', '-M', '--stat', '-p', ish]).split('\n')
        c, s, d = self.__parse_commit(ll)
        d = diff.parse(d)
        self._diff_setup(c,s,d)
        return s, d

    def commit_patch(self, treeish):
        ll = self.__git(['show', '--pretty=raw', '--binary', '--stat', '-p', treeish]).split('\n')
        c, s, d = self.__parse_commit(ll)
        return d        
    """
    
    def checkout(self, treeish):
        self.__git(['checkout', '-f', treeish], nocache=True, wt=True)
        self.__git(['reset', '--hard'], nocache=True, wt=True)
        self.__git(['clean', '-f', '-d'], nocache=True, wt=True)
    
    def blame(self, path):
        ll = self.__git(['blame', path], wt=True).split('\n')
        r = []
        b = None
        for l in ll:
            if l == '':
                continue
            l = l.split(')', 1)
            code = l[1]
            l = l[0].split('(')
            ish = l[0].strip(' ^')
            l = l[1].split()
            date = dateutil.parser.parse(' '.join(l[-4:-1]))
            author = ' '.join(l[:-4])
            if b and b.treeish != ish:
                r.append(b)
            if not b or b.treeish != ish:
                b = Blame()
                b.treeish = ish
                b.author = author
                b.date = date
            b.lines.append(code)
        if b:
            r.append(b)
        return r  
        
             
class Blame:
    def __init__(self):
        self.lines = []
        self.treeish = ''
        self.author = ''
        self.date = None
                       
                        
class Blob:
    def __init__(self):
        self.treeish = ''
        self.name = ''
        self.mode = 0
        self.type= ''
        self.size = 0
        
        
class Stat:
    def __init__(self):
        self.name = ''
        self.stat =''
        self.count = 0
        self.fa = None
        self.fb = None
                        
class Commit:
    def __init__(self):
        self.message = ''
        self.author = ''
        self.date = None
        self.treeish = ''
        self.parent = None
        self.merge = []

