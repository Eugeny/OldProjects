GITBOX_LOCATION = '/gitbox/'
KEYFILE_LOCATION = GITBOX_LOCATION + '.ssh/authorized_keys'
REPOSITORY_LOCATION = GITBOX_LOCATION + 'repositories/'
STATIC_PATH = '/static'
DOMAIN = 'localhost:8000'

WIKI_BRANCH = 'gittle-wiki'

LOGIN_REDIRECT_URL = '/dashboard'
LOGIN_URL = '/accounts/login/'
LOGOUT_URL = '/accounts/logout/'

ACCOUNT_ACTIVATION_DAYS = 7

AUTH_USER_EMAIL_UNIQUE = True
EMAIL_HOST = 'localhost'
EMAIL_PORT = 25
EMAIL_HOST_USER = ''
EMAIL_HOST_PASSWORD = ''
EMAIL_USE_TLS = False
DEFAULT_FROM_EMAIL = 'accounts@%s' % DOMAIN

INTERNAL_IPS = ('127.0.0.1',)



DEBUG = False
DEBUG = True
TEMPLATE_DEBUG = DEBUG
DEBUG_TOOLBAR_PANELS = (
    'debug_toolbar.panels.version.VersionDebugPanel',
    'debug_toolbar.panels.timer.TimerDebugPanel',
    'debug_toolbar.panels.settings_vars.SettingsVarsDebugPanel',
    'debug_toolbar.panels.headers.HeaderDebugPanel',
    'debug_toolbar.panels.request_vars.RequestVarsDebugPanel',
    'debug_toolbar.panels.template.TemplateDebugPanel',
    'debug_toolbar.panels.sql.SQLDebugPanel',
    'debug_toolbar.panels.signals.SignalDebugPanel',
    'debug_toolbar.panels.logger.LoggingPanel',
)
DEBUG_TOOLBAR_CONFIG = {
    'HIDE_DJANGO_SQL': True,
    'INTERCEPT_REDIRECTS': False,
}


ADMINS = (
    ('Eugeny Pankov', 'john.pankov@gmail.com'),
)
MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'gitbox',
        'USER': 'root',
        'PASSWORD': '123',
        'HOST': '',
        'PORT': '',
    }
}

CACHE_BACKEND = 'memcached://localhost:11211/'

MEDIA_ROOT = '/gitbox-site/media/'


TIME_ZONE = 'America/Chicago'
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

USE_I18N = False
USE_L10N = True 

ADMIN_MEDIA_PREFIX = '/media/'

SECRET_KEY = '_@jj0_$skx=$hr20^x#7#f8pstqr4y9(fh!s0i32l!h*@3mg=@'

TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.middleware.http.ConditionalGetMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.gzip.GZipMiddleware',
    #'debug_toolbar.middleware.DebugToolbarMiddleware',
)

TEMPLATE_CONTEXT_PROCESSORS = (
    'django.contrib.auth.context_processors.auth',
    'django.core.context_processors.debug',
    'django.contrib.messages.context_processors.messages',
    'main.helpers.context_processor',
)

ROOT_URLCONF = 'urls'

USE_ETAGS = True

TEMPLATE_DIRS = (
    '/gitbox-site/templates',
    #'/usr/share/pyshared/debug_toolbar/templates',
)

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.admin',
    'django.contrib.admindocs',
    'django.contrib.markup',
    'django.contrib.humanize',
    'registration',
    #'debug_toolbar',
    'main',
)
