$(document).ready(function () {
    $('.tabs .handles a').click( function () {
        $('.tabs .body').removeClass('current'); 
        $('#body-'+this.id).addClass('current'); 
        $('.tabs .handles a').removeClass('active');
        $(this).addClass('active');
        return false;
    });
});

function graphLoadCommit(ish, scroll) {
    $('div.canvas-graph a').removeClass('active');
    $('#commit-' + ish).addClass('active');
    $('#view-pane').empty();
    $('#ajax-loader').show();
    $.ajax({
        type: 'GET',
        url: 'flow-ajax/' + ish,
        success: function (html) {
            $('#ajax-loader').hide();
            $('#view-pane').append(html);
        }
    });
    
    if (scroll) {
        $('div.canvas-graph').scrollTop($('#commit-' + ish)[0].offsetTop);
    }
    
    return false;
}

function codeNoteForm(f,l) {
    id = '#comment-form-' + f + '-' + l;
    $(id).empty();
    $(id).append($('#code-note-form'));
    $('#note-file-data')[0].value = f;
    $('#note-line-data')[0].value = l;
    
    return false;
}


function loadDialog(url) {
    $.ajax({
        type: 'GET',
        url: url,
        success: function (html) {
            $('#dialog-socket').empty();
            $('#dialog-socket').append(html);
            uiFullscreen($('.blackout')[0]);
            uiCenter($('.dialog')[0]);
            window.scrollTo(0,0);        
        }
    });
}

function uiCenter(e) {
    sw = window.innerWidth;
    sh = window.innerHeight;
    e.style.left = (sw / 2 - e.clientWidth / 2) + 'px';
    e.style.top = (sh / 2 - e.clientHeight / 2) + 'px';
    if (sh < e.clientHeight)
        e.style.top = '0px';
}

function uiFullscreen(e) {
    sw = document.documentElement.scrollWidth;
    sh = document.documentElement.scrollHeight;
    e.style.width = sw + 'px';
    e.style.height = sh + 'px';
}
