from django.db import models
from django.core.cache import cache
from django.contrib import auth 
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes import generic
import settings
import os
import time


class Repository(models.Model):
    user = models.ForeignKey(auth.models.User)
    name = models.SlugField('Name')
    private = models.BooleanField('Private')    
    upstream = models.ForeignKey('Repository', related_name='forks', blank=True, null=True)
    integration = models.CharField('Integration branch', max_length=100)
    followers = models.ManyToManyField(auth.models.User, related_name='followed_repos')
    
    def __unicode__(self):
        return u'%s/%s' % (self.user.username, self.name)
        
    def full_path(self):
        return os.path.join(settings.REPOSITORY_LOCATION, self.user.username, self.name)
        
    def cache_id(self):
        return '%s:%s'%(self.user.username,self.name)
    
    def drop_cache(self):
        cache.set('namespace:' + self.cache_id(), str(time.time()))
        if self.upstream:    
            cache.set('namespace:' + self.upstream.cache_id(), str(time.time()))
        
                
class Permission(models.Model):
    repository = models.ForeignKey(Repository)
    user = models.ForeignKey(auth.models.User, related_name='+')
    read = models.BooleanField('Read')
    write = models.BooleanField('Write')
    
    def __unicode__(self):
        return u'%s: %s = %s%s' % (self.repository, self.user.username, 'R' if self.read else '', 'W' if self.write else '')
    
    
class PublicKey(models.Model):
    user = models.ForeignKey(auth.models.User)
    key = models.TextField('Key data')
    name = models.CharField('Name', max_length=100)
    fingerprint = models.CharField('RSA fingerprint', max_length=100)
    
    
class BugComponent(models.Model):
    repository = models.ForeignKey(Repository)
    name = models.CharField(max_length=100)

    def __unicode__(self):
        return u'%s' % self.name


class BugMilestone(models.Model):
    repository = models.ForeignKey(Repository)
    name = models.CharField(max_length=100)
    
    def __unicode__(self):
        return u'%s' % self.name
        
        
class Bug(models.Model):
    repository = models.ForeignKey(Repository)
    reporter = models.ForeignKey(auth.models.User, related_name='bugs_reported', blank=True, null=True)
    assignee = models.ForeignKey(auth.models.User, related_name='bugs_assigned', blank=True, null=True)
    component = models.ForeignKey(BugComponent, blank=True, null=True)
    milestone = models.ForeignKey(BugMilestone, blank=True, null=True)
    priority = models.IntegerField('Priority', blank=True, null=True)
    text = models.TextField(max_length=2000)
    title = models.CharField(max_length=200)
    date = models.DateTimeField('Created on')

    bug_statuses = {
            'new': ('#993300', 'New'),
            'invalid': ('#555', 'Invalid'),
            'duplicate': ('#555', 'Duplicate'),
            'wontfix': ('#555', 'Won\'t fix / Feature'),
            'confirmed': ('#ff0000', 'Confirmed'),
            'triaged': ('#ff6600', 'Triaged'),
            'inprogress': ('#222', 'In progress'),
            'commited': ('#005500', 'Fix commited'),
            'released': ('#00ff00', 'Fix released'),
    }    
    
    bug_priorities = {
        -2: ('#666', 'Lowest'),
        -1: ('#444', 'Low'),
        0: ('#333', 'Normal'),
        1: ('#993300', 'High'),
        2: ('#ff6600', 'Highest'),
        3: ('#ff0000', 'Critical'),
    }
    
    status = models.CharField(max_length=50, choices=[(x,bug_statuses[x][1]) for x in bug_statuses])
    
    def status_text(self):
        return self.bug_statuses[self.status][1]
        
    def status_color(self):
        return self.bug_statuses[self.status][0]     
        
    def priority_text(self):
        return self.bug_priorities[self.priority][1]
        
    def priority_color(self):
        return self.bug_priorities[self.priority][0]     
        
        
class BugComment(models.Model):
    bug = models.ForeignKey(Bug)
    text = models.TextField(max_length=3000, blank=True, null=True)
    author = models.ForeignKey(auth.models.User)
    date = models.DateTimeField('Posted on')
    changes = models.TextField(max_length=3000, blank=True, null=True)
    
    
class UserFollowship(models.Model):
    who = models.ForeignKey(auth.models.User, related_name='followed_users')
    subject = models.ForeignKey(auth.models.User, related_name='followers')
    
class Message(models.Model):
    sender = models.ForeignKey(auth.models.User, related_name='outbox')
    subject = models.ForeignKey(auth.models.User, related_name='inbox')
    owner = models.ForeignKey(auth.models.User, related_name='+')
    read = models.BooleanField('Read')
    text = models.TextField(max_length=3000)
    date = models.DateTimeField('Sent on')
    
class News(models.Model):
    subject = models.ForeignKey(auth.models.User, related_name='+')
    repository = models.ForeignKey(Repository, related_name='+', blank=True, null=True)
    objekt_id = models.PositiveIntegerField()
    objekt_type = models.ForeignKey(ContentType)
    objekt = generic.GenericForeignKey(ct_field='objekt_type', fk_field='objekt_id')
    action = models.CharField(max_length=100,
        choices = (
            ('followrepo', 'Watching repo'),
            ('followuser', 'Watching user'),
            ('fork', 'Fork'),
            ('create', 'Create repo'),
            ('push', 'Push'),
            ('diffnote', 'Diff note'),
        ))
    misc = models.TextField(max_length=2000, blank=True, null=True)
    date = models.DateTimeField()
    
    
class DiffNote(models.Model):
    repository = models.ForeignKey(Repository)
    commit = models.CharField(max_length=100)
    author = models.ForeignKey(auth.models.User)
    date = models.DateTimeField()
    file = models.CharField(max_length=500)
    line = models.IntegerField()
    text = models.TextField(max_length=3000)
    
    
class MergeRequest(models.Model):
    repository = models.ForeignKey(Repository)
    head = models.CharField(max_length=100)
    author = models.ForeignKey(auth.models.User)
    closed = models.BooleanField('Closed')
    date = models.DateTimeField()
    title = models.TextField(max_length=300)
    
    
class MergeRequestComment(models.Model):
    request = models.ForeignKey(MergeRequest, related_name='comments')
    text = models.TextField(max_length=3000, blank=True, null=True)
    author = models.ForeignKey(auth.models.User)
    date = models.DateTimeField('Posted on')
    
        
