#coding: utf8
from main.models import *
from django.contrib import admin
        
        
class RepositoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'user', 'private', 'upstream')
    list_filter = ('private',)
    search_fields = ('user__username', 'name')

class PermissionAdmin(admin.ModelAdmin):
    list_display = ('repository', 'user', 'read', 'write')
    search_fields = ('user', 'repository')

class BugAdmin(admin.ModelAdmin):
    list_display = ('repository', 'title', 'reporter', 'status', 'date')
    search_fields = ('title', 'text', 'repository')
    list_filter = ('status',)
    
class DiffNoteAdmin(admin.ModelAdmin):
    list_display = ('repository', 'commit', 'author', 'file', 'line')
    search_fields = ('author', 'text', 'repository')
    

admin.site.register(Repository, RepositoryAdmin)
admin.site.register(Permission, PermissionAdmin)
admin.site.register(Bug, BugAdmin)
admin.site.register(PublicKey)
admin.site.register(BugComment)
admin.site.register(BugComponent)
admin.site.register(BugMilestone)
admin.site.register(Message)
admin.site.register(DiffNote, DiffNoteAdmin)
