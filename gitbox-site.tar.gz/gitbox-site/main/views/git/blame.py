#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *


@repo_view
@git_view
def blame(req, path=None):
    try:
        blame = req.git.blame(path)
    except GitError:
        raise Http404
    commits = req.git.iter_commits(req.treeish, paths=path, max_count=5)
    return render_to_response(
        'git/blame.html', 
        {
            'blame': blame,
            'commits':commits,
        },
        context_instance=RequestContext(req)
    )

