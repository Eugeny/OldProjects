#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *

    
@repo_view
@git_view
def raw(req, path=None):
    try:
        blob = req.git.commit(req.treeish).tree / path
        f = blob.data_stream
    except GitError:
        raise Http404
    #wrapper = FileWrapper(f)
    response = HttpResponse(f.read(), content_type=blob.mime_type)
    return response


