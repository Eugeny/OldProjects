#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *
from mygit import *
import settings


@repo_view
@git_view
def tree(req, readme=False, path=None):
    try:
        files = req.git.commit(req.treeish).tree
        if path != '':
            files /= path
    except GitError:
        raise Http404
        
    commits = req.git.iter_commits(req.treeish, paths=[path], max_count=5)
    
    if readme:
        try:
            f = req.git.commit(req.treeish).tree / 'README'
            readme = f.data_stream.read()
        except KeyError:
            readme = None
            
    nf = []
    for f in files:
        i = Item()
        i.file = f
        i.commit = list(req.git.iter_commits(req.treeish, paths=[os.path.join(path,f.name)], max_count=1))[0]
        nf.append(i)

    nf = sorted(nf)
    
    return render_to_response(
        'git/tree.html', 
        {
            'files':nf,
            'commits':commits,
            'sshurl':'git@%s:%s/%s'%(settings.DOMAIN, req.repo.user.username, req.repo.name),
            'httpurl':'http://git.%s/%s/%s'%(settings.DOMAIN, req.repo.user.username, req.repo.name),
            'readme': readme,
        },
        context_instance=RequestContext(req)
    )

    
class Item:
    def __init__(self):
        self.file = None
        self.commit = None    

    def __cmp__(self, other):
        if self.file.type == 'tree' and other.file.type == 'blob':
            return -1
        if self.file.type == 'blob' and other.file.type == 'tree':
            return 1
        return cmp(self.file.name, other.file.name)
        
