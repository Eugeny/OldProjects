#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *


@repo_view
@git_view
@feeder
def log(req, path=None):
    st = 0
    page_len = 10
    if req.GET and 's' in req.GET:
        st = int(req.GET['s'])
    commits = list(req.git.iter_commits(req.treeish, paths=path, skip=st, max_count=page_len))
    return render_to_response(
        'git/log.html' if not req.feed else 'git/log.atom', 
        {
            'log': commits,
            'page_link': req.META['PATH_INFO'] + '?s=',
            'page_prev': str(st-page_len) if st >= page_len else None,
            'page_next': str(st+page_len) if len(commits) == page_len else None,
        },
        context_instance=RequestContext(req)
    )
    
