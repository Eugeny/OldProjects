#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *
from main.highlight import *
from datetime import *
from django.db.models import Q


@repo_view
@git_view
def commit(req, commitish=None, path=None):
    commit = req.git.commit(commitish)
    commits = req.git.iter_commits(req.treeish, max_count=10)
    diff = req.git.diff(commit.hexsha) 
    parent = None
    if len(commit.parents)>1:
        parent = commit.parents[0]
    
    if req.POST and req.user.is_authenticated:
        if req.POST['text']:
            rp = req.repo
            if req.repo.upstream:
                rp = req.repo.upstream
            dn = DiffNote(
                author=req.user,
                repository=rp,
                date=datetime.now(),
                commit=commit.hexsha,
                file=diff.files[int(req.POST['file'])-1].name,
                line=int(req.POST['line']),
                text=req.POST['text'],
            )
            dn.save()
            emit_news(subject=req.user, repo=req.repo, objekt=dn, action='diffnote')

    if req.GET:
        if 'delete_comment' in req.GET:
            try:
                note = DiffNote.objects.get(id=req.GET['delete_comment'])
                if note.author == req.user or note.repository.user == req.user:
                    note.delete()
                else:
                    push_message(req, 'WNo way')
            except DiffNote.DoesNotExist:
                pass
            
    notes = DiffNote.objects.filter(
        Q(commit=commit.hexsha) &
        (Q(repository=req.repo) | Q(repository=req.repo.upstream))
    ).order_by('date')
    
    diff.apply_notes(notes)
    
    return render_to_response(
        'git/diff.html', 
        {
            'c': commit,
            'commits': commits,
            'parent': parent,
            'diff': diff,
        },
        context_instance=RequestContext(req)
    )
    
@repo_view
@git_view
def compare(req, commitish=None, path=None):
    d = req.git.diff(commitish)
    s = req.git.stat(commitish)

    class CommitStub:
        def __init__(self, s):
            self.stats = s
            
    return render_to_response(
        'git/diff.html', 
        {
            'c': CommitStub(s),
            'diff': d,
            'compare': commitish,
        },
        context_instance=RequestContext(req)
    )
    
@repo_view
@git_view
def patch(req, commitish=None, path=None):
    c = req.git.diff(commitish, patch=True)
    return HttpResponse(c, content_type='text/plain')

    
