#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *
from main.highlight import *

from mygit import *


@repo_view
@git_view
def blob(req, path=None):
    try:
        blob = req.git.commit(req.treeish).tree / path
        f = blob.data_stream
    except GitError:
        raise Http404

    mime = blob.mime_type
    
    filename = path.split('/')[-1]
    commits = req.git.iter_commits(req.treeish, paths=path, max_count=5)
    
    if 'text' in mime:
        code = f.read()
        return render_to_response(
            'git/blob.html', 
            {
                'code': highlight_code(filename, code),
                'styles': get_highlight_styles(),
                'commits':commits,
                'blob_type': 'text',
            },
            context_instance=RequestContext(req)
        )
    return render_to_response(
        'git/blob.html', 
        {
            'commits':commits,
            'blob_type': 'image' if 'image' in mime else 'binary',
        },
        context_instance=RequestContext(req)
    )




