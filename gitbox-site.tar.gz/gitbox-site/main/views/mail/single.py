#coding: utf-8 
from django.http import *
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *
from main.models import *
import datetime
from django.db.models import Q


@login_required
def single(req, uid):
    user = get_object_or_404(User, id=int(uid))
    if req.POST:
        if 'send' in req.POST:
            Message(
                sender=req.user,
                subject=user,
                read=True,
                owner=req.user,
                date=datetime.datetime.now(),
                text=req.POST['text']
            ).save()
            Message(
                sender=req.user,
                subject=user,
                read=False,
                owner=user,
                date=datetime.datetime.now(),
                text=req.POST['text']
            ).save()

    q = Q(sender=user, owner=req.user) | Q(subject=user, owner=req.user)
    qs = Message.objects.filter(q).order_by('-date')
    qs.update(read=True)
    msgs = qs.all()
    for m in msgs:
        m.author = m.sender
    
    return render_to_response(
        'mail/single.html',
        {
            'u': user,
            'msgs': msgs,
        },
        context_instance=RequestContext(req)
    )
    
