#coding: utf-8 
from django.http import *
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from main.models import *


@login_required
def maillist(req):
    msgs = {}
    for m in Message.objects.filter(owner=req.user).order_by('-date'):
        if m.sender == req.user:
            if not m.subject in msgs:
                msgs[m.subject] = Msg(m)
                msgs[m.subject].sender = m.subject
        else:
            if not m.sender in msgs:
                msgs[m.sender] = Msg(m)

    return render_to_response(
        'mail/list.html',
        {
            'msgs': msgs.values(),
        },
        context_instance=RequestContext(req)
    )
    
    
class Msg:
    def __init__(self, msg):
        self.sender=msg.sender
        self.text=msg.text
        self.date=msg.date
        self.read=msg.read

