#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *
from main.forms import *

from git import *


@login_required
def account(req):
    tab = 'personal'
    
    editform = EditAccountForm(initial={
           'first_name': req.user.first_name,
           'last_name': req.user.last_name,
           'new_pass': '',
           'email': req.user.email,
        })

        
    if req.GET:
        if 'del_key' in req.GET:
            try:
                k = PublicKey.objects.get(id=req.GET['del_key'])
                if k.user != req.user:
                    push_message(req, 'WNice try.')
                else:
                    delete_key(k)
                return HttpResponseRedirect('/account?tab=keys')
            except PublicKey.DoesNotExist:
                pass            
        if 'tab' in req.GET:
            tab = req.GET['tab']    
    
    if req.POST:
        if 'addkey' in req.POST:
            if req.POST['title'] == '':
                push_message(req, 'WPlease enter title')
            elif req.POST['key'] == '':
                push_message(req, 'WPlease enter key data')
            else:
                if not add_key(req.user, req.POST['title'], req.POST['key']):
                    push_message(req, 'WInvalid key data')
                else:
                    push_message(req, 'IKey added')
        if 'edit_account' in req.POST:
            editform = EditAccountForm(req.POST)
            tab = 'personal'
            if editform.is_valid():
                req.user.first_name = editform.cleaned_data['first_name']
                req.user.last_name = editform.cleaned_data['last_name']
                req.user.email = editform.cleaned_data['email']
                req.user.save()
                push_message(req, 'ISaved')

    return render_to_response(
        'main/account.html', 
        {
            'current_tab': tab,
            'editform': editform,
        },
        context_instance=RequestContext(req)
    )

