#coding: utf-8 
from django.http import *
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *
from django.contrib import auth
from main.models import *
from main.forms import *
from main.helpers import *
import main.models
from django.db.models import Q


def index(req):
    return render_to_response(
        'basic-site.html',
        {
        },
        context_instance=RequestContext(req)
    )

@feeder
def dashboard_feed(req, token=None):
    u = User.objects.get(password__endswith=token)
    req.user = u
    return dashboard(req)
    
@login_required
@feeder
def dashboard(req):
    mr = [x.id for x in req.user.repository_set.all()]
    fr = [x.id for x in req.user.followed_repos.all()]
    fu = [x.subject.id for x in req.user.followed_users.all()]

    news = News.objects.filter(
        (Q(action='followuser') & Q(objekt_id__in=fu)) |
        (Q(action='followuser') & Q(objekt_id=req.user.id)) |
        (Q(repository__id__in=fr)) |
        (Q(repository__id__in=mr)) |
        (Q(subject__id__in=fu) & ~Q(action='welcome')) | 
        (Q(subject=req.user) & Q(action='welcome'))
    ).order_by('-date')

    token = req.user.password[-8:]
    
    return render_to_response(
        'dashboard.html' if not req.feed else 'dashboard.atom',
        {
            'news': news,
            'token': token,
            'repos': req.user.repository_set.all(),
        },
        context_instance=RequestContext(req)
    )
    
    
    
def http500(req):
    return render_to_response(
        '500.html',
        {
            'section': 'error'
        },
        context_instance=RequestContext(req)
    )    
    
