#coding: utf-8 
from django.http import *
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import User
from main.models import *
from main.helpers import *

def profile(req, username):
    try:
        user = User.objects.get(username=username)
    except:
        raise Http404
        
    repos = user.repository_set.filter(private=False)
    following = False
    if req.user.is_authenticated():
        following = req.user.followed_users.filter(subject=user).exists()
        
    return render_to_response(
        'main/profile.html',
        {
            'u': user,
            'repos': repos,
            'following': following,
        },
        context_instance=RequestContext(req)
    )
    
@login_required
def follow(req, uid):
    user = get_object_or_404(User, id=uid)
    if not req.user.followed_users.filter(subject=user).exists():
        emit_news(subject=req.user, objekt=user, action='followuser')
        req.user.followed_users.create(
            who=req.user,
            subject=user
        )
    return HttpResponseRedirect('/%s'%user.username)
    
@login_required
def unfollow(req, uid):
    user = get_object_or_404(User, id=uid)
    req.user.followed_users.filter(subject=user).delete()
    return HttpResponseRedirect('/%s'%user.username)    
        
