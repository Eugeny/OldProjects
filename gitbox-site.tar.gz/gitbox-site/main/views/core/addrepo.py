#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *
from main.forms import *

from git import *


@login_required
def addrepo(req):
    if req.POST:
        form = AddRepoForm(req.POST)
        form.user = req.user
        if form.is_valid():
            u,r = req.user.username, form.cleaned_data['name']
            repo_add(u, r)
            repo = Repository(
                user=req.user,
                name=r,
                integration='master'
            )
            repo.save()
            emit_news(subject=req.user,repo=repo,objekt=repo,action='create')
            return HttpResponseRedirect('/%s/%s' % (u,r))
    else:
        form = AddRepoForm()
        
    return render_to_response(
        'main/add-repo.html', 
        {
            'form': form,
        },
        context_instance=RequestContext(req)
    )
    
