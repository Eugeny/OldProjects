#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *


@repo_view
@upstream_only
def buglist(req):
    q = {}
    search_box = ''
    flt = ''
    msflt = None
    cmpflt = None
    
    if req.GET:
        if 'search' in req.GET:
            q['title__icontains'] = req.GET['search']
            search_box = req.GET['search']
        if 'filter' in req.GET:
            flt = req.GET['filter']
            if flt == 'o':
                q['status__in'] = ['new', 'confirmed']
            if flt == 'c':
                q['status__in'] = ['commited', 'released', 'duplicate', 'invalid', 'wontfix']
            if flt == 'hp':
                q['priority__in'] = [1,2,3]
            if flt == 'ip':
                q['status'] = 'inprogress'
        if 'cmp' in req.GET:
            cmpflt = int(req.GET['cmp'])
            flt = '1'
            q['component__id'] = req.GET['cmp']
        if 'ms' in req.GET:
            msflt = int(req.GET['ms'])
            flt = '1'
            q['milestone__id'] = req.GET['ms']
        if 'del_component' in req.GET:
            if req.user == req.repo.user:
                Bug.objects.filter(component__id=req.GET['del_component']).update(component=None)
                BugComponent.objects.filter(
                    id=req.GET['del_component'],
                    repository=req.repo
                ).delete()
            return HttpResponseRedirect('.')
        if 'del_milestone' in req.GET:
            if req.user == req.repo.user:
                Bug.objects.filter(milestone__id=req.GET['del_milestone']).update(milestone=None)
                BugMilestone.objects.filter(
                    id=req.GET['del_milestone'],
                    repository=req.repo
                ).delete()
            return HttpResponseRedirect('.')
            
    if req.POST:
        if 'add_component' in req.POST:
            if req.user == req.repo.user:
                BugComponent(
                    name=req.POST['name'],
                    repository=req.repo
                ).save()
        if 'add_milestone' in req.POST:
            if req.user == req.repo.user:
                BugMilestone(
                    name=req.POST['name'],
                    repository=req.repo
                ).save()
    if q == {}:            
        bugs = Bug.objects.filter(repository=req.repo).order_by('-date')
    else:
        bugs = Bug.objects.filter(repository=req.repo, **q).order_by('-date')
        
    return render_to_response(
        'bugs/list.html', 
        {
            'bugs': bugs,
            'search_box': search_box,
            'flt': flt,
            'msflt': msflt,
            'cmpflt': cmpflt,
        },
        context_instance=RequestContext(req)
    )




