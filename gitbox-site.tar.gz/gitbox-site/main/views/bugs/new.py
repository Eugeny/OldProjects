#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *
from main.forms import *

import datetime


@login_required
@repo_view
@upstream_only
def new(req):
    if req.POST:
        form = AddBugForm(req.POST)
        if form.is_valid(): 
            b = Bug(
                repository = req.repo,
                reporter = req.user if req.user.is_authenticated() else None,
                title = form.cleaned_data['title'],
                text = form.cleaned_data['text'],
                priority = 0,
                status = 'new',
                date = datetime.datetime.now()
            )
            b.save()
            return HttpResponseRedirect(str(b.id))
    else:
        form = AddBugForm()
        
    return render_to_response(
        'bugs/new.html', 
        {
            'form': form,
        },
        context_instance=RequestContext(req)
    )
    
