#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib import auth

from main.models import *
from main.helpers import *

import datetime


@repo_view
@upstream_only
def single(req, id=None):
    bug = Bug.objects.get(id=id)
    
    if req.GET:
        if 'delete_comment' in req.GET:
            try:
                c = BugComment.objects.get(id=req.GET['delete_comment'])
                if c.author == req.user or c.bug.repository.user == req.user:
                    c.delete()
                else:
                    push_message(req, 'WNo way')
            except BugComment.DoesNotExist:
                pass

    if req.POST:
        if 'comment' in req.POST:
            cs = ''
            
            nv = None
            if req.POST['assignee']:
                nv = auth.models.User.objects.get(username=req.POST['assignee'])
            if nv != bug.assignee:
                cs += u'%s|%i|%i\n' % (
                    'assignee', 
                    -1 if not bug.assignee else bug.assignee.id, 
                    -1 if not nv else nv.id)
                bug.assignee = nv

            nv = 'new'
            if req.POST['status']:
                nv = req.POST['status']
            if nv != bug.status:
                cs += u'%s|%s|%s\n' % ('status', bug.status, nv)
                bug.status = nv
                
            nv = 0
            if req.POST['priority']:
                nv = int(req.POST['priority'])
            if nv != bug.priority:
                cs += u'%s|%i|%i\n' % ('priority', bug.priority, nv)
                bug.priority = nv

            nv = None
            if req.POST['component']:
                nv = BugComponent.objects.get(id=int(req.POST['component']))
            if nv != bug.component:
                cs += u'%s|%i|%i\n' % (
                    'component', 
                    -1 if not bug.component else bug.component.id,
                    -1 if not nv else nv.id)
                bug.component = nv

            nv = None
            if req.POST['milestone']:
                nv = BugMilestone.objects.get(id=int(req.POST['milestone']))
            if nv != bug.milestone:
                cs += u'%s|%i|%i\n' % (
                    'milestone', 
                    -1 if not bug.milestone else bug.milestone.id,
                    -1 if not nv else nv.id)
                bug.milestone = nv

            c = BugComment(
                text=req.POST['text'],
                author=req.user,
                bug=bug,
                date=datetime.datetime.now(),
                changes=cs if cs != '' else None,
            )
            c.save()
            bug.save()
            
    comments = bug.bugcomment_set.all()
    for c in comments:
        if c.changes:
            d = [[y.strip() for y in x.split('|')] for x in c.changes.split('\n')]
            d = filter(lambda x:x!=[''], d)
            c.changes = []
            for x in d:
                print x
                cs = BugChangeset()
                if x[0] == 'status':
                    cs.what = 'Status'
                    cs.old = Bug.bug_statuses[x[1]][1]
                    cs.new = Bug.bug_statuses[x[2]][1]
                if x[0] == 'priority':
                    cs.what = 'Priority'
                    cs.old = Bug.bug_priorities[int(x[1])][1]
                    cs.new = Bug.bug_priorities[int(x[2])][1]
                if x[0] == 'component':
                    cs.what = 'Component'
                    try:
                        cs.old = BugComponent.objects.get(id=int(x[1])).name
                    except BugComponent.DoesNotExist:
                        cs.old = 'none'
                    try:
                        cs.new = BugComponent.objects.get(id=int(x[2])).name
                    except BugComponent.DoesNotExist:
                        cs.new = 'none'
                if x[0] == 'milestone':
                    cs.what = 'Milestone'
                    try:
                        cs.old = BugMilestone.objects.get(id=int(x[1])).name
                    except BugMilestone.DoesNotExist:
                        cs.old = 'none'
                    try:
                        cs.new = BugMilestone.objects.get(id=int(x[2])).name
                    except BugMilestone.DoesNotExist:
                        cs.new = 'none'
                if x[0] == 'assignee':
                    cs.what = 'Assigned to'
                    try:
                        cs.old = auth.models.User.objects.get(id=int(x[1])).get_full_name()
                    except auth.models.User.DoesNotExist:
                        cs.old = 'none'
                    try:
                        cs.new = auth.models.User.objects.get(id=int(x[2])).get_full_name()
                    except auth.models.User.DoesNotExist:
                        cs.new = 'none'
                c.changes.append(cs)
                
    return render_to_response(
        'bugs/single.html', 
        {
            'bug': bug,
            'comments': comments,
            'components': BugComponent.objects.filter(repository=req.repo),
            'milestones': BugMilestone.objects.filter(repository=req.repo),
        },
        context_instance=RequestContext(req)
    )

class BugChangeset:
    def __init__(self, w=None, o=None, n=None):
        self.what = w
        self.old = o
        self.new = n

