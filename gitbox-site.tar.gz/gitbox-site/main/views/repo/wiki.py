#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *
from git import *

import settings
import codecs

@login_required
@repo_view
@repo_admin
def wiki_init(req):
    if req.GET:
        if 'init' in req.GET:
            req.git.create_root_branch(settings.WIKI_BRANCH)
            open(os.path.join(req.git.path, 'Home.md'), 'w').write(
                generate_homepage(req)
            ) 
            req.git.make_commit(msg='Initial commit', author='%s <%s>'%(req.user.get_full_name(),req.user.email))
            req.git.checkout(req.repo.integration)
            return HttpResponseRedirect('Home')
    return render_to_response(
        'wiki/new.html', 
        {},
        context_instance=RequestContext(req)
    )
    
@repo_view
def wiki_page(req, page):
    if not settings.WIKI_BRANCH in req.git.branches():
        return HttpResponseRedirect('init')
    
    if req.POST:
        if 'edit' in req.POST:
            r = wiki_edit(req, fn=page+'.md') 
            if r: return r
        if 'delete' in req.POST:
            return wiki_delete(req, fn=page+'.md') 
    
    if req.GET:
        if 'delete' in req.GET:
            return wiki_delete(req, fn=page+'.md')
        
    try:
        fn = page + '.md'
        f = req.git.get_file(settings.WIKI_BRANCH, fn)
    except GitError:
        try:
            f = req.git.get_file(settings.WIKI_BRANCH, page)
            return HttpResponse(f.read(), content_type='text/plain')
        except:
            raise Http404

    idx = req.git.ls(settings.WIKI_BRANCH)
    idx = filter(lambda x: x.name.endswith('.md'), idx)
    
    return render_to_response(
        'wiki/page.html', 
        {
            'title': page.split('/')[-1].replace('_', ' '),
            'page': f.read(),
            'index': idx,
        },
        context_instance=RequestContext(req)
    )


@login_required
@repo_view
@repo_admin
def wiki_create(req):
    if req.GET:
        if 'dialog' in req.GET:
            return render_to_response(
                'wiki/new-page-dialog.html',
                context_instance=RequestContext(req)
            )
    if req.POST:
        n = req.POST['name']
        if n not in ['', 'create', 'init']:
            req.git.checkout(settings.WIKI_BRANCH)
            open(os.path.join(req.git.path, n+'.md'), 'w').write('_There\'s no content yet_')
            req.git.make_commit(msg='Created %s' % n, author='%s <%s>'%(req.user.get_full_name(),req.user.email))
            req.git.checkout(req.repo.integration)
            return HttpResponseRedirect(n)
    return HttpResponseRedirect('.')

@repo_admin
def wiki_edit(req, fn=None):
    if req.POST:
        req.git.checkout(settings.WIKI_BRANCH)
        os.unlink(os.path.join(req.git.path, fn))
        codecs.open(os.path.join(req.git.path, req.POST['title'] + '.md'), 'wt', 'utf-8').write(req.POST['text'])
        req.git.make_commit(msg=req.POST['commit'], author='%s <%s>'%(req.user.get_full_name(),req.user.email))
        req.git.checkout(req.repo.integration)
        return HttpResponseRedirect(req.POST['title'])
    
@repo_admin
def wiki_delete(req, fn=None):
    if fn == 'Home.md':
        push_message(req, 'ECannot delete home page')
    elif req.POST:
        req.git.checkout(settings.WIKI_BRANCH)
        os.unlink(os.path.join(req.git.path, fn))
        req.git.make_commit(msg='Deleted %s' % fn, author='%s <%s>'%(req.user.get_full_name(),req.user.email))
        req.git.checkout(req.repo.integration)
        push_message(req, 'IWiki page deleted')
    return HttpResponseRedirect('.')
    
    
def generate_homepage(req):
    t = """%s wiki
====

The wiki was successfully created. Now pull the [%s branch](../%s/tree) from the repository and create some pages.
    
""" % (req.repo.name, settings.WIKI_BRANCH, settings.WIKI_BRANCH)
    return t
