#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *
from git import *


@login_required
@repo_view
def fork(req):
    try:
        r = Repository.objects.get(user=req.user, upstream=req.repo)
        return HttpResponseRedirect('/%s/%s'%(req.user.username, r.name))
    except Repository.DoesNotExist:
        pass
        
    if req.GET:
        if 'go' in req.GET:
            u,r = req.user.username, req.repo.name
            repo_clone(u, r, req.repo.user.username)
            repo = Repository(
                user=req.user,
                name=r,
                upstream=req.repo,
                integration='master'
            )
            repo.save()
            Repo(repo.full_path(), repo).setup_fork()
            emit_news(subject=req.user,repo=req.repo,objekt=req.repo,action='fork')
            
            push_message(req, 'IForked')
            return HttpResponseRedirect('/%s/%s' % (u,r))
    else:
        can = not Repository.objects.filter(user=req.user, name=req.repo.name).exists()
        
    return render_to_response(
        'git/fork.html', 
        {
            'can': can
        },
        context_instance=RequestContext(req)
    )

