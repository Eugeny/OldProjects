#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *
from main.forms import *

import datetime


@login_required
@repo_view
def merge_request(req):
    return make_request(req)

        
@repo_admin
def make_request(req):         
    branches = req.git.branches
    if req.POST:
        form = MergeRequestForm(req.POST)
        if form.is_valid(): 
            rev = req.git.rev_parse(form.cleaned_data['branch'])
            MergeRequest(
                author=req.user,
                title=form.cleaned_data['title'],
                head=rev,
                closed=False,
                date=datetime.datetime.now(),
                repository=req.repo,
            ).save()
            push_message(req, 'IRequest sent')
            return HttpResponseRedirect('.')
    else:
        form = MergeRequestForm(
            initial={
                'branch': 'master'
            }
        )
        
    return render_to_response(
        'main/merge-request.html', 
        {
            'form': form,
            'branches': req.git.branches,
        },
        context_instance=RequestContext(req)
    )
    

@repo_view
@upstream_only    
def merge_request_all(req):
    if req.GET and 'hidden' in req.GET:
        rq = MergeRequest.objects.filter(repository__upstream=req.repo).order_by('-date')
    else:
        rq = MergeRequest.objects.filter(repository__upstream=req.repo, closed=False).order_by('-date')
    return render_to_response(
        'main/merge-requests.html', 
        {
            'rq': rq,
        },
        context_instance=RequestContext(req)
    )   
    

@login_required
@repo_view
@upstream_only    
def merge_request_view(req, id):
    rq = get_object_or_404(MergeRequest, id=id)

    if req.POST and not rq.closed:
        MergeRequestComment(
            author=req.user,
            text=req.POST['text'],
            date=datetime.datetime.now(),
            request=rq,
        ).save()
    
    return render_to_response(
        'main/merge-request-view.html', 
        {
            'rq': rq,
        },
        context_instance=RequestContext(req)
    )   


@login_required
@repo_view
@repo_admin
@upstream_only    
def merge_request_close(req, id):
    rq = get_object_or_404(MergeRequest, id=id)
    if req.repo.user == req.user and not rq.closed:
        rq.closed = True
        rq.save()
        MergeRequestComment(
            author=req.user,
            text='Request closed.',
            date=datetime.datetime.now(),
            request=rq,
        ).save()
    return HttpResponseRedirect('../all')
    
