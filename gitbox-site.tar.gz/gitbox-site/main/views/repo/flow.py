#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext

from main.models import *
from main.helpers import *
from main.highlight import *

import main.graph
from git import *


@repo_view
@require_master
@upstream_only
def flow(req):
    highlight = None
    if req.GET and req.user.is_authenticated():
        if 'merge' in req.GET:
            what = req.GET['merge'].replace(':', '/')
            if req.repo.user != req.user:
                push_message(req, 'WNice try')
            else:
                if req.git.merge(what):
                    push_message(req, 'ISuccessful merge')
                else:
                    push_message(req, 'IMerge produced conflicts and was rolled back. You need to merge locally and resolve conflicts.')
            return HttpResponseRedirect('flow')
        if 'head' in req.GET:
            highlight = req.GET['head']
    if req.POST and user.is_authenticated():
        if 'integration' in req.POST and req.user == req.repo.user:
            nb = req.POST['integration']
            try:
                req.git.checkout(nb)
                push_message(req, 'IBranch changed')
                req.repo.integration = nb
                req.repo.save()
            except GitError:
                req.git.checkout(req.repo.integration)
                push_message(req, 'WFailed to change branch')
                
    
    lbls,code,height,heads = main.graph.generate(req.git.graph_data(), '/%s/%s/master/commit/'%(req.repo.user.username, req.repo.name))
    return render_to_response(
        'git/flow.html', 
        {
            'data': code,
            'labels': lbls,
            'height': height,
            'heads': heads,
            'branches': req.git.branches,
            'hl': highlight,
        },
        context_instance=RequestContext(req)
    )


@repo_view
def flow_ajax(req, ish=None):
    commit = req.git.commit(ish)
    diff = req.git.diff(commit.hexsha) 
    return render_to_response(
        'git/flow-ajax.html', 
        {
            'c': commit,
            'diff': diff,
            'ajax': True,
        },
        context_instance=RequestContext(req)
    )

