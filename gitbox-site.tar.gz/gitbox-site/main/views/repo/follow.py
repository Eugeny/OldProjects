#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *


@login_required
@repo_view
def follow(req):
    if not req.user.followed_repos.filter(id=req.repo.id).exists():
        req.user.followed_repos.add(req.repo)
        emit_news(subject=req.user, repo=req.repo, objekt=req.repo, action='followrepo')
    return HttpResponseRedirect('/%s/%s'%(req.repo.user.username,req.repo.name))
    
@login_required
@repo_view
def unfollow(req):
    if req.user.followed_repos.filter(id=req.repo.id).exists():
        req.user.followed_repos.remove(req.repo)
    return HttpResponseRedirect('/%s/%s'%(req.repo.user.username,req.repo.name))    
