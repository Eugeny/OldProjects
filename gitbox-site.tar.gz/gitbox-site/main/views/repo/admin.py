#coding: utf-8 
from django.http import *
from django.core.servers.basehttp import FileWrapper
from django.shortcuts import *
from django.template import RequestContext
from django.contrib.auth.decorators import *
from django.contrib.auth.models import *

from main.models import *
from main.helpers import *


@login_required
@repo_view
@repo_admin
def admin(req):
    if req.POST:
        if 'set_public' in req.POST:
            req.repo.private = req.POST['private'] == '1'
            req.repo.save()
            push_message(req, 'ISaved')
        if 'add_commiter' in req.POST:
            un = req.POST['username']
            try:
                u = User.objects.get(username=un)
                req.repo.permission_set.filter(user=u).delete()
                req.repo.permission_set.create(
                    user = u,
                    read = True,
                    write = True
                )
                push_message(req, 'ICommiter added')
            except User.DoesNotExist:
                push_message(req, 'WNo such user')
        if 'delete' in req.POST:
            if req.user == req.repo.user:
                req.repo.forks.update(upstream=None)
                req.repo.delete()
                push_message(req, 'IRepository deleted.')
                return HttpResponseRedirect('/dashboard')
                
    if req.GET:
        if 'del_commiter' in req.GET:
            try:
                u = User.objects.get(username=req.GET['del_commiter'])
                req.repo.permission_set.filter(user=u).delete()
                push_message(req, 'ICommiter deleted')
                return HttpResponseRedirect('/%s/%s/admin' % (req.repo.user.username, req.repo.name))
            except User.DoesNotExist:
                push_message(req, 'WNo such user')
            
            
    du = req.git.disk_usage()
    
    return render_to_response(
        'main/repo-admin.html', 
        {
            'disk_usage': du,
        },
        context_instance=RequestContext(req)
    )



@repo_view
def empty(req):
    return render_to_response(
        'main/repo-empty.html', 
        {},
        context_instance=RequestContext(req)
    )    
