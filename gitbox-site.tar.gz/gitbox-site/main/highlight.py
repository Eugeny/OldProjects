from pygments import highlight
from pygments.lexers import guess_lexer_for_filename, guess_lexer
from pygments.formatters import HtmlFormatter

def highlight_code(fn, code, css='code', linepfx='L'):
    try:
        lexer = guess_lexer_for_filename(fn, code)
    except:
        lexer = guess_lexer(code)
        
    formatter = HtmlFormatter(
        lineanchors=linepfx, 
        hl_lines=range(0,len(code.splitlines())), 
        anchorlinenos=True, 
        linenos=True, 
        cssclass=css
    )
    result = highlight(code, lexer, formatter)
    return result

def get_highlight_styles(css='code'):
    return HtmlFormatter(style='friendly', nobackground=True).get_style_defs('.'+css)

