import random


def generate(data, commitlink):
    CELL = 25
    LINE_COLORS = '#127dd8', '#6e9e2c', '#777777', '#dd9b0e', '#ba2911'
    NODE_COLOR = '#fff'
    NODE_SIZE = 5
    lcidx = 0
    
    lines = []
    linesy = []
    linecolor = [LINE_COLORS[x%len(LINE_COLORS)] for x in range(0,100)]
    
    code = 'ctx=$("#canvas")[0].getContext("2d");ctx.scale(1,1);ctx.lineWidth=2;'
    nodes = []
    labels = []
    aheads = []
    y = 0

    for l in data.split('---BOUND---'):
        l = l.split('\n')
        if l[0] == '': 
            l = l[1:]
        if l == []:
            break

        ish = l[0].split()[0]
        heads = []
        if '(' in l[0]:
            heads = l[0].split(' ',1)[1].strip('() ').split()
            heads = [x.strip(' ,') for x in heads]
            if 'HEAD' in heads:
                heads.remove('HEAD')
        aheads.extend([(x,ish) for x in heads])
        parents = l[1].split()
        subj = l[4]
        auth = l[2]
        
        np = len(lines)

        ch = []
        idx = -1
        for line in lines:
            idx += 1
            if line:
                if ish in line:
                    line[ish] = True
                    ch.append(idx)
                obs = True
                for l in line:
                    if not line[l]:
                        obs = False
                        break
                if obs:
                    lines[idx] = None
                    
        np = len(lines)
        idx = 0
        for l in lines:
            if not l:
                np = idx
            idx += 1

            
        for c in ch:
            code += 'ctx.strokeStyle="%s";' % linecolor[c]
            code += 'ctx.beginPath();ctx.moveTo(%i,%i);ctx.lineTo(%i,%i);ctx.closePath();ctx.stroke();' % (
                c*CELL+CELL/2, linesy[c]+CELL/2, c*CELL+CELL/2, y-CELL/2)
            code += 'ctx.beginPath();ctx.moveTo(%i,%i);ctx.lineTo(%i,%i);ctx.closePath();ctx.stroke();' % (
                c*CELL+CELL/2, y-CELL/2, np*CELL+CELL/2, y+CELL/2)
            

        idx = 0
        for l in lines:
            if not l and np != idx:
                linecolor[idx] = LINE_COLORS[lcidx]
                lcidx = (lcidx+1)%len(LINE_COLORS)
            idx += 1

        if np < len(lines):
            lines[np] = dict((x,False) for x in parents)
            linesy[np] = y
        else:
            lines.append(dict((x,False) for x in parents))    
            linesy.append(y)
 
        maxright = 0
        idx = 0
        for l in lines:
            if l is not None:
                maxright = idx
            idx += 1
            
        nodes.append((np,y,linecolor[np],len(parents)>1))

        c = Commit()
        c.x, c.y = (maxright+1)*CELL+10, y
        c.subj = subj
        c.author = auth
        c.ish = ish
        c.heads = heads
        labels.append(c)
        
        y += CELL
        
        
    for n in nodes:
        if n[3]:
            code += 'ctx.beginPath();ctx.strokeStyle="%s";ctx.fillStyle="%s";ctx.arc(%i,%i,%i,0,Math.PI*2,true);ctx.closePath();ctx.fill();ctx.stroke();' % (
                n[2], NODE_COLOR, n[0]*CELL+CELL/2, n[1]+CELL/2, NODE_SIZE*1.7)
        code += 'ctx.beginPath();ctx.strokeStyle="%s";ctx.fillStyle="%s";ctx.arc(%i,%i,%i,0,Math.PI*2,true);ctx.closePath();ctx.fill();ctx.stroke();' % (
            n[2], NODE_COLOR, n[0]*CELL+CELL/2, n[1]+CELL/2, NODE_SIZE)
    
    return labels, code, y, aheads


class Commit:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.ish = ''
        self.author = ''
        self.subj =  ''
        self.heads = []
        
