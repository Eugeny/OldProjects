import hashlib
from django import template
from main.helpers import *
from django.contrib.auth.models import User
from django.utils.safestring import mark_safe
from datetime import *


register = template.Library()

@register.filter
def chmod(value):
    if value:
        return mode_string(int(value))
    return ''
   
@register.filter
def octal(value):
    return (u'%o' % value).zfill(6)

@register.filter
def date(value):
    return datetime.fromtimestamp(value).date()

@register.filter
def date_time(value):
    return datetime.fromtimestamp(value)

@register.filter
def unsafe(value):
    return str(value)
    
@register.filter
def ish(value):
    return value[:8]

@register.filter
def feeddate(value):
    tz = value.strftime('%z')
    if tz == '':
        tz = '+00:00'
    else:
        tz = '%s:%s' % (tz[0:3], tz[4,6])
    return value.strftime('%Y-%m-%dT%H:%M:%S') + tz
    
@register.filter
def avatar(user, size):
    try:
        e = user.email.strip().lower()
    except:
        e = user.split()[-1].strip('<> \t\n').lower()
    return 'http://www.gravatar.com/avatar/%s?r=pg&d=mm&s=%i' % (hashlib.md5(e).hexdigest(), size)
        

@register.filter
def gituser(s):
    try:
        u = User.objects.get(email=s.email)
    except User.DoesNotExist:
        u = None
    return u
    
@register.filter
def gituserbox(s):
    n = s.name
    e = s.email
    u = gituser(s)
    href = ''
    if u:
        href = '/' + u.username
    return mark_safe('<a class="userbox" href="%s"><img src="%s" class="avatar"/><p>%s</p>%s</a>' % (href, avatar(s, 25), n, e))
gituserbox.is_safe = True    
