from django.shortcuts import *
from django.http import *
from django.contrib.auth.models import *
from main.models import *
import mygit
import settings
import subprocess
import os
from dateutil.relativedelta import *
from datetime import *


def repo_view(f):
    def proxy(req, repouser=None, section=None, reponame=None, **kwargs):
        try:
            user = auth.models.User.objects.get(username=repouser)
            req.repo = Repository.objects.get(user=user, name=reponame)
        except auth.models.User.DoesNotExist:
            raise Http404
        except Repository.DoesNotExist:
            raise Http404
                
        r = not req.repo.private
        if req.user.is_authenticated():
            try:
                r = Permission.objects.get(repository=req.repo, user=req.user).read
            except Permission.DoesNotExist:
                pass
        if req.user == req.repo.user:
            r = True
        if not r:
            return HttpResponseForbidden('Forbidden')
            
        req.section = section
        req.git = mygit.Repo(req.repo.full_path(), req.repo)
        return f(req, **kwargs)
    return proxy

def git_view(f):
    def proxy(req, treeish=None, path=None, **kwargs):
        req.treeish = treeish
        req.repopath = path
        req.repoaction = f.__name__
        kwargs.update({'path':path})
        return f(req, **kwargs)
    return require_master(proxy)

def require_master(f):
    def proxy(req, **kwargs):
        if len(req.git.branches) == 0:
            return HttpResponseRedirect('/%s/%s/empty' % (req.repo.user.username, req.repo.name))
        return f(req, **kwargs)
    return proxy

def feeder(f):
    def proxy(req, feed=False, **kwargs):
        if not hasattr(req, 'feed'):
            req.feed = feed
        return f(req, **kwargs)
    return proxy

def upstream_only(f):
    def proxy(req, **kwargs):
        if req.repo.upstream:
            push_message(req, 'WRedirected to upstream repository')
            return HttpResponseRedirect(req.META['PATH_INFO'].replace(
                '/%s/%s/'%(req.repo.user.username,req.repo.name),
                '/%s/%s/'%(req.repo.upstream.user.username, req.repo.upstream.name)
            ) + '?' + req.META['QUERY_STRING'])
        return f(req, **kwargs)
    return proxy


def repo_admin(f):
    def proxy(req, **kwargs):
        if req.repo.user != req.user:
            return HttpResponseForbidden('Forbidden')
        return f(req, **kwargs)
    return proxy

def detect_mime(fn):
    p = subprocess.Popen(['file', '-b', '--mime-type', fn], stdout=subprocess.PIPE)
    p.wait()
    return p.stdout.read().strip('\n')
    
def push_message(req, t):
    req.user.message_set.create(message=t)    
    
def context_processor(req):
    d = {}
    
    d.update({
        'domain': settings.DOMAIN,
    })
    
    if req.user.is_authenticated():
        d.update({
            'unread_messages': Message.objects.filter(read=False, subject=req.user, owner=req.user).count()
        })
        if hasattr(req, 'repo'):
            d.update({
                'following': req.repo.followers.filter(id=req.user.id).exists(),
            })
        
    if hasattr(req, 'repo'):
        d.update({
            'repository': req.repo,
            'git': req.git,
            'my_repo': req.repo.user == req.user,
            'section': req.section,
        })    
        
    if hasattr(req, 'treeish'):
        p = ''
        paths = []
        for x in filter(lambda x:len(x)>0, req.repopath.split('/')):
            paths.append((x, p+x))
            p += x + '/'
            
        ps = '/'.join(x[0] for x in paths) if paths != [] else ''
        d.update({
            'treeish': req.treeish,
            'repopath': paths,
            'repopathstr': ps,
            'repoaction': req.repoaction,
            'branches': req.git.branches,
            'tags': req.git.tags,
        })    
    return d
    
def mode_string(mode):
    return ('r' if mode & 256 else '-') + \
           ('w' if mode & 128 else '-') + \
           ('x' if mode & 64 else '-') + \
           ('r' if mode & 32 else '-') + \
           ('w' if mode & 16 else '-') + \
           ('x' if mode & 8 else '-') + \
           ('r' if mode & 4 else '-') + \
           ('w' if mode & 2 else '-') + \
           ('x' if mode & 1 else '-')

def emit_news(subject, repo=None, objekt=None, action=''):
    News(
        date=datetime.now(),
        subject=subject,
        objekt=objekt,
        repository=repo,
        action=action,
        misc=None,
    ).save()
    
    
def register_callback(user):
    emit_news(subject=user, objekt=user, action='welcome')
    user.first_name = 'newbie'
    user.last_name = user.username
    user.save()
    
    
