from django import forms
from django.forms.widgets import *
from models import *
from django.contrib.auth.models import *
from git import *


class EditAccountForm(forms.Form):
    error_css_class = 'error'
    
    first_name = forms.CharField(max_length=100)
    last_name = forms.CharField(max_length=100)
    email = forms.EmailField()


class AddRepoForm(forms.Form):
    error_css_class = 'error'
    
    name = forms.SlugField(max_length=30)
    
    def clean_name(self):
        n = self.cleaned_data['name']
        if repo_exists(self.user.username, n) or \
            Repository.objects.filter(user=self.user, name=n).exists():
            raise forms.ValidationError('You already have a repository with such name')
        return n
        
        
class AddBugForm(forms.Form):
    error_css_class = 'error'
    
    title = forms.CharField(label='Short summary', max_length=300)
    text = forms.CharField(widget=forms.Textarea, label='Description', max_length=3000)

class MergeRequestForm(forms.Form):
    error_css_class = 'error'
    
    branch = forms.CharField(max_length=300)
    title = forms.CharField(max_length=300)
        
        
