#!/bin/sh
mysqldump -u root -p gitbox > db
