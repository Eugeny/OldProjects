#!/bin/sh
./manage.py runserver 10.10.1.1:8080
