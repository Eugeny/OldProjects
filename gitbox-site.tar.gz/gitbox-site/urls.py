from django.conf.urls.defaults import *
from django.contrib import admin, auth
import registration
from registration.forms import *
from main.helpers import register_callback
admin.autodiscover()


handler500 = 'main.views.core.http500'


urlpatterns = patterns('',
    (r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': 'media'}),
    (r'^admin/doc/', include('django.contrib.admindocs.urls')),
    (r'^admin/', include(admin.site.urls)),
    url(r'^accounts/register/$', 'registration.views.register', 
        {
            'form_class': RegistrationFormUniqueEmail,
            'profile_callback': register_callback,
        }, 
        name='registration_register'),
    (r'^accounts/', include('registration.urls')),
)

urlpatterns += patterns('main.views.core',
    (r'^$', 'index'),
    (r'^dashboard$', 'dashboard'),
    (r'^dashboard/feed/(?P<token>.+)$', 'dashboard_feed', { 'feed': True }),
    (r'^account$', 'account'),
    (r'^add-repo$', 'addrepo'),
    (r'^follow/(?P<uid>\d+)$', 'follow'),
    (r'^unfollow/(?P<uid>\d+)$', 'unfollow'),
)

repospecpatterns = patterns('main.views.repo',
    (r'^admin$', 'admin', { 'section': 'admin' }),
    (r'^empty$', 'empty', { 'section': 'admin' }),
    (r'^fork$', 'fork', { 'section': 'admin' }),
    (r'^flow$', 'flow', { 'section': 'flow' }),
    (r'^flow-ajax/(?P<ish>.+)$', 'flow_ajax'),
    (r'^follow$', 'follow', { 'section': 'admin' }),
    (r'^unfollow$', 'unfollow', { 'section': 'admin' }),
    (r'^merge-request$', 'merge_request', { 'section': 'requests' }),
    (r'^merge-request/all$', 'merge_request_all', { 'section': 'requests' }),
    (r'^merge-request/close/(?P<id>\d+)$', 'merge_request_close', { 'section': 'requests' }),
    (r'^merge-request/(?P<id>\d+)$', 'merge_request_view', { 'section': 'requests' }),
)

repopatterns = patterns('main.views.git',
    # feeds
    (r'^log/feed/*$', 'log', { 'path': '', 'feed': True }),
    # 
    (r'^blob/(?P<path>.+)$', 'blob'),
    (r'^raw/(?P<path>.+)$', 'raw'),
    (r'^tree/(?P<path>.+)$', 'tree'),
    (r'^blame/(?P<path>.+)$', 'blame'),
    (r'^log/(?P<path>.+)$', 'log'),
    (r'^log/*$', 'log', { 'path': '' }),
    (r'^tree/*$', 'tree', { 'path': '' }),
    (r'^commit/(?P<commitish>.+)$', 'commit', { 'path': '' }),
    (r'^compare/(?P<commitish>.+)$', 'compare', { 'path': '' }),
    (r'^patch/(?P<commitish>.+)$', 'patch', { 'path': '' }),
)

bugpatterns = patterns('main.views.bugs',
    (r'^$', 'buglist'),
    (r'^new$', 'new'),
    (r'^(?P<id>\d+)$', 'single'),
)

wikipatterns = patterns('main.views.repo',
    (r'^$', 'wiki_page', {'page': 'Home'}),
    (r'^init', 'wiki_init'),
    (r'^create', 'wiki_create'),
    (r'^(?P<page>.+)$', 'wiki_page'),
)

mailpatterns = patterns('main.views.mail',
    (r'^$', 'maillist'),
    (r'^/(?P<uid>\d+)$', 'single'),
)


urlpatterns += patterns('',
    (r'^mail', include(mailpatterns)),
)


urlpatterns += patterns('',
    # Repo root - show README 
    (r'^(?P<repouser>[\w\-\.]+)/(?P<reponame>[\w\.\-]+)/*$', 'main.views.git.tree', {'path':'','readme':True,'treeish':'master','section':''}), 
    # Bug tracker
    (r'^(?P<repouser>[\w\-\.]+)/(?P<reponame>[\w\.\-]+)/bugs/', include(bugpatterns), {'section':'bugs'}),
    # Wiki
    (r'^(?P<repouser>[\w\-\.]+)/(?P<reponame>[\w\.\-]+)/wiki/', include(wikipatterns), {'section':'wiki'}),
    # Repo special - admin, fork, etc.
    (r'^(?P<repouser>[\w\-\.]+)/(?P<reponame>[\w\.\-]+)/', include(repospecpatterns)),
    # GIT operations on master
    (r'^(?P<repouser>[\w\-\.]+)/(?P<reponame>[\w\.\-]+)/*', include(repopatterns), { 'treeish': 'master', 'section': 'code' }),
    # GIT operations on tree
    (r'^(?P<repouser>[\w\-\.]+)/(?P<reponame>[\w\.\-]+)/(?P<treeish>[\w\.\-]+)/*', include(repopatterns), { 'section': 'code' }),
    # Profile
    (r'^(?P<username>[\w\-\.]+)$', 'main.views.core.profile'),
)

