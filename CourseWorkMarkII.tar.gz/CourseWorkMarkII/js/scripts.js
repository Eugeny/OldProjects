(function() {
  var Interpolator, LagrangeInterpolator, NewtonInterpolator, SmoothInterpolator, box, fx2html, getFx, getPoints, tex2html;

  Interpolator = (function() {

    function Interpolator() {}

    Interpolator.prototype.interpolate = function(data) {};

    return Interpolator;

  })();

  SmoothInterpolator = (function() {

    function SmoothInterpolator() {}

    SmoothInterpolator.prototype.interpolate = function(data) {
      var i, sum1, sum2, _fn, _ref,
        _this = this;
      sum1 = M('0');
      sum2 = M('0');
      _fn = function(i) {
        var dx;
        dx = M('x')['-'](M('' + data[i][0]));
        dx = dx['*'](dx);
        sum1 = sum1['+'](M('' + data[i][1])['/'](dx));
        return sum2 = sum2['+'](M('1')['/'](dx));
      };
      for (i = 0, _ref = data.length; 0 <= _ref ? i < _ref : i > _ref; 0 <= _ref ? i++ : i--) {
        _fn(i);
      }
      return sum1['/'](sum2);
    };

    return SmoothInterpolator;

  })();

  LagrangeInterpolator = (function() {

    function LagrangeInterpolator() {}

    LagrangeInterpolator.prototype.interpolate = function(data) {
      var i, sum, _fn, _ref,
        _this = this;
      sum = M('0');
      _fn = function(i) {
        var j, li, _fn2, _ref2;
        li = M('1');
        _fn2 = function(j) {
          var down, item, up;
          if (j !== i) {
            console.log(data);
            up = M('x')['-'](M(data[j][0] + ''));
            down = data[i][0] - data[j][0];
            item = up['/'](M(down + ''));
            return li = li['*'](item);
          }
        };
        for (j = 0, _ref2 = data.length; 0 <= _ref2 ? j < _ref2 : j > _ref2; 0 <= _ref2 ? j++ : j--) {
          _fn2(j);
        }
        return sum = sum['+'](li['*'](M(data[i][1] + '')));
      };
      for (i = 0, _ref = data.length; 0 <= _ref ? i < _ref : i > _ref; 0 <= _ref ? i++ : i--) {
        _fn(i);
      }
      return sum;
    };

    return LagrangeInterpolator;

  })();

  NewtonInterpolator = (function() {

    function NewtonInterpolator() {
      this.cache = {};
    }

    NewtonInterpolator.prototype.divdiff = function(data, from, to) {
      var cid, r;
      cid = "" + from + "-" + to;
      r = this.cache[cid];
      if (!r) {
        if (from === to) {
          r = data[from][1];
        } else {
          r = (this.divdiff(data, from + 1, to) - this.divdiff(data, from, to - 1)) / (data[to][0] - data[from][0]);
        }
      }
      this.cache[cid] = r;
      return r;
    };

    NewtonInterpolator.prototype.interpolate = function(data) {
      var i, sum, _fn, _ref,
        _this = this;
      sum = M('0');
      _fn = function(i) {
        var j, li, _fn2, _ref2;
        li = M('' + _this.divdiff(data, 0, i));
        if (i > 0) {
          _fn2 = function(j) {
            var item;
            item = M('x')['-'](M('' + data[j][0]));
            return li = li['*'](item);
          };
          for (j = 0, _ref2 = i - 1; 0 <= _ref2 ? j <= _ref2 : j >= _ref2; 0 <= _ref2 ? j++ : j--) {
            _fn2(j);
          }
        }
        return sum = sum['+'](li);
      };
      for (i = 0, _ref = data.length; 0 <= _ref ? i < _ref : i > _ref; 0 <= _ref ? i++ : i--) {
        _fn(i);
      }
      return sum;
    };

    return NewtonInterpolator;

  })();

  tex2html = function(tex) {
    setTimeout(function() {
      MathJax.Hub.PreProcess();
      return MathJax.Hub.Process();
    }, 1);
    return "$$" + tex + "$$";
  };

  fx2html = function(fx) {
    return tex2html(fx.s('text/latex').s);
  };

  getPoints = function(fx, from, to, step) {
    var i, x, xs, ys;
    xs = (function() {
      var _ref, _results;
      _results = [];
      for (i = 0, _ref = (to - from) / step; 0 <= _ref ? i <= _ref : i >= _ref; 0 <= _ref ? i++ : i--) {
        _results.push(from + step * i);
      }
      return _results;
    })();
    ys = (function() {
      var _i, _len, _results;
      _results = [];
      for (_i = 0, _len = xs.length; _i < _len; _i++) {
        x = xs[_i];
        _results.push(fx(x));
      }
      return _results;
    })();
    return [xs, ys];
  };

  box = function(xs, ys) {
    var i;
    return (function() {
      var _ref, _results;
      _results = [];
      for (i = 0, _ref = xs.length; 0 <= _ref ? i < _ref : i > _ref; 0 <= _ref ? i++ : i--) {
        _results.push([xs[i], ys[i]]);
      }
      return _results;
    })();
  };

  $('#sample-data').click(function() {
    var data, i, l, m, _fn, _ref,
      _this = this;
    data = [[0.0, 0], [0.1, 0.41], [0.2, 0.79], [0.3, 1.13], [0.4, 1.46], [0.5, 1.76], [0.6, 2.04], [0.7, 2.30], [0.8, 2.55], [0.9, 2.79], [1.0, 3.01]];
    m = Math.floor(Math.random() * 10) * 0.05;
    _fn = function(i) {
      return data[i][1] += Math.pow(-1, i) * m;
    };
    for (i = 0, _ref = data.length; 0 <= _ref ? i < _ref : i > _ref; 0 <= _ref ? i++ : i--) {
      _fn(i);
    }
    return $('#data-table').html(((function() {
      var _i, _len, _results;
      _results = [];
      for (_i = 0, _len = data.length; _i < _len; _i++) {
        l = data[_i];
        _results.push("<tr>\n    <td><input style=\"width: 80px\" type=\"text\" value=\"" + l[0] + "\"/></td>\n    <td><input style=\"width: 80px\" type=\"text\" value=\"" + l[1] + "\"/></td>\n</tr>");
      }
      return _results;
    })()).join(''));
  });

  getFx = function() {
    var fx;
    return new Function('x', 'return ' + $('#function').val());
    fx = M($('#function').val());
    return fx.compile('x');
  };

  $('#compare').click(function() {
    var data, e, eavg, emax, err, fxc, i, idata, ifrom, istep, ito, xs, ys, _ref, _ref2;
    idata = window.interpolatedData;
    fxc = getFx();
    ifrom = parseFloat($('#int-from').val());
    ito = parseFloat($('#int-to').val());
    istep = idata[1][0] - idata[0][0];
    _ref = getPoints(fxc, ifrom, ito, istep), xs = _ref[0], ys = _ref[1];
    data = box(xs, ys);
    err = (function() {
      var _ref2, _results;
      _results = [];
      for (i = 0, _ref2 = data.length; 0 <= _ref2 ? i < _ref2 : i > _ref2; 0 <= _ref2 ? i++ : i--) {
        _results.push([data[i][0], Math.abs(data[i][1] - idata[i][1])]);
      }
      return _results;
    })();
    emax = 0;
    eavg = 0;
    for (i = 0, _ref2 = err.length; 0 <= _ref2 ? i < _ref2 : i > _ref2; 0 <= _ref2 ? i++ : i--) {
      e = err[i][1];
      emax = Math.max(emax, e);
      eavg += e / err.length;
    }
    $('#formula').html(tex2html("e_{max} = " + emax + "; e_{avg} = " + eavg + " "));
    return $.plot($("#plot"), [
      {
        data: data,
        lines: {
          show: true,
          fill: true
        }
      }, {
        data: idata,
        lines: {
          show: true,
          fill: true
        }
      }, {
        data: err,
        lines: {
          show: true,
          fill: true
        }
      }
    ]);
  });

  $('#generate').click(function() {
    var data, fxc, i, ifrom, istep, ito, table, xs, ys, _ref, _ref2, _results,
      _this = this;
    table = $('#data-table');
    table.empty();
    fxc = getFx();
    ifrom = parseFloat($('#int-from').val());
    ito = parseFloat($('#int-to').val());
    istep = parseFloat($('#int-step').val());
    _ref = getPoints(fxc, ifrom, ito, istep), xs = _ref[0], ys = _ref[1];
    data = box(xs, ys);
    _results = [];
    for (i = 0, _ref2 = xs.length; 0 <= _ref2 ? i < _ref2 : i > _ref2; 0 <= _ref2 ? i++ : i--) {
      _results.push((function(i) {
        return table.append("<tr>\n    <td><input style=\"width: 80px\" type=\"text\" value=\"" + xs[i] + "\"/></td>\n    <td><input style=\"width: 80px\" type=\"text\" value=\"" + ys[i] + "\"/></td>\n</tr>");
      })(i));
    }
    return _results;
  });

  $('.interpolate').click(function() {
    var ciexpr, data, idata, iexpr, ixs, iys, table, x0, x1, _ref,
      _this = this;
    table = $('#data-table tr');
    data = [];
    table.each(function(i, e) {
      var x, y;
      x = parseFloat($($(e).find('input')[0]).val());
      y = parseFloat($($(e).find('input')[1]).val());
      return data.push([x, y]);
    });
    iexpr = new (eval($(this).attr('data-class')))().interpolate(data);
    ciexpr = iexpr.compile('x');
    $('#formula').html(fx2html(iexpr));
    x0 = data[0][0];
    x1 = data[data.length - 1][0];
    _ref = getPoints(ciexpr, x0, x1, (x1 - x0) / 1000), ixs = _ref[0], iys = _ref[1];
    idata = box(ixs, iys);
    window.interpolatedData = idata;
    return $.plot($("#plot"), [
      {
        data: data,
        lines: {
          show: true,
          fill: true
        },
        points: {
          show: true
        }
      }, {
        data: idata,
        lines: {
          show: true,
          fill: true
        }
      }
    ]);
  });

}).call(this);
