#!/bin/bash
git add .
git add -u .
git commit
git push origin master

