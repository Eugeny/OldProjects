using System;
using SyncStream;
	
namespace SampleClient
{
	class MainClass
	{
		static byte[] stuff = {1,2,3,90};
		
		public static void Main(string[] args)
		{
			Socket s = new Socket(new TcpImplementation());
			s.Receive += new Socket.ReceiveEvent(OnReceive);
			s.DebugName = "Socket";
			s.Connect("127.0.0.1:1111");
			Console.WriteLine("Enter your message to send it");
			Console.WriteLine("Enter \'raw\' to send raw data and desync remote socket");
			Console.WriteLine("Enter \'q\' to exit");
			s.Send(new Packet("message", new Argument("text", "Hello")));
			while (true) {
				string ss = Console.ReadLine();
				if (ss.Equals("q")) Environment.Exit(0); else
				if (ss.Equals("raw")) s.SendRaw(stuff, 0, stuff.Length); else {
					Console.WriteLine(">> " + ss);
					Packet p = new Packet("message", new Argument("text", ss));
					p.Important = true;
					s.Send(p);
				}
			}
		}
			                              
		public static void OnReceive(Socket s, Packet p) {
			Console.WriteLine("<< " + p["text"]);
		}
	}
}