using System;
using SyncStream;

namespace SampleServer
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			Server s = new Server(new TcpImplementation());
			
			s.BindInfo = "any:1111";
			s.Connect += new Server.ConnectEvent(OnConnect);
			s.StartServer();
		}
			                              
		public static void OnConnect(Socket s) {
			Console.WriteLine("New connection");
			s.DebugName = "Socket";
			s.Receive += new Socket.ReceiveEvent(OnReceive);
		}
		
		public static void OnReceive(Socket s, Packet p) {
			Console.WriteLine("<< " + p);
			Packet pp = new Packet("message", new Argument("text", "You said: \"" + p["text"] + "\"."));
			Console.WriteLine(">> " + pp);
			s.Send(pp);
		}
	}
}