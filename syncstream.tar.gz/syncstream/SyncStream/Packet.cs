using System;
using System.Text;
using System.Collections.Generic;

namespace SyncStream
{
	public class Packet
	{
		public string Command = "none";
		public List<Argument> Arguments = new List<Argument>();
		
		/// <summary>
		/// Gets/sets if this packet should be sent using guaranteed delivery mechanism
		/// </summary>
		public bool Important = false; 
		
		/// <summary>
		/// Gets/sets if the packet is utilitary. Utilitary packets are processed internally by SyncStream and are not presented to the host application.
		/// </summary>
		public bool Utilitary = false;
		
		
		internal const int DefaultResendInterval = 200;
		internal int ResendInterval = DefaultResendInterval;
		internal int RetriesLeft = 3;
		internal int UID = 0;
		
		public Packet() { }
		
		/// <summary>
		/// Constructs a packet
		/// </summary>
		/// <param name="command">Packet command</param>
		/// <param name="args">Arguments included in packet</param>
		public Packet(string command, params Argument[] args) {
			Command = command;
			foreach (Argument a in args)
				Arguments.Add(a);
		}
		
		/// <summary>
		/// Gets an argument by name
		/// </summary>
		/// <param name="key">Argument name</param>
		public Argument this[string key] {
			get {
				foreach (Argument a in Arguments)
					if (a.Name.Equals(key))
						return a;
				return null;
			}
		}
		
		/// <summary>
		/// Deserializes packet from a byte buffer
		/// </summary>
		/// <param name="buf">Buffer</param>
		/// <param name="start">Starting index</param>
		/// <param name="len">Length of the data</param>
		public static Packet ParseFrom(byte[] buf, int start, int len) {
			Packet r = new Packet();
			int p = start;
			
			int flags = buf[p++];
			r.Utilitary = (flags & (int)PacketFlags.Utility) != 0;
			r.Important = (flags & (int)PacketFlags.Important) != 0;
			
			int l = buf[p++] * 256;
			l += buf[p++];
			
			r.Command = Encoding.UTF8.GetString(buf, p, l);
			
			p += l;
			
			while (p < start + len) {
				Argument x = new Argument();
				r.Arguments.Add(x);
				p += Argument.DeserializeFrom(buf, p, x);
			}
			
			return r;
		}
		
		private byte[] Serialize() {
			byte[] buf = new byte[Socket.BufferSize];
			byte[] s;
			int p = 0;
			
			byte f = 0;
			if (Utilitary) f += (int)PacketFlags.Utility;
			if (Important) f += (int)PacketFlags.Important;
			
			buf[p++] = f;
			
			s = Encoding.UTF8.GetBytes(Command);
			buf[p++] = (byte)(s.Length / 256 % 256);
			buf[p++] = (byte)(s.Length % 256);
			s.CopyTo(buf, p);
			p += s.Length;
			
			foreach (Argument a in Arguments)
				p += a.SerializeInto(ref buf, p);
			
			byte[] res = new byte[p];
			for (int i = 0; i < p; i++) 
				res[i] = buf[i];
			
			return res;
		}
		
		public override string ToString()
		{
			string r = Command + "(";
			foreach (Argument x in Arguments) {
				r += x.Name + "=" + x.ToString();
				if (Arguments.IndexOf(x) != Arguments.Count - 1)
					r += ", ";
			}
			r += ")";
			return r;
		}

		/// <summary>
		/// Serializes packet into a byte buffer.
		/// </summary>
		/// <returns>Serialized packet</returns>
		public byte[] Prepare() {
			byte[] data = Serialize();
			
			byte[] buffer = new byte[data.Length + 5];
			
			int l = data.Length + 5;
			buffer[0] = (byte)(l % 256); l /= 256;
			buffer[1] = (byte)(l % 256); l /= 256;
			buffer[2] = (byte)(l % 256); l /= 256;
			buffer[3] = (byte)(l % 256); l /= 256;
			buffer[4] = GetChecksum(data, 0, data.Length);
				
			data.CopyTo(buffer, 5);
			
			return buffer;
		}
		
		/// <summary>
		/// Gets the 8-bit checksum for the packet data
		/// </summary>
		/// <param name="packetdata">Buffer</param>
		/// <param name="start">Starting index</param>
		/// <param name="len">Length of the data</param>
		/// <returns>Checksum for the packet</returns>
		public static byte GetChecksum(byte[] packetdata, int start, int len) {
			int r = 0;
			for (int i = 0; i < len; i++) 
				r += packetdata[start + i] * packetdata[start + i] % 65536;
			return (byte)(r % 256);
		}
		
		/// <summary>
		/// Validates the 8-bit checksum for this packet
		/// </summary>
		/// <param name="sum">Checksum to validate</param>
		/// <param name="packetdata">Buffer</param>
		/// <param name="start">Starting index</param>
		/// <param name="len">Length of the data</param>
		/// <returns>Validation result</returns>
		public static bool ValidateChecksum(byte sum, byte[] packetdata, int start, int len) {
			return GetChecksum(packetdata, start, len) == sum;
		}
		
		private enum PacketFlags {
			None = 0,
			Utility = 1,
			Important = 2
		}
	}
	
	public class Argument {
		public string Name = "unnamed";
		public byte[] Data = {};
		public Type DataType = Type.Raw;
		
		public enum Type {
			String = 1,
			Int = 2,
			Raw = 3
		}
		
		public Argument() { }
		
		public Argument(string name, string data) {
			Name = name;
			SetData(data);
		}
		
		public Argument(string name, byte[] data) {
			Name = name;
			SetData(data);
		}
		
		public Argument(string name, long data) {
			Name = name;
			SetData(data);
		}
		
		public void SetData(string data) {
			Data = Encoding.UTF8.GetBytes(data);
			DataType = Type.String;
		}
		
		public void SetData(byte[] data) {
			Data = data;
			DataType = Type.Raw;
		}
		
		public void SetData(long data) {
			SetData(data.ToString());
			DataType = Type.Int;
		}
		
		public string GetString() {
			return Encoding.UTF8.GetString(Data);
		}
				
		public long GetInt() {
			return Int64.Parse(GetString());
		}
				
		public override string ToString ()
		{
			if (DataType == Type.String) return GetString();
			if (DataType == Type.Int) return GetString();
			return "<raw>";
		}

				
		/// <summary>
		/// Serializes packet into a byte buffer.
		/// </summary>
		/// <returns>Serialized packet</returns>
		public int SerializeInto(ref byte[] buf, int idx) {
			int p = idx;
			byte[] s;
			
			s = Encoding.UTF8.GetBytes(Name);
			buf[p++] = (byte)(s.Length / 256 % 256);
			buf[p++] = (byte)(s.Length % 256);
			s.CopyTo(buf, p);
			p += s.Length;
			
			buf[p++] = (byte)DataType;
			
			buf[p++] = (byte)(Data.Length / 256 % 256);
			buf[p++] = (byte)(Data.Length % 256);
			Data.CopyTo(buf, p);
			p += Data.Length;
			
			return p - idx;
		}
		
		/// <summary>
		/// Deserializes argument from a byte buffer
		/// </summary>
		/// <param name="buf">Buffer</param>
		/// <param name="idx">Starting index</param>
		/// <param name="x">Argument to put data into.</param>
		/// <returns>Number of bytes that respresented the argument in the input buffer</returns>
		public static int DeserializeFrom(byte[] buf, int idx, Argument x) {
			int p = idx;
			int l = buf[p++] * 256;
			l += buf[p++];
			
			x.Name = Encoding.UTF8.GetString(buf, p, l);
			
			p += l;
			
			x.DataType = (Type)buf[p++];
			
			l = buf[p++] * 256;
			l += buf[p++];
			
			x.Data = new byte[l];
			
			for (int i = 0; i < l; i++)
				x.Data[i] = buf[p + i];
			
			p += l;
			
			return p - idx;
		}
		
	}
}
