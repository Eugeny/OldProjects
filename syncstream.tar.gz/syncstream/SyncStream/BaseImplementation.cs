using System;

namespace SyncStream
{
	public abstract class BaseImplementation
	{
		public BaseImplementation()	{ }
		
		/// <summary>
		/// Should connect implementation to the remote end specified by connection string.
		/// If the connection attempt fails, should throw Exception.
		/// </summary>
		/// <param name="info">Connection string</param>
		public abstract void Connect(string info);
		
		
		/// <summary>
		/// Should close a connection, if one is estabilished.
		/// </summary>
		public abstract void Disconnect();
		
		/// <summary>
		/// Sends data from buffer.
		/// </summary>
		/// <param name="buf">Buffer</param>
		/// <param name="start">Starting index</param>
		/// <param name="len">Argument to put data into.</param>
		public abstract void Send(byte[] data, int start, int len);
		
		/// <summary>
		/// Receives data into buffer. If no data is available, should do nothing and return zero.
		/// </summary>
		/// <param name="buf">Buffer</param>
		/// <param name="start">Starting index</param>
		/// <param name="len">Argument to put data into.</param>
		/// <returns>Number of bytes received, or 0 if no data is available</returns>
		public abstract int Recv(ref byte[] data, int start, int len);
		
		/// <summary>
		/// Should put implementation into server mode. The Accept() calls are likely to follow.
		/// </summary>
		/// <param name="info">A string representing server data</param>
		public abstract void Listen(string info);
		
		/// <summary>
		/// Should block until a remote connection arrives, then return a ready-to-use Implementation of the same type and go back into server mode.
		/// </summary>
		/// <returns>An Implementation already connected to the remote end and ready for data transfer</returns>
		public abstract BaseImplementation Accept();
		
		public abstract string GetConnectionInfo();
	}

}
