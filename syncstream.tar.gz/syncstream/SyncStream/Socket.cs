using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;

namespace SyncStream
{
	public class Socket
	{
		private BaseImplementation Inner = null;
		private Queue<Packet> SendQueue = new Queue<Packet>();
		private List<Packet> AwaitingConfirmation = new List<Packet>();
		private Thread WorkerA = null, WorkerB = null;
		private byte[] Buffer = new byte[BufferSize];
		private int BufferOffset = 0;
		private Random UIDGen = new Random();
		private int LastUID = 0;
			
		public SocketStatus Status = SocketStatus.Idle;
		
		/// <summary>
		/// Socket's internal clock in ms
		/// </summary>
		public int Clock = 10;
		
		/// <summary>
		/// Status of synchronization with remote endpoint. When sync is lost, no data is guaranteed to be succesfully received.
		/// The sync will be automatically restored when 1-2 valid packets from the remote end are received.
		/// </summary>
		public bool Synced = true;
		
		public ReceiveEvent Receive;
		public EventHandler Disconnected;
		public EventHandler Connected;
		
		/// <summary>
		/// When is not empty, enables debug output to the console with DebugName as prefix
		/// </summary>
		public string DebugName = "";
		
		/// <summary>
		/// Last connection string used
		/// </summary>
		public string ConnectionInfo = "";
		
		public const int BufferSize = 1024 * 1024 * 10;
		
		/// <summary>
		/// Magic byte sequence for packet start. Magic sequences have to be the same on both ends, or sync will be lost permanently
		/// </summary>
		public byte[] MagicStart = {128, 112, 92, 192, 83, 23, 78, 203 };
		
		/// <summary>
		/// Magic byte sequence for packet ending. Magic sequences have to be the same on both ends, or sync will be lost permanently
		/// </summary>
		public byte[] MagicEnd = {228, 12, 192, 122, 85, 22, 182, 213 };
		
		public delegate void ReceiveEvent(Socket s, Packet packet);
		
		/// <summary>
		/// Constructs a new socket.
		/// </summary>
		/// <param name="inn">An underlaying implementation to use</param>
		public Socket(BaseImplementation inn)
		{
			Inner = inn;
		}
		
		/// <summary>
		/// Attempts to connect to a remote end
		/// </summary>
		/// <param name="info">Connection string passed to the underlaying implementation</param>
		public void Connect(string info)
		{
			Debug("Connecting: " + info);
			ConnectionInfo = info;
			Inner.Connect(info);
			Status = SocketStatus.Connected;
			Debug("Success");
			if (Connected != null) Connected(this, null);
			WorkerA = new Thread(new ThreadStart(RunWorkerA));
			WorkerA.Start();
			WorkerB = new Thread(new ThreadStart(RunWorkerB));
			WorkerB.Start();
		}
		
		/// <summary>
		/// Forces a (re)start of receiver and sender threads
		/// </summary>
		public void RestartWorkers() {
			try { WorkerA.Abort(); } catch {}
			try { WorkerB.Abort(); } catch {}
			WorkerA = new Thread(new ThreadStart(RunWorkerA));
			WorkerA.Start();
			WorkerB = new Thread(new ThreadStart(RunWorkerB));
			WorkerB.Start();
		}
		
		public void Disconnect()
		{
			Debug("Disconnecting");
			Inner.Disconnect();
			if (Disconnected != null) Disconnected(this, null);
			Status = SocketStatus.Idle;
			try { WorkerA.Abort(); } catch {}
			try { WorkerB.Abort(); } catch {}
		}
		
		/// <summary>
		/// Forces all pending packets to be processed immediately
		/// </summary>
		public void ProcessQueue() {
			lock (SendQueue) {
				while (SendQueue.Count > 0) {
					try {
						Packet p = SendQueue.Dequeue();
						if (p.Important) {
							AwaitingConfirmation.Add(p);
							if (p.UID == 0) {
								p.UID = UIDGen.Next(1000000);
								p.Arguments.Add(new Argument("x-packet-uid", p.UID));
							}
						}
						byte[] b = p.Prepare();
						SendRaw(MagicStart, 0, MagicStart.Length);
						SendRaw(b, 0, b.Length);
						SendRaw(MagicEnd, 0, MagicEnd.Length);
					} catch {
						Disconnect();
					}
				}
				
				int i = 0;
				while (i < AwaitingConfirmation.Count) {
					if (AwaitingConfirmation[i].RetriesLeft != 0) {
						AwaitingConfirmation[i].ResendInterval -= Clock;
						if (AwaitingConfirmation[i].ResendInterval <= 0) {
							AwaitingConfirmation[i].ResendInterval = Packet.DefaultResendInterval;
							AwaitingConfirmation[i].RetriesLeft--;
							SendQueue.Enqueue(AwaitingConfirmation[i]);
						}
					} else AwaitingConfirmation.RemoveAt(i);
					i++;
				}
			}
		}
		
		/// <summary>
		/// Sends raw data through underlaying implementation.
		/// If the data isn't well-formed (including magic sequences, length and checksum), the remote socket will likely to be desynced.
		/// </summary>
		public void SendRaw(byte[] data, int start, int len) {
			Inner.Send(data, start, len);
		}
		
		public void Send(Packet p) {
			lock (SendQueue) {
				SendQueue.Enqueue(p);
			}
		}
		
		private void RunWorkerA() {
			while (true) {
				Thread.Sleep(Clock);
				ProcessQueue();
			}
		}
		
		private void Debug(string s) {
			if (DebugName.Length > 0) {
				Console.WriteLine("[" + DebugName + "] " + s);
			}
		}
		
		private void DoReceive() {
			try {
				int l = Inner.Recv(ref Buffer, BufferOffset, BufferSize - BufferOffset);
				while (l == 0) {
					Thread.Sleep(Clock);
					l = Inner.Recv(ref Buffer, BufferOffset, BufferSize - BufferOffset);
				}
			/*if (l>0) {
			Console.WriteLine("Received " + l + " bytes");
			for (int i=0;i<l;i++)
				Console.Write(Buffer[BufferOffset+i] + " ");
			Console.WriteLine();
			}*/
				BufferOffset += l;
			} catch {
				Disconnect();
			}
		}
		
		private void PopBuffer(int len) {
			for (int i = 0; i < BufferOffset - len; i++) 
				Buffer[i] = Buffer[i+len];
			BufferOffset -= len;
		}
		
		private int GrabSize() {
			int i = MagicStart.Length;
			return Buffer[i] + 
				   Buffer[i+1] * 256 + 
				   Buffer[i+2] * 256 * 256 + 
				   Buffer[i+3] * 256 * 256 * 256;
		}
		
		private void RunWorkerB() {
			bool m;
			while (true) {
				while (!Synced) {
					Debug("Trying to resync");
					while (BufferOffset <= MagicStart.Length)
						DoReceive();
					for (int i = 0; i <= BufferOffset - MagicStart.Length; i++) {
						m = true;
						for (int j = 0; j < MagicStart.Length; j++)
							if (Buffer[i+j] != MagicStart[j]) {
								m = false;
								break;
							}
						if (m) {
							PopBuffer(i);
							Synced = true;
							Debug("Sync restored");
							break;
						}
					}
					PopBuffer(BufferOffset - MagicStart.Length);
				}
				
				while (BufferOffset <= MagicStart.Length + 4) {
					DoReceive();
				}
				
				int len = GrabSize();
				
				try {
					m = true;
					for (int j = 0; j < MagicStart.Length; j++)
						if (Buffer[j] != MagicStart[j]) {
							m = false;
							break;
						}
					
					if (!m) {
						Synced = false;
						Debug("Desync!");
						BufferOffset = 0;
						continue;
					}
					
					while (BufferOffset < len + MagicEnd.Length + MagicStart.Length) {
						DoReceive();
					}
				
					m = true;
					for (int j = 0; j < MagicEnd.Length; j++)
						if (Buffer[len + MagicStart.Length + j] != MagicEnd[j]) {
							m = false;
							break;
						}
				
					if (m) {
						if (Packet.ValidateChecksum(Buffer[MagicStart.Length + 4], Buffer, MagicStart.Length + 5, len - 5)) {
							ProcessPacket(Packet.ParseFrom(Buffer, MagicStart.Length + 5, len - 5));
						}
						BufferOffset = 0;
					} else {
						Synced = false;
						Debug("Desync!");
						BufferOffset = 0;
						continue;
					}
				} catch {
					Synced = false;
					Debug("Desync!");
					BufferOffset = 0;
				}
			}
		}
		
		
		private void ProcessUtilityPacket(Packet p) {
			if (p.Command.Equals("close-connection"))
				Disconnect();
			if (p.Command.Equals("packet-received")) {
				int i = 0;
				while (i < AwaitingConfirmation.Count) {
					if (AwaitingConfirmation[i].UID == p["x-packet-uid"].GetInt()) AwaitingConfirmation.RemoveAt(i);
					i++;
				}
			}
		}
		
		private void ProcessPacket(Packet p) {
			try {
				if (p.Utilitary) {
					ProcessUtilityPacket(p);
				} else {
					if (p.Important) {
						p.UID = (int)p["x-packet-uid"].GetInt();
						if (p.UID == LastUID) return;
						LastUID = p.UID;
						
						Packet pp = new Packet();
						pp.Utilitary = true;
						pp.Command = "packet-received";
						
						pp.Arguments.Add(p["x-packet-uid"]);
						
						Send(pp);
					}	
					if (Receive != null) Receive(this, p);
				}
			} catch { }
		}
		
	}
	
	public enum SocketStatus {
		Idle,
		Connected,
		Listening
	}
}
