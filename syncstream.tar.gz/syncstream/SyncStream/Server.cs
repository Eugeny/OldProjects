using System;
using System.Threading;

namespace SyncStream
{
	public class Server
	{
		private Thread Worker = null;
		private BaseImplementation Inner = null;
		
		public string BindInfo = "";
		public ConnectEvent Connect;
		
		public delegate void ConnectEvent(Socket socket);
		
		
		/// <summary>
		/// Constructs a server using a specific underlaying Implementation
		/// </summary>
		/// <param name="inn">An Implementation to use</param>
		public Server(BaseImplementation inn) {
			Inner = inn;
		}
		
		/// <summary>
		/// Starts a worker thread. From this on, Connect event will be emitted
		/// The BindInfo property should be set by this moment
		/// </summary>
		public void StartServer() {
			StopServer();
			Worker = new Thread(new ThreadStart(Run));
			Worker.Start();
		}
		
		/// <summary>
		/// Kills worked thread
		/// </summary>
		public void StopServer() {
			try {
				Worker.Abort();
				Inner.Disconnect();
			} catch {}
		}
		
		private void Run() {
			Inner.Listen(BindInfo);
			while (true) {
				Socket s = new Socket(Inner.Accept());
				s.RestartWorkers();
				if (Connect != null) Connect(s);
			}
		}
	}
}
