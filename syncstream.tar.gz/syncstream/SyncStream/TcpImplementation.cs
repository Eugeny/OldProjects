using System;
using System.Net;
using Sockets = System.Net.Sockets;

namespace SyncStream
{
	public class TcpImplementation : BaseImplementation
	{
		private Sockets.Socket Inner = null;
		
		public TcpImplementation()
		{
			Inner = new Sockets.Socket(Sockets.AddressFamily.InterNetwork, Sockets.SocketType.Stream, Sockets.ProtocolType.Tcp);
		}
	
		public TcpImplementation(Sockets.Socket sck) {
			Inner = sck;
		}
		
		public override void Connect(string info) {
			IPAddress addr = null;
			int port = 0;
			
			try {
				string[] s = info.Split(':');
				addr = IPAddress.Parse(s[0]);
				port = Int32.Parse(s[1]);
			}
			catch {
				throw new ArgumentException("Invalid connection string");
			}
			
			try {
				Inner.Connect(addr, port);
			}
			catch {
				throw new Exception("Can't connect through TCP implementation");
			}
		}
		
		public override void Disconnect() {
			try {
				Inner.Shutdown(Sockets.SocketShutdown.Both);
				Inner.Close();
			}
			catch { }
		}
		
		public override void Send(byte[] data, int start, int len) {
			try {
				Inner.Send(data, start, len, Sockets.SocketFlags.None);
			}
			catch {
				throw new Exception("Failed to send data through TCP implementation");
			} 
		}
		
		public override int Recv(ref byte[] data, int start, int len) {
			try {
				return Inner.Receive(data, start, len, Sockets.SocketFlags.None);
			}
			catch {
				throw new Exception("Failed to receive data through TCP implementation");
			} 
		}
		
		public override void Listen(string info) {
			IPAddress addr = null;
			int port = 0;
			
			try {
				string[] s = info.Split(':');
				if (s[0].Equals("any"))
					addr = IPAddress.Any; else
					addr = IPAddress.Parse(s[0]);
				port = Int32.Parse(s[1]);
			}
			catch {
				throw new ArgumentException("Invalid connection string");
			}
			
			try {
				Inner.Bind(new IPEndPoint(addr, port));
				Inner.Listen(10);
			}
			catch {
				throw new Exception("Can't listen through TCP implementation");
			}
		}
				
		public override BaseImplementation Accept() {
			try {
				return new TcpImplementation(Inner.Accept());
			}
			catch {
				throw new Exception("Can't accept through TCP implementation");
			}
		}
		
		public override string GetConnectionInfo ()
		{
			return Inner.RemoteEndPoint.ToString();
		}


	}
}
