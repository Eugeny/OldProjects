#!/bin/sh
cd connect; ./manage.py runserver
