﻿using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace RaytracerLib
{
    public class Texture
    {
        public string Filename;
        private int Height;
        public string Name;
        private int Width;
        private Bitmap bitmap;
        private BitmapData bmpd;
        private byte[] data;
        private Image image;

        public void Load()
        {
            try
            {
                image = Image.FromFile(Filename);
            }
            catch
            {
                MessageBox.Show("Texture not found! " + Filename);
                return;
            }
            bitmap = new Bitmap(image);
            Width = image.Width;
            Height = image.Height;
            bmpd = bitmap.LockBits(new Rectangle(0, 0, Width, Height), ImageLockMode.ReadOnly,
                                   PixelFormat.Format32bppArgb);
            data = new byte[Width*Height*4];
            Marshal.Copy(bmpd.Scan0, data, 0, Width*Height*4);
        }

        public Color Sample(Vector3 uv, double sampling)
        {
            var sz = (int) (sampling*Width);

            Color r = Color.Black;
            for (int dx = -sz/2; dx < sz/2; dx++)
                for (int dy = -sz/2; dy < sz/2; dy++)
                    r += Sample(uv + new Vector3(dx, dy, 0));

            r *= 1.0/sz/sz;
            return r;
        }

        public Color Sample(Vector3 uv)
        {
            var x = (int) (uv.X*Width);
            int y = Height - (int) (uv.Y*Height);

            while (x < 0) x += Width;
            while (y < 0) y += Height;

            x %= Width;
            y %= Height;

            var r = new Color();

            int off = y*Width*4 + x*4;
            r.A = data[off + 3];
            r.G = data[off + 0];
            r.B = data[off + 1];
            r.R = data[off + 2];

            r *= 1.0/256;

            return r;
        }
    }
}