﻿using System;

namespace RaytracerLib
{
    public class Camera
    {
        private const double AspectRatio = 1;
        private const double FOV = Math.PI/3;
        public Vector3 Position = Vector3.Zero;
        public Matrix Rotation = Matrix.Identity();

        public Ray GetViewportRay(double vx, double vy)
        {
            var d = new Vector3(-Math.Tan(FOV/2*vx)*AspectRatio, Math.Tan(FOV/2*vy), 1);
            var r = new Ray(Position, Rotation*d);
            return r;
        }
    }
}