﻿using System;

namespace RaytracerLib
{
    public struct Ray
    {
        private static int rnd;
        public Vector3 Direction;
        public bool HitsTransparent;
        public Vector3 Origin;
        internal double ThicknessCoefficient;

        public Ray(Vector3 o, Vector3 d)
        {
            Origin = o;
            Direction = d;
            HitsTransparent = true;
            ThicknessCoefficient = 0;
        }

        public void Transform(Matrix t)
        {
            Vector3 target = Origin + Direction;
            Origin = t*Origin;
            target = t*target;
            Direction = target - Origin;
        }

        public void Refract(RaycastHit h)
        {
            Origin = h.Point + Direction.Normalized*0.02;
            double n = 1/Material.Refractivity;
            if (h.Normal.Dot(Direction) < 0)
                n = 1/n;

            double cosI = -h.Normal.Dot(Direction);
            double cosT2 = 1 - n*n*(1 - cosI*cosI);

            Direction = (Direction*n) + h.Normal*(cosT2 - cosI*n);
        }


        public void Reflect(RaycastHit h)
        {
            Origin = h.Point + h.Normal.Normalized*0.02;
            Vector3 n = h.Normal.Normalized;
            Direction = n*Direction*n*2 - Direction;
        }

        public void RandomizeReflection(RaycastHit h)
        {
            Vector3 n;
            do
            {
                if (Scene.random.Next() == Scene.random.Next())
                    Scene.random = new Random();

                rnd = Scene.random.Next()%500 - 250;
                n.X = rnd;
                rnd = Scene.random.Next()%500 - 250;
                n.Y = rnd;
                rnd = Scene.random.Next()%500 - 250;
                n.Z = rnd;
                n = n.Normalized;
            } while (h.Normal.Dot(n) < 0);
            Direction = n;
        }
    }
}