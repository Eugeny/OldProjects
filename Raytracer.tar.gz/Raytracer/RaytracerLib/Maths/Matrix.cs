﻿using System;

namespace RaytracerLib
{
    public struct Matrix
    {
        public double[,] M;

        public static Matrix Identity()
        {
            return CreateTranslation(Vector3.Zero);
        }

        private static Matrix Create()
        {
            var m = new Matrix {M = new double[4,4]};
            return m;
        }

        public static Matrix operator +(Matrix a, Matrix b)
        {
            Matrix result = Create();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    result.M[i, j] = a.M[i, j] + b.M[i, j];
                }
            }
            return result;
        }

        public static Matrix operator -(Matrix a, Matrix b)
        {
            Matrix result = Create();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    result.M[i, j] = a.M[i, j] - b.M[i, j];
                }
            }
            return result;
        }

        public static Matrix operator *(Matrix a, double scalar)
        {
            Matrix result = Create();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    result.M[i, j] = a.M[i, j]*scalar;
                }
            }
            return result;
        }

        public static Vector3 operator *(Matrix a, Vector3 b)
        {
            var result = new Vector3();
            for (int i = 0; i < 4; i++)
            {
                double s = 0.0;
                s += a.M[i, 0]*b.X;
                s += a.M[i, 1]*b.Y;
                s += a.M[i, 2]*b.Z;
                s += a.M[i, 3];

                if (i == 0)
                    result.X = s;
                if (i == 1)
                    result.Y = s;
                if (i == 2)
                    result.Z = s;
            }
            return result;
        }

        public static Matrix operator *(Matrix a, Matrix b)
        {
            Matrix result = Create();
            for (int j = 0; j < 4; j++)
            {
                for (int i = 0; i != 4; i++)
                {
                    double s = 0.0;
                    for (int l = 0; l < 4; l++)
                    {
                        s += a.M[j, l]*b.M[l, i];
                    }

                    result.M[j, i] = s;
                }
            }
            return result;
        }

        // ------------

        public static Matrix CreateTranslation(Vector3 t)
        {
            Matrix m = Create();
            m.M = new[,]
                      {
                          {1, 0, 0, t.X},
                          {0, 1, 0, t.Y},
                          {0, 0, 1, t.Z},
                          {0, 0, 0, 1}
                      };
            return m;
        }

        public static Matrix CreateScale(Vector3 t)
        {
            Matrix m = Create();
            m.M = new[,]
                      {
                          {t.X, 0, 0, 0},
                          {0, t.Y, 0, 0},
                          {0, 0, t.Z, 0},
                          {0, 0, 0, 1}
                      };
            return m;
        }

        private static Matrix CreateRotationX(double ang)
        {
            Matrix m = Create();
            m.M = new[,]
                      {
                          {1, 0, 0, 0},
                          {0, Math.Cos(ang), -Math.Sin(ang), 0},
                          {0, Math.Sin(ang), Math.Cos(ang), 0},
                          {0, 0, 0, 1}
                      };
            return m;
        }

        private static Matrix CreateRotationY(double ang)
        {
            Matrix m = Create();
            m.M = new[,]
                      {
                          {Math.Cos(ang), 0, Math.Sin(ang), 0},
                          {0, 1, 0, 0},
                          {-Math.Sin(ang), 0, Math.Cos(ang), 0},
                          {0, 0, 0, 1}
                      };
            return m;
        }

        private static Matrix CreateRotationZ(double ang)
        {
            Matrix m = Create();
            m.M = new[,]
                      {
                          {Math.Cos(ang), -Math.Sin(ang), 0, 0},
                          {Math.Sin(ang), Math.Cos(ang), 0, 0},
                          {0, 0, 1, 0},
                          {0, 0, 0, 1}
                      };
            return m;
        }

        public static Matrix CreateRotation(Vector3 ang)
        {
            return CreateRotation(ang.X, ang.Y, ang.Z);
        }

        public static Matrix CreateRotation(double x, double y, double z)
        {
            return CreateRotationY(y)*CreateRotationX(x)*CreateRotationZ(z);
        }
    }
}