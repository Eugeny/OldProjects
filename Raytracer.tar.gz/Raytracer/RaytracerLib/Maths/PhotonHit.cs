﻿namespace RaytracerLib
{
    public class PhotonHit
    {
        public Color Color;
        public Vector3 Normal;
        public Vector3 Position;
    }
}