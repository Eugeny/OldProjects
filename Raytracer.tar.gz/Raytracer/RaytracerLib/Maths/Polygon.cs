﻿using System;

namespace RaytracerLib
{
    public struct Polygon
    {
        public int MaterialIndex;
        public Vector3 Normal0, Normal1, Normal2;
        public Mesh ParentMesh;
        public Vector3[] UV;
        public Vector3 Vertex0, Vertex1, Vertex2;

        public Polygon(Vector3 a, Vector3 b, Vector3 c, Vector3 normal0, Vector3 normal1, Vector3 normal2, Mesh m)
        {
            UV = new Vector3[3];
            Vertex0 = a;
            Vertex1 = b;
            Vertex2 = c;
            MaterialIndex = 0;
            Normal0 = normal0;
            Normal1 = normal1;
            Normal2 = normal2;
            ParentMesh = m;
        }

        public Material Material
        {
            get { return ParentMesh.Materials[MaterialIndex]; }
        }

        public bool Raycast(Ray R, ref RaycastHit I)
        {
            // get triangle edge vectors and plane normal
            Vector3 u = Vertex1 - Vertex0;
            Vector3 v = Vertex2 - Vertex0;
            Vector3 n = u*v;
            if (n == Vector3.Zero) // triangle is degenerate
                return false; // do not deal with this case

            Vector3 dir = R.Direction;
            Vector3 w0 = R.Origin - Vertex0;
            double a = -n.Dot(w0);
            double b = n.Dot(dir);
            if (Math.Abs(b) < 0.0001)
            {
                // ray is parallel to triangle plane
                return false;
            }

            // get intersect point of ray with triangle plane
            double r = a/b;
            if (r < 0.0) // ray goes away from triangle
                return false; // => no intersect
            // for a segment, also test if (r > 1.0) => no intersect

            I.Point = R.Origin + dir*r; // intersect point of ray and plane
            I.Polygon = this;
            I.Distance = (I.Point - R.Origin).Magnitude;

            // is I inside T?
            double uu = u.Dot(u);
            double uv = u.Dot(v);
            double vv = v.Dot(v);
            Vector3 w = I.Point - Vertex0;
            double wu = w.Dot(u);
            double wv = w.Dot(v);
            double D = uv*uv - uu*vv;

            // get and test parametric coords
            double s = (uv*wv - vv*wu)/D;
            if (s < 0.0 || s > 1.0) // I is outside T
                return false;
            double t = (uv*wu - uu*wv)/D;
            if (t < 0.0 || (s + t) > 1.0) // I is outside T
                return false;
            I.PolygonU = s;
            I.PolygonV = t;

            I.TextureUV = Vector3.Lerp3(UV[0], UV[1], UV[2], s, t);

            // Interpolate normals
            I.Normal = Vector3.Lerp3(Normal0, Normal1, Normal2, s, t);

            I.Ray = R;

            return true;
        }
    }
}