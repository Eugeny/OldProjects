﻿using System.Collections.Generic;

namespace RaytracerLib
{
    public class SpaceMap<T>
    {
        private readonly int Size;
        private readonly double Slice;
        private readonly List<T>[,,] map;

        public SpaceMap(double extents, double slice)
        {
            var len = (int) (2*extents/slice);
            map = new List<T>[len,len,len];
            Size = len;
            Slice = slice;
        }

        public IEnumerator<T> GetItems(Vector3 coords, int delta)
        {
            int cx = (int) (coords.X/Slice) + Size/2;
            int cy = (int) (coords.Y/Slice) + Size/2;
            int cz = (int) (coords.Z/Slice) + Size/2;

            for (int dx = -delta; dx <= delta; dx++)
                for (int dy = -delta; dy <= delta; dy++)
                    for (int dz = -delta; dz <= delta; dz++)
                    {
                        int x = cx + dx, y = cy + dy, z = cz + dz;
                        if (x < Size && y < Size && z < Size && x >= 0 && y >= 0 && z >= 0)
                            if (map[x, y, z] != null)
                                foreach (T t in map[x, y, z])
                                    yield return t;
                    }
        }

        public void Add(Vector3 coords, T i)
        {
            int cx = (int) (coords.X/Slice) + Size/2;
            int cy = (int) (coords.Y/Slice) + Size/2;
            int cz = (int) (coords.Z/Slice) + Size/2;

            if (map[cx, cy, cz] == null)
                map[cx, cy, cz] = new List<T>();
            if (!map[cx, cy, cz].Contains(i))
                map[cx, cy, cz].Add(i);
        }
    }
}