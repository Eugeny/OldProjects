﻿namespace RaytracerLib
{
    public struct RaycastHit
    {
        public Color Dim;
        public double Distance;
        public Mesh Mesh;
        public Vector3 Normal;
        public Vector3 Point;
        public Polygon Polygon;
        public double PolygonU, PolygonV;
        public Ray Ray;
        public Vector3 TextureUV;
    }
}