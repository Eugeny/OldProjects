﻿using System;

namespace RaytracerLib
{
    public struct Vector3 : IEquatable<Vector3>
    {
        public static Vector3 Zero = new Vector3(0, 0, 0);
        public static Vector3 One = new Vector3(1, 1, 1);
        public double X;
        public double Y;
        public double Z;

        public Vector3(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        public double Magnitude
        {
            get { return Math.Sqrt(X*X + Y*Y + Z*Z); }
        }

        public Vector3 Normalized
        {
            get
            {
                if (Magnitude == 0)
                    return Zero;
                return this*(1.0/Magnitude);
            }
        }

        #region IEquatable<Vector3> Members

        public bool Equals(Vector3 o)
        {
            return (X == o.X && Y == o.Y && Z == o.Z);
        }

        #endregion

        public double Dot(Vector3 b)
        {
            return X*b.X + Y*b.Y + Z*b.Z;
        }

        public static Vector3 operator +(Vector3 a, Vector3 b)
        {
            return new Vector3(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
        }

        public static Vector3 operator -(Vector3 a)
        {
            return new Vector3(-a.X, -a.Y, -a.Z);
        }

        public static Vector3 operator -(Vector3 a, Vector3 b)
        {
            return a + (-b);
        }

        public static Vector3 operator *(Vector3 a, Vector3 b)
        {
            return new Vector3(a.Y*b.Z - a.Z*b.Y, a.Z*b.X - a.X*b.Z, a.X*b.Y - a.Y*b.X);
        }

        public static Vector3 operator *(Vector3 a, double b)
        {
            return new Vector3(a.X*b, a.Y*b, a.Z*b);
        }

        public override bool Equals(object obj)
        {
            return Equals((Vector3) obj);
        }

        public static bool operator ==(Vector3 a, Vector3 b)
        {
            return a.Equals(b);
        }

        public static bool operator !=(Vector3 a, Vector3 b)
        {
            return !(a == b);
        }

        public static Vector3 Lerp(Vector3 a, Vector3 b, double t)
        {
            return a + (b - a)*t;
        }

        public static Vector3 Lerp3(Vector3 a, Vector3 b, Vector3 c, double u, double v)
        {
            return a + (b - a)*u + (c - a)*v;
        }


        public override int GetHashCode()
        {
            return X.GetHashCode() + Y.GetHashCode() + Z.GetHashCode();
        }

        public override string ToString()
        {
            return String.Format("({0}; {1}; {2})", X, Y, Z);
        }
    }
}