﻿using System;
using System.Linq;

namespace RaytracerLib
{
    public struct Color
    {
        public static Color Black = new Color(0, 0, 0, 1);
        public static Color White = new Color(1, 1, 1, 1);
        public double A;
        public double B;
        public double G;
        public double R;

        public Color(double r, double g, double b, double a)
        {
            R = r;
            G = g;
            B = b;
            A = a;
        }

        public Color OverburnPart
        {
            get { return new Color(Math.Max(1, R) - 1, Math.Max(1, G) - 1, Math.Max(1, B) - 1, A); }
        }

        public Color RealPart
        {
            get { return new Color(Math.Min(1, R), Math.Min(1, G), Math.Min(1, B), A); }
        }

        public static Color operator +(Color a, Color b)
        {
            return new Color(a.R + b.R, a.G + b.G, a.B + b.B, a.A);
        }

        public static Color operator *(Color a, Color b)
        {
            return new Color(a.R*b.R, a.G*b.G, a.B*b.B, a.A*b.A);
        }

        public static Color operator *(Color a, double b)
        {
            return new Color(a.R*b, a.G*b, a.B*b, a.A);
        }


        public static Color Average(Color[] cc)
        {
            var r = new Color();
            r = cc.Aggregate(r, (current, c) => current + c);
            r *= (1.0/cc.Length);
            return r;
        }

        public static Color Blend(Color bg, Color c)
        {
            double a = 1 - c.A;
            return new Color(bg.R*a + c.R*c.A, bg.G*a + c.G*c.A, bg.B*a + c.B*c.A, bg.A*a + c.A);
        }
    }
}