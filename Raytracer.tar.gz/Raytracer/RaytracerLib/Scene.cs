﻿using System;
using System.Collections.Generic;

namespace RaytracerLib
{
    public class Scene
    {
        private const double SLICE_STEP = 0.3;

        private const int PHOTON_REFRACTED = 1;
        private const int PHOTON_REFLECTED = 3;
        public const double Extents = 20;
        public static int PHOTON_NEW;
        public static Random random = new Random();
        public readonly List<Light> Lights = new List<Light>();
        public readonly List<Mesh> Meshes = new List<Mesh>();
        private SpaceMap<Polygon> PolyMap;

        public void BuildPolyMap()
        {
            PolyMap = new SpaceMap<Polygon>(Extents*3, SLICE_STEP);
            foreach (Mesh m in Meshes)
            {
                foreach (Polygon t in m.Polygons)
                {
                    Polygon nt = t;
                    nt.Vertex0 = m.Transform*t.Vertex0;
                    nt.Vertex1 = m.Transform*t.Vertex1;
                    nt.Vertex2 = m.Transform*t.Vertex2;

                    Vector3 u = nt.Vertex1 - nt.Vertex0;
                    Vector3 v = nt.Vertex2 - nt.Vertex0;
                    double lu = u.Magnitude;
                    double lv = v.Magnitude;
                    u = u.Normalized;
                    v = v.Normalized;
                    for (double du = 0; du < lu + SLICE_STEP; du += SLICE_STEP/2)
                        for (double dv = 0; dv < lv + SLICE_STEP; dv += SLICE_STEP/2)
                        {
                            PolyMap.Add(nt.Vertex0 + u*du + v*dv, nt);
                        }
                }
            }
        }

        public bool Raycast(Ray R, ref RaycastHit hit)
        {
            var bestHit = new RaycastHit();
            bool hasHit = false;
            Color dim = Color.White;
            double dimA = 1;

            for (double d = 0; d < Extents*2; d += SLICE_STEP/2)
            {
                IEnumerator<Polygon> en = PolyMap.GetItems(R.Origin + R.Direction*d, 1);
                while (en.MoveNext())
                {
                    Polygon t = en.Current;

                    var curHit = new RaycastHit();
                    if (t.Raycast(R, ref curHit))
                    {
                        curHit.Mesh = t.ParentMesh;
                        if (!R.HitsTransparent && curHit.Polygon.Material.RefractionChance > 0)
                        {
                            dim = curHit.Polygon.Material.Diffuse;
                            dimA = (1 - curHit.Polygon.Material.Diffuse.A);
                        }
                        else
                        {
                            if (!hasHit || curHit.Distance < bestHit.Distance)
                            {
                                bestHit = curHit;
                                hasHit = true;
                            }
                        }
                    }
                }

                if (hasHit) break;
            }

            hit = bestHit;
            hit.Dim = dim;
            hit.Dim.A = dimA;
            return hasHit;
        }

        public bool MapPhoton(Ray r, int state, int bounces, double maxDist, ref Color dim, out Vector3 pos,
                              out Vector3 nrm)
        {
            var h = new RaycastHit();
            pos = Vector3.Zero;
            nrm = Vector3.Zero;
            if (Raycast(r, ref h) && h.Distance < maxDist)
            {
                double rnd = random.NextDouble();

                if (rnd < h.Polygon.Material.DiffusionChance)
                {
                    if (random.NextDouble() < 0.5 || bounces == 0)
                        //if (state != PHOTON_NEW)
                    {
                        pos = h.Point;
                        nrm = h.Normal;
                        //dim *= -h.Normal.Dot(r.direction.Normalized);
                        return true;
                    }
                    {
                        Ray refl = r;
                        refl.Reflect(h);
                        refl.RandomizeReflection(h);
                        dim *= h.Polygon.Material.Diffuse;
                        return MapPhoton(refl, PHOTON_REFLECTED, bounces - 1, maxDist, ref dim, out pos, out nrm);
                    }
                }
                if (rnd >= h.Polygon.Material.DiffusionChance &&
                         rnd < h.Polygon.Material.DiffusionChance + h.Polygon.Material.ReflectionChance && bounces > 0)
                {
                    Ray refl = r;
                    refl.Reflect(h);
                    dim *= h.Polygon.Material.Diffuse;
                    return MapPhoton(refl, PHOTON_REFLECTED, bounces - 1, maxDist, ref dim, out pos, out nrm);
                }
                if (rnd > h.Polygon.Material.DiffusionChance + h.Polygon.Material.ReflectionChance &&
                         bounces > 0)
                {
                    Ray refr = r;
                    refr.Refract(h);
                    dim *= h.Polygon.Material.Diffuse;
                    return MapPhoton(refr, PHOTON_REFRACTED, bounces - 1, maxDist, ref dim, out pos, out nrm);
                }
            }
            return false;
        }

        public Color Raytrace(Ray r, string method, int bounces, double maxDist, SpaceMap<PhotonHit> GI)
        {
            var h = new RaycastHit();
            if (Raycast(r, ref h) && h.Distance < maxDist)
            {
                Color c = h.Polygon.Material.Shade(method, this, h, GI);
                c *= h.Polygon.Material.DiffusionChance;
                if (h.Polygon.Material.RefractionChance > 0 && bounces > 0)
                {
                    Ray refr = r;
                    refr.Refract(h);
                    Color bg = Raytrace(refr, method, bounces - 1, maxDist, GI);
                    c += bg*h.Polygon.Material.RefractionChance;
                }
                if (h.Polygon.Material.ReflectionChance > 0 && bounces > 0)
                {
                    Ray refr = r;
                    refr.Reflect(h);
                    Color bg = Raytrace(refr, method, bounces - 1, maxDist, GI);
                    c += bg*h.Polygon.Material.ReflectionChance;
                }

                return c;
            }
            return Color.White;
        }
    }
}