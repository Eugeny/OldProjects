﻿using System.Collections.Generic;

namespace RaytracerLib
{
    public class Mesh
    {
        public readonly List<Material> Materials = new List<Material>();
        public Polygon[] Polygons;
        public Matrix Transform = Matrix.Identity();

        public bool Raycast(Ray R, ref RaycastHit hit)
        {
            var bestHit = new RaycastHit();
            bool hasHit = false;

            foreach (Polygon t in Polygons)
            {
                Polygon poly = t;
                poly.Vertex0 = Transform*poly.Vertex0;
                poly.Vertex1 = Transform*poly.Vertex1;
                poly.Vertex2 = Transform*poly.Vertex2;

                var curHit = new RaycastHit();
                if (poly.Raycast(R, ref curHit))
                {
                    if (!hasHit || curHit.Distance < bestHit.Distance)
                    {
                        bestHit = curHit;
                        hasHit = true;
                    }
                }
            }

            hit = bestHit;
            hit.Mesh = this;
            return hasHit;
        }
    }
}