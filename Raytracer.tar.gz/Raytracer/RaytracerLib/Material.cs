﻿using System;
using System.Collections.Generic;

namespace RaytracerLib
{
    public class Material
    {
        private static bool UNTEXTURED = false;

        private const int PHOTON_MAX_COUNT = 80000;
        public Color Diffuse = Color.White;
        public Texture DiffuseMap;
        public double DiffusionChance = 1;
        public double ReflectionChance, RefractionChance;
        public const double Refractivity = 1.2;

        public Color Shade(string method, Scene s, RaycastHit h, SpaceMap<PhotonHit> GI)
        {
            if (method == "Blended")
                return ShadeBlended(s, h, GI);
            if (method == "Photon mapping")
                return ShadePhotonMapped(s, h, GI);
            if (method == "Averaged")
                return ShadeAveraged(s, h, GI);
            return ShadeSimple(s, h, GI);
        }


        private Color ShadeAveraged(Scene s, RaycastHit h, SpaceMap<PhotonHit> GI)
        {
            return (ShadeSimple(s, h, GI) + ShadePhotonMapped(s, h, GI))*0.5;
        }

        private Color ShadeBlended(Scene s, RaycastHit h, SpaceMap<PhotonHit> GI)
        {
            return ShadeSimple(s, h, GI)*ShadePhotonMapped(s, h, GI);
        }

        private Color ShadePhotonMapped(Scene s, RaycastHit h, SpaceMap<PhotonHit> GI)
        {
            Vector3 point = h.Point;
            Color result = Color.Black;

            var e = new List<PhotonHit>();
            IEnumerator<PhotonHit> en = GI.GetItems(point, 1);
            while (en.MoveNext())
                e.Add(en.Current);
            //e.Sort(new Comparison<Photon>((x, y) => (x.Position - point).Magnitude.CompareTo((y.Position - point).Magnitude)));

            Color radiosity = Color.Black;
            double mdist = 0;
            int count = 0;
            int total = Math.Min(e.Count, PHOTON_MAX_COUNT);
            for (int i = 0; i < total; i++)
            {
                PhotonHit p = e[i];
                double dot = p.Normal.Dot(h.Normal);
                if (dot < 0.2) continue;
                //dot += 0.2f;//hack

                double dist = (p.Position - point).Magnitude;
                if (dist < Raytracer.Instance.Settings.PhotonDistance)
                {
                    double c = (1.0 - ((p.Position - point).Magnitude/Raytracer.Instance.Settings.PhotonDistance));
                    //c *= dot;
                    //c *= c;
                    radiosity += p.Color*c; // *c;
                    count++;
                    if (dist > mdist)
                        mdist = dist;
                }
            }
            if (mdist > 0)
            {
                //radiosity *= 1.0 / count;
                radiosity *= Raytracer.Instance.Settings.PhotonBoost/
                             (Raytracer.Instance.Settings.PhotonDistance*Raytracer.Instance.Settings.PhotonDistance);
                radiosity *= 5000.0/Raytracer.Instance.Settings.Photons;
                //radiosity *= 1.0 * count / total;
                radiosity *= Diffuse;
                radiosity.A = 1;
                radiosity.R = Math.Max(0, radiosity.R);
                radiosity.G = Math.Max(0, radiosity.G);
                radiosity.B = Math.Max(0, radiosity.B);
                result += radiosity;
            }

            Color diff = GetDiffuse(h);
            return result*diff + Color.White*Raytracer.Instance.Settings.Ambient;
        }

        private Color GetDiffuse(RaycastHit h)
        {
            if (UNTEXTURED)
                return Diffuse;
            return Diffuse*(DiffuseMap == null ? Color.White : DiffuseMap.Sample(h.TextureUV));
        }

        private Color ShadeSimple(Scene s, RaycastHit h, SpaceMap<PhotonHit> GI)
        {
            Vector3 point = h.Point;

            //double sampling = (h.Polygon.UV[1] + h.Polygon.UV[2] - h.Polygon.UV[0] * 2).Magnitude / (h.Polygon.v1 + h.Polygon.v2 - h.Polygon.v0 * 2).Magnitude * h.Ray.ThicknessCoefficient * h.Distance;
            Color diff = GetDiffuse(h);
            Color result = Color.Black;

            foreach (Light l in s.Lights)
            {
                Vector3 rcd = l.Position - point;
                double ldist = rcd.Magnitude;
                if (ldist > l.Range && !l.IsDirectional)
                    continue;

                rcd = rcd.Normalized;

                var hit = new RaycastHit();
                var lr = new Ray(point + rcd*0.02, rcd) {HitsTransparent = false};

                if (l.IsDirectional)
                    lr.Direction = l.Rotation*new Vector3(0, 0, 1);

                if (!s.Raycast(lr, ref hit) || hit.Distance > ldist)
                {
                    double reflectance = rcd.Dot(h.Normal);
                    if (reflectance > 0)
                    {
                        Color a = diff*l.Color*hit.Dim*reflectance*hit.Dim.A;
                        if (!l.IsDirectional)
                            a *= l.Intensity*(1 - (ldist/l.Range));
                        result += a;
                    }
                }
            }

            return result + Color.White*Raytracer.Instance.Settings.Ambient;
        }
    }
}