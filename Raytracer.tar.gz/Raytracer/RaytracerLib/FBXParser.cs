﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;

namespace RaytracerLib
{
    public class FBXParser
    {
        private readonly Regex CONNECTION = new Regex("C: \"O.\",(\\d+),(\\d+)");
        private readonly Regex HDR_GEOMETRY = new Regex("Geometry: \\d+");
        private readonly Regex ID_CAMERA = new Regex("Model: (\\d+).+\"Camera\"");
        private readonly Regex ID_GEOMETRY = new Regex("Geometry: (\\d+)");
        private readonly Regex ID_LIGHT = new Regex("NodeAttribute: (\\d+), \"NodeAttribute::\", \"Light\"");
        private readonly Regex ID_MATERIAL = new Regex("Material: (\\d+)");
        private readonly Regex ID_MODEL = new Regex("Model: (\\d+)");
        private readonly Regex ID_TEXTURE = new Regex("Texture: (\\d+)");
        public readonly Camera camera;
        public readonly Dictionary<long, Mesh> geometry = new Dictionary<long, Mesh>();
        public readonly Dictionary<long, Light> lights = new Dictionary<long, Light>();
        private readonly Dictionary<long, List<long>> mat2model = new Dictionary<long, List<long>>();
        private readonly Dictionary<long, Material> materials = new Dictionary<long, Material>();
        private readonly Dictionary<long, Model> models = new Dictionary<long, Model>();
        private readonly Dictionary<long, Texture> textures = new Dictionary<long, Texture>();


        public FBXParser(string[] lines)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            int lidx = lines.Length;
            for (int i = 0; i < lidx; i++)
                if (lines[i].EndsWith(",\r"))
                {
                    //lines[i] = lines[i].Remove(lines[i].Length - 1);
                    lines[i] += lines[i + 1];
                    for (int j = i + 1; j < lidx - 1; j++)
                        lines[j] = lines[j + 1];
                    i--;
                    lidx--;
                }
            var nl = new string[lidx];
            Array.Copy(lines, nl, lidx);
            lines = nl;

            int idx = 0;
            while (lines.Length > idx)
            {
                if (idx == lines.Length)
                    break;

                if (HDR_GEOMETRY.IsMatch(lines[idx]))
                {
                    long id = long.Parse(ID_GEOMETRY.Match(lines[idx]).Groups[1].Value);
                    idx += 2;
                    var verts = new List<double>(lines[idx].Substring(6).Split(',').Select(double.Parse));
                    idx += 3;
                    var indexes = new List<int>(lines[idx].Substring(6).Split(',').Select(int.Parse));
                    while (!lines[idx++].Contains("\tNormals: ")) ;
                    var normals = new List<double>(lines[idx].Substring(7).Split(',').Select(double.Parse));
                    while (!lines[idx++].Contains("\tUV: ")) ;
                    var uvs = new List<double>(lines[idx].Substring(7).Split(',').Select(double.Parse));

                    List<int> uvidx = null;
                    if (lines[idx + 2].Contains("UVIndex"))
                    {
                        while (!lines[idx++].Contains("\tUVIndex: ")) ;
                        uvidx = new List<int>(lines[idx].Substring(7).Split(',').Select(int.Parse));
                    }

                    while (!lines[idx++].Contains("\tMaterials: ") && !lines[idx].Contains("\" {")) ;
                    List<int> mats = null;
                    if (!lines[idx].Contains("\" {"))
                    {
                        mats = new List<int>(lines[idx].Substring(7).Split(',').Select(int.Parse));
                    }
                    else
                        idx--;

                    var m = new Mesh {Polygons = new Polygon[indexes.Count/3]};

                    for (int i = 0; i < indexes.Count/3; i++)
                    {
                        var t = new Polygon();
                        int i0 = indexes[i*3];
                        int i1 = indexes[i*3 + 1];
                        int i2 = -1 ^ (indexes[i*3 + 2]);
                        t.Vertex0 = new Vector3(verts[i0*3], verts[i0*3 + 1], verts[i0*3 + 2]);
                        t.Vertex1 = new Vector3(verts[i1*3], verts[i1*3 + 1], verts[i1*3 + 2]);
                        t.Vertex2 = new Vector3(verts[i2*3], verts[i2*3 + 1], verts[i2*3 + 2]);
                        t.Normal0 = new Vector3(normals[i0*3], normals[i0*3 + 1], normals[i0*3 + 2]);
                        t.Normal1 = new Vector3(normals[i1*3], normals[i1*3 + 1], normals[i1*3 + 2]);
                        t.Normal2 = new Vector3(normals[i2*3], normals[i2*3 + 1], normals[i2*3 + 2]);
                        t.UV = new Vector3[3];
                        if (uvidx == null)
                        {
                            //t.UV[0] = new Vector3(uvs[i * 6 + 0], uvs[i * 6 + 1], 0);
                            //t.UV[1] = new Vector3(uvs[i * 6 + 2], uvs[i * 6 + 3], 0);
                            //t.UV[2] = new Vector3(uvs[i * 6 + 4], uvs[i * 6 + 5], 0);

                            t.UV[0] = new Vector3(uvs[i0*2], uvs[i0*2 + 1], 0);
                            t.UV[1] = new Vector3(uvs[i1*2], uvs[i1*2 + 1], 0);
                            t.UV[2] = new Vector3(uvs[i2*2], uvs[i2*2 + 1], 0);
                        }
                        else
                        {
                            //t.UV[0] = new Vector3(uvs[uvidx[i * 3 + 0] * 2], uvs[uvidx[i * 3 + 0] * 2 + 1], 0);
                            //t.UV[1] = new Vector3(uvs[uvidx[i * 3 + 1] * 2], uvs[uvidx[i * 3 + 1] * 2 + 1], 0);
                            //t.UV[2] = new Vector3(uvs[uvidx[i * 3 + 2] * 2], uvs[uvidx[i * 3 + 2] * 2 + 1], 0);

                            t.UV[0] = new Vector3(uvs[uvidx[i0]*2], uvs[uvidx[i0]*2 + 1], 0);
                            t.UV[1] = new Vector3(uvs[uvidx[i1]*2], uvs[uvidx[i1]*2 + 1], 0);
                            t.UV[2] = new Vector3(uvs[uvidx[i2]*2], uvs[uvidx[i2]*2 + 1], 0);
                        }
                        t.ParentMesh = m;
                        t.MaterialIndex = (mats != null) ? (i < mats.Count ? mats[i] : mats[mats.Count - 1]) : 0;
                        m.Polygons[i] = t;
                    }


                    geometry[id] = m;
                }

                if (ID_MODEL.IsMatch(lines[idx]) || ID_CAMERA.IsMatch(lines[idx]))
                {
                    long id = long.Parse(ID_MODEL.Match(lines[idx]).Groups[1].Value);
                    bool cam = ID_CAMERA.IsMatch(lines[idx]);
                    Matrix transform = Matrix.Identity();
                    if (cam)
                        camera = new Camera();

                    var m = new Model();

                    while (!lines[++idx].Contains("}"))
                    {
                        if (lines[idx].Contains("Lcl Translation"))
                        {
                            string[] p = lines[idx].Split(',');
                            int l = p.Length;
                            var t = new Vector3(double.Parse(p[l - 3]), double.Parse(p[l - 2]), double.Parse(p[l - 1]));
                            transform *= Matrix.CreateTranslation(t);
                            if (cam)
                                camera.Position = t;
                            m.P = t;
                        }
                        if (lines[idx].Contains("Lcl Rotation"))
                        {
                            string[] p = lines[idx].Split(',');
                            int l = p.Length;
                            Matrix r =
                                Matrix.CreateRotation(new Vector3(double.Parse(p[l - 3])*Math.PI/180,
                                                                  double.Parse(p[l - 2])*Math.PI/180,
                                                                  double.Parse(p[l - 1])*Math.PI/180));
                            if (cam)
                                r =
                                    Matrix.CreateRotation(new Vector3(-double.Parse(p[l - 3])*Math.PI/180,
                                                                      double.Parse(p[l - 2])*Math.PI/180 - Math.PI,
                                                                      double.Parse(p[l - 1])*Math.PI/180));
                            transform *= r;
                            if (cam)
                                camera.Rotation = r;
                            m.R = r;
                        }
                        if (lines[idx].Contains("Lcl Scaling"))
                        {
                            string[] p = lines[idx].Split(',');
                            int l = p.Length;
                            var t = new Vector3(double.Parse(p[l - 3]), double.Parse(p[l - 2]), double.Parse(p[l - 1]));
                            transform *= Matrix.CreateScale(t);
                            m.S = t;
                        }
                        //if (lines[idx].Contains("PostRotation"))
                        //{
                            //string[] p = lines[idx].Split(',');
                            //int l = p.Length;
                        //}
                    }

                    //                  if (cam)
                    //                        camera.Rotation *= PR;
                    m.M = transform;
                    models[id] = m;
                }

                if (ID_MATERIAL.IsMatch(lines[idx]))
                {
                    long id = long.Parse(ID_MATERIAL.Match(lines[idx]).Groups[1].Value);
                    var mat = new Material();

                    while (!lines[++idx].Contains("}"))
                    {
                        if (lines[idx].Contains("DiffuseColor"))
                        {
                            string[] p = lines[idx].Split(',');
                            int l = p.Length;
                            mat.Diffuse.R = double.Parse(p[l - 3]);
                            mat.Diffuse.B = double.Parse(p[l - 2]);
                            mat.Diffuse.G = double.Parse(p[l - 1]);
                        }
                        if (lines[idx].Contains("Opacity"))
                        {
                            string[] p = lines[idx].Split(',');
                            int l = p.Length;
                            mat.Diffuse.A = double.Parse(p[l - 1]);
                        }
                    }

                    if (mat.Diffuse.A < 0.5)
                    {
                        mat.DiffusionChance = 0.05;
                        mat.RefractionChance = 0.75;
                        mat.ReflectionChance = 0.2;
                    }
                    materials[id] = mat;
                }

                if (ID_TEXTURE.IsMatch(lines[idx]))
                {
                    long id = long.Parse(ID_TEXTURE.Match(lines[idx]).Groups[1].Value);
                    var t = new Texture();
                    while (!lines[++idx].Contains("FileName")) ;
                    t.Filename = lines[idx].Substring(12).Trim('"', ' ', '\r').Replace('/', '\\');
                    while (!lines[++idx].Contains("}")) ;
                    Console.WriteLine("Loading texture: " + t.Filename);
                    t.Load();
                    textures[id] = t;
                }

                if (ID_LIGHT.IsMatch(lines[idx]))
                {
                    long id = long.Parse(ID_LIGHT.Match(lines[idx]).Groups[1].Value);
                    var l = new Light();

                    idx += 2;
                    if (lines[idx].Contains("LightType"))
                    {
                        l.IsDirectional = true;
                        idx += 2;
                    }

                    string[] colors = lines[idx].Split(',');
                    try
                    {
                        l.Color = new Color(double.Parse(colors[colors.Length - 3]),
                                            double.Parse(colors[colors.Length - 2]),
                                            double.Parse(colors[colors.Length - 1]), 1);
                        idx++;
                    }
                    catch
                    {
                    }
                    try
                    {
                        l.Intensity = double.Parse(lines[idx].Split(',').Reverse().First())/100;
                    }
                    catch
                    {
                    }

                    lights[id] = l;
                }


                if (CONNECTION.IsMatch(lines[idx]))
                {
                    long ida = long.Parse(CONNECTION.Match(lines[idx]).Groups[1].Value);
                    long idb = long.Parse(CONNECTION.Match(lines[idx]).Groups[2].Value);

                    if (geometry.ContainsKey(ida) && models.ContainsKey(idb))
                    {
                        geometry[ida].Transform = models[idb].M;
                        if (mat2model.ContainsKey(idb))
                            foreach (long id in mat2model[idb])
                                geometry[ida].Materials.Add(materials[id]);
                    }

                    if (materials.ContainsKey(ida) && models.ContainsKey(idb))
                    {
                        if (!mat2model.ContainsKey(idb))
                            mat2model[idb] = new List<long>();
                        mat2model[idb].Add(ida);
                    }

                    if (lights.ContainsKey(ida) && models.ContainsKey(idb))
                    {
                        lights[ida].Position = models[idb].P;
                        lights[ida].Rotation = models[idb].R;
                        lights[ida].Range = models[idb].S.X;
                    }

                    if (textures.ContainsKey(ida) && materials.ContainsKey(idb))
                    {
                        materials[idb].DiffuseMap = textures[ida];
                    }
                }
                idx++;
            }
        }

        #region Nested type: Model

        private struct Model
        {
            public Matrix M;
            public Vector3 P;
            public Matrix R;
            public Vector3 S;
        }

        #endregion
    }
}