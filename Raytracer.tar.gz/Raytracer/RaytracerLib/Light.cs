﻿namespace RaytracerLib
{
    public class Light
    {
        public Color Color = Color.White;
        public double Intensity = 1;
        public bool IsDirectional;
        public Vector3 Position;
        public double Range = 1;
        public Matrix Rotation;
    }
}