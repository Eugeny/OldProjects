﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows;

namespace RaytracerLib
{
    public class Raytracer
    {
        public static Raytracer Instance;
        private readonly object SyncLock = new object();

        private readonly List<Thread> Workers = new List<Thread>();
        private readonly Random random = new Random();
        private SpaceMap<PhotonHit> PhotonMap;
        private int PhotonScans = 1;
        private byte[] cache;
        private Camera camera;

        private Int32Rect currentPatch;
        private int imagePixelsRendered, imagePixelsTotal;
        private int lastLight, lastPhoton;
        private int lastPixel, renderedPixels;
        private Scene scene;
        private Stage stage;
        private int totalPixels;
        public int PatchSize { get; private set; }
        private bool IsRunning { get; set; }
        public RenderSettings Settings { get; private set; }
        public event Action<Int32Rect, byte[]> PixelsReady = delegate { };
        public event Action<string, double> Progress = delegate { };
        public event Action Stopped = delegate { };

        public void Initialize(RenderSettings s)
        {
            Settings = s;
            Instance = this;
        }

        public void StartRender(Scene s, Camera c)
        {
            scene = s;
            camera = c;

            IsRunning = true;

            cache = new byte[PatchSize*PatchSize*3];

            stage = Stage.GI;
            lastLight = 0;
            lastPhoton = 0;
            imagePixelsTotal = Settings.Width*Settings.Height;

            Progress("Creating photon map", 0);
            PhotonScans = Math.Max((int) (1.0/Settings.PhotonDistance), 1);
            PhotonMap = new SpaceMap<PhotonHit>(Scene.Extents*3, Settings.PhotonDistance*PhotonScans);
            Progress("Creating polymap", 0);
            scene.BuildPolyMap();

            for (int i = 0; i < Settings.Threads; i++)
            {
                var t = new Thread(Work);
                Workers.Add(t);
                t.Start();
            }
        }

        public void Stop()
        {
            if (!IsRunning) return;
            IsRunning = false;
            Workers.Clear();
            Stopped();
        }

        public void SetPatchSize(int ps)
        {
            if (!IsRunning)
                PatchSize = ps;
        }

        private bool NextPatch()
        {
            if ((currentPatch.X + PatchSize) >= Settings.Width && (currentPatch.Y + PatchSize) >= Settings.Height)
            {
                return false;
            }

            currentPatch.Width = currentPatch.Height = PatchSize;
            currentPatch.X += PatchSize;

            if (currentPatch.X >= Settings.Width)
            {
                currentPatch.X = 0;
                currentPatch.Y += PatchSize;
            }

            if (currentPatch.X + currentPatch.Width >= Settings.Width)
                currentPatch.Width = (Settings.Width - currentPatch.X);
            if (currentPatch.Y + currentPatch.Height >= Settings.Height)
                currentPatch.Height = (Settings.Height - currentPatch.Y);
            totalPixels = (currentPatch.Width*currentPatch.Height);
            lastPixel = 0;
            renderedPixels = 0;
            return true;
        }

        private bool RequestWork(ref Task task)
        {
            if (!IsRunning)
                return false;

            bool result = false;

            lock (SyncLock)
            {
                if (stage == Stage.GI)
                {
                    if (lastLight >= scene.Lights.Count || Settings.Method == "Simple")
                    {
                        currentPatch = new Int32Rect(-PatchSize, 0, 0, 0);
                        NextPatch();
                        Thread.Sleep(1000);
                        stage = Stage.Tracing;
                        return false;
                    }

                    var gtask = new GITask {light = scene.Lights[lastLight]};
                    if (gtask.light.IsDirectional)
                        gtask.ray =
                            new Ray(
                                gtask.light.Position +
                                new Vector3(random.NextDouble() - 0.5, random.NextDouble() - 0.5,
                                            random.NextDouble() - 0.5)*Scene.Extents,
                                gtask.light.Rotation*new Vector3(0, 0, -1));
                    else
                        gtask.ray = new Ray(scene.Lights[lastLight].Position,
                                            new Vector3(random.NextDouble() - 0.5, random.NextDouble() - 0.5,
                                                        random.NextDouble() - 0.5));


                    lastPhoton++;
                    if (lastPhoton >= Settings.Photons)
                    {
                        lastPhoton = 0;
                        lastLight++;
                    }

                    task = gtask;
                    result = true;

                    if ((lastLight*Settings.Photons + lastPhoton)%100 == 0)
                    {
                        Progress(
                            String.Format("GI {0}/{1}", lastLight*Settings.Photons + lastPhoton,
                                          scene.Lights.Count*Settings.Photons),
                            1.0*(lastLight*Settings.Photons + lastPhoton)/(scene.Lights.Count*Settings.Photons));
                    }
                }

                if (stage == Stage.Tracing)
                {
                    if (lastPixel < totalPixels)
                    {
                        int px = (lastPixel%currentPatch.Width);
                        int py = (lastPixel/currentPatch.Width);
                        int x = currentPatch.X + px;
                        int y = currentPatch.Y + py;
                        double[] cdx = {0, -0.5, 0.5, 0.5, 0.5};
                        double[] cdy = {0, -0.5, -0.5, -0.5, 0.5};

                        var ttask = new TracingTask {rays = new Ray[Settings.Antialiasing ? 5 : 1], px = px, py = py};
                        for (int i = 0; i < ttask.rays.Length; i++)
                        {
                            ttask.rays[i] = camera.GetViewportRay(2*(x + cdx[i] - Settings.Width/2.0)/Settings.Height,
                                                                  -2*(y + cdy[i] - Settings.Height/2.0)/Settings.Height);
                            ttask.rays[i].ThicknessCoefficient = 1.0/Settings.Width;
                        }

                        if (lastPixel%100 == 0)
                        {
                            double p = 1.0*imagePixelsRendered/imagePixelsTotal;
                            Progress(String.Format("Rendering {0}-{1}-{2}", currentPatch.X, currentPatch.Y, lastPixel),
                                     p);
                        }

                        lastPixel++;
                        task = ttask;
                        result = true;
                    }

                    if (renderedPixels >= totalPixels)
                    {
                        PixelsReady(currentPatch, cache);
                        if (!NextPatch())
                            Stop();
                    }
                }

                task.stage = stage;
            }

            return result;
        }

        private void PixelComplete()
        {
            Interlocked.Increment(ref renderedPixels);
            Interlocked.Increment(ref imagePixelsRendered);
        }

        private void Work()
        {
            Task task = null;

            while (IsRunning)
            {
                while (!RequestWork(ref task))
                {
                    Thread.Sleep(100);
                    if (!IsRunning) return;
                }

                if (task.stage == Stage.GI)
                {
                    var gtask = task as GITask;
                    var p = new PhotonHit {Color = Color.White};

                    if (scene.MapPhoton(gtask.ray, Scene.PHOTON_NEW, Settings.Bounces, 9999, ref p.Color, out p.Position,
                                        out p.Normal))
                    {
                        Color l = gtask.light.Color*gtask.light.Intensity;
                        if (!gtask.light.IsDirectional)
                            l *= Math.Max(0, (1 - ((p.Position - gtask.light.Position).Magnitude/gtask.light.Range)));

                        p.Color = l.RealPart*p.Color + l.OverburnPart;

                        lock (SyncLock)
                            PhotonMap.Add(p.Position, p);
                    }
                    else
                    {
                        Interlocked.Decrement(ref lastPhoton);
                    }
                }

                if (task.stage == Stage.Tracing)
                {
                    var ttask = task as TracingTask;
                    var colors = new Color[ttask.rays.Length];
                    for (int i = 0; i < colors.Length; i++)
                    {
                        colors[i] = scene.Raytrace(ttask.rays[i], Settings.Method, Settings.Bounces, 9999, PhotonMap);
                    }
                    Color c = Color.Average(colors);

                    int idx = ttask.py*PatchSize + ttask.px;
                    idx *= 3;
                    c.R = Math.Min(c.R, 1);
                    c.G = Math.Min(c.G, 1);
                    c.B = Math.Min(c.B, 1);
                    cache[idx] = (byte) (c.R*255);
                    cache[idx + 1] = (byte) (c.B*255);
                    cache[idx + 2] = (byte) (c.G*255);

                    PixelComplete();
                }
            }
        }

        #region Nested type: GITask

        private class GITask : Task
        {
            public Light light;
            public Ray ray;
        }

        #endregion

        #region Nested type: Stage

        private enum Stage
        {
            GI,
            Tracing
        }

        #endregion

        #region Nested type: Task

        private class Task
        {
            public Stage stage;
        }

        #endregion

        #region Nested type: TracingTask

        private class TracingTask : Task
        {
            public int px, py;
            public Ray[] rays;
        }

        #endregion
    }
}