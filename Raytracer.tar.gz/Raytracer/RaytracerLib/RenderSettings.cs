﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace RaytracerLib
{
    [DataContract]
    [Serializable]
    public class RenderSettings : INotifyPropertyChanged
    {
        private double _Ambient = 0.33;
        private bool _Antialiasing;
        private int _Bounces = 2;
        private int _Height = 256;
        private string _Method = "Simple";
        private double _PhotonBoost = 0.1;
        private double _PhotonDistance = 1;
        private int _Photons = 1000;
        private int _Threads = 8;

        private int _Width = 256;

        [DataMember]
        public string Method
        {
            get { return _Method; }
            set
            {
                _Method = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Method"));
            }
        }

        [DataMember]
        public int Width
        {
            get { return _Width; }
            set
            {
                _Width = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Width"));
            }
        }

        [DataMember]
        public int Height
        {
            get { return _Height; }
            set
            {
                _Height = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Height"));
            }
        }

        [DataMember]
        public bool Antialiasing
        {
            get { return _Antialiasing; }
            set
            {
                _Antialiasing = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Antialiasing"));
            }
        }

        [DataMember]
        public int Threads
        {
            get { return _Threads; }
            set
            {
                _Threads = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Threads"));
            }
        }

        [DataMember]
        public int Photons
        {
            get { return _Photons; }
            set
            {
                _Photons = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Photons"));
            }
        }

        [DataMember]
        public double PhotonBoost
        {
            get { return _PhotonBoost; }
            set
            {
                _PhotonBoost = value;
                PropertyChanged(this, new PropertyChangedEventArgs("PhotonBoost"));
            }
        }

        [DataMember]
        public double PhotonDistance
        {
            get { return _PhotonDistance; }
            set
            {
                _PhotonDistance = value;
                PropertyChanged(this, new PropertyChangedEventArgs("PhotonDistance"));
            }
        }

        [DataMember]
        public int Bounces
        {
            get { return _Bounces; }
            set
            {
                _Bounces = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Bounces"));
            }
        }


        [DataMember]
        public double Ambient
        {
            get { return _Ambient; }
            set
            {
                _Ambient = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Ambient"));
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        #endregion

        public void CopyTo(RenderSettings t)
        {
            t.Method = Method;
            t.Width = Width;
            t.Height = Height;
            t.Antialiasing = Antialiasing;
            t.Threads = Threads;
            t.Photons = Photons;
            t.PhotonBoost = PhotonBoost;
            t.PhotonDistance = PhotonDistance;
            t.Bounces = Bounces;
            t.Ambient = Ambient;
        }
    }
}