﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using RaytracerLib;
using SWM = System.Windows.Media;


namespace RaytracerApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AppState State = AppState.Empty;
        private Scene currentScene;
        private Camera currrentCamera;
        private Raytracer raytracer;
        private WriteableBitmap renderBitmap;
        private DateTime renderStartTime;
        private string sceneId;


        public MainWindow()
        {
            RenderSettings = new RenderSettings();
            InitializeComponent();
            UpdateWindow();
        }

        public RenderSettings RenderSettings { get; private set; }

        private void UpdateWindow()
        {
            PanelLoad.IsEnabled = State != AppState.Rendering;
            PanelSetup.IsEnabled = State == AppState.Loaded;
            PanelStatus.IsEnabled = State == AppState.Rendering;
            StatusLabel.Content = "";
            if (State != AppState.Rendering)
                RenderProgress.Value = 0;
        }

        private void tracer_Stopped()
        {
            State = AppState.Loaded;
            Dispatcher.Invoke(new Action(delegate
                                             {
                                                 UpdateWindow();
                                                 StatusLabel.Content = String.Format("Finished in {0}",
                                                                                     DateTime.Now - renderStartTime);
                                             }));
        }

        private void tracer_PixelsReady(Int32Rect patch, byte[] pixels)
        {
            Dispatcher.Invoke(new Action(() => renderBitmap.WritePixels(patch, pixels, raytracer.PatchSize*3, 0)));
        }

        private void tracer_Progress(string text, double progress)
        {
            Dispatcher.Invoke(new Action(delegate
                                             {
                                                 RenderProgress.Value = progress;
                                                 StatusLabel.Content = text;
                                             }));
            Console.WriteLine(text);
        }


        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog {Filter = "FBX|*.fbx"};
            if (!ofd.ShowDialog().Value) return;
            currentScene = new Scene();
            var fbx = new FBXParser(File.ReadAllText(ofd.FileName, Encoding.GetEncoding(1251)).Split('\n'));
            foreach (Mesh m in fbx.geometry.Values)
                currentScene.Meshes.Add(m);
            foreach (Light l in fbx.lights.Values)
                currentScene.Lights.Add(l);
            currrentCamera = fbx.camera;
            State = AppState.Loaded;
            UpdateWindow();
            sceneId = new FileInfo(ofd.FileName).Name.Split('.')[0];
            LoadRenderSettings(sceneId);
        }

        private void RenderButton_Click(object sender, RoutedEventArgs e)
        {
            raytracer = new Raytracer();
            double dpi = PresentationSource.FromVisual(this).CompositionTarget.TransformToDevice.M11*96.0;
            renderBitmap = new WriteableBitmap(RenderSettings.Width, RenderSettings.Height, dpi, dpi, PixelFormats.Rgb24,
                                               null);
            raytracer.Initialize(RenderSettings);
            raytracer.SetPatchSize(32);
            raytracer.PixelsReady += tracer_PixelsReady;

            Canvas.Source = renderBitmap;
            Canvas.SnapsToDevicePixels = true;
            Canvas.Stretch = Stretch.None;

            renderStartTime = DateTime.Now;
            raytracer.StartRender(currentScene, currrentCamera);
            raytracer.Stopped += tracer_Stopped;
            raytracer.Progress += tracer_Progress;

            State = AppState.Rendering;
            UpdateWindow();
            SaveRenderSettings(sceneId);
        }

        private void RenderStop_Click(object sender, RoutedEventArgs e)
        {
            raytracer.Stop();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void LoadRenderSettings(string id)
        {
            try
            {
                Directory.CreateDirectory("Render Settings");
            }
            catch
            {
            }
            var tmp = new RenderSettings();
            try
            {
                tmp = (RenderSettings) XamlReader.Parse(File.ReadAllText("Render Settings\\" + id + ".xml"));
            }
            catch (FileNotFoundException)
            {
            }
            tmp.CopyTo(RenderSettings);
        }

        private void SaveRenderSettings(string id)
        {
            try
            {
                Directory.CreateDirectory("Render Settings");
            }
            catch
            {
            }
            File.WriteAllText("Render Settings\\" + id + ".xml", XamlWriter.Save(RenderSettings));
        }

        #region Nested type: AppState

        private enum AppState
        {
            Empty,
            Loaded,
            Rendering
        }

        #endregion
    }
}