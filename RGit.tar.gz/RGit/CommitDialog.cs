using System;
using Gtk;

namespace RGit
{
	public partial class CommitDialog : Gtk.Dialog
	{
		public CommitDialogController Controller;

		public CommitDialog ()
		{
			this.Build ();
			Default = commitMessage;
		}

		protected virtual void OnResponse (object o, Gtk.ResponseArgs args)
		{
			if (args.ResponseId == Gtk.ResponseType.Ok) {
				if (commitMessage.Buffer.Text.Length == 0) {
					new MessageBox (this, "Commit message is required", MessageType.Warning, ButtonsType.Ok).Run ();
					return;
				}
				Controller.Commit (commitMessage.Buffer.Text, chkSignOff.Active, chkAmend.Active);
			}
			HideAll ();
		}
	}

	public class CommitDialogController
	{
		public Git Repository = null;
		public CommitDialog Window = null;
		public MainWindowController Base;

		public CommitDialogController (CommitDialog wnd, Git rep, MainWindowController bs)
		{
			Window = wnd;
			Window.Controller = this;
			Repository = rep;
			Base = bs;
		}

		public void Commit (string msg, bool signoff, bool amend)
		{
			Repository.Commit (msg, signoff, amend);
			Base.Refresh ();
		}
	}
	
}
