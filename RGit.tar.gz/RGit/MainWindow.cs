using System;
using Gtk;
using RGit;
using Gdk;

public partial class MainWindow : Gtk.Window
{
	public TreeView SourceTree, LogTree;
	public Pixbuf IconNew, IconModified, IconDeleted, IconUntracked, IconUnmerged;
	public MainWindowController Controller;
	public TextView CodeView;
	public string SelectedFile = "";
	public Menu FileContextMenu;
	public MenuItem StageMenuItem, UnstageMenuItem;

	public MainWindow () : base(Gtk.WindowType.Toplevel)
	{
		Build ();
		sourceTree.AppendColumn ("", new CellRendererPixbuf (), "pixbuf", 0);
		sourceTree.AppendColumn ("File", new CellRendererText (), "text", 1);
		sourceTree.Model = new TreeStore (typeof(Pixbuf), typeof(string));
		SourceTree = sourceTree;
		
		logTree.Model = new ListStore (typeof(string), typeof(string));
		logTree.AppendColumn ("Summary", new CellRendererText (), "text", 0);
		logTree.AppendColumn ("ID", new CellRendererText (), "text", 1);
		LogTree = logTree;
		
		IconNew = this.RenderIcon ("gtk-add", IconSize.Menu, "menu");
		IconModified = this.RenderIcon ("gtk-edit", IconSize.Menu, "menu");
		IconDeleted = this.RenderIcon ("gtk-delete", IconSize.Menu, "menu");
		IconUntracked = this.RenderIcon ("gtk-no", IconSize.Menu, "menu");
		IconUnmerged = this.RenderIcon ("gtk-dialog-warning", IconSize.Menu, "menu");
		
		CodeView = codeView;
		Pango.FontDescription fd = new Pango.FontDescription ();
		fd.Family = "monospace";
		codeView.ModifyFont (fd);
		TextTag DiffHead = new TextTag ("diffhead");
		TextTag DiffAddText = new TextTag ("diffplus");
		TextTag DiffDelText = new TextTag ("diffminus");
		DiffHead.Weight = Pango.Weight.Heavy;
		DiffAddText.Background = "#CCFFCC";
		DiffDelText.Background = "#FFCCCC";
		codeView.Buffer.TagTable.Add (DiffHead);
		codeView.Buffer.TagTable.Add (DiffAddText);
		codeView.Buffer.TagTable.Add (DiffDelText);
		
		TextTag LogHead = new TextTag ("head");
		LogHead.Weight = Pango.Weight.Heavy;
		outputView.Buffer.TagTable.Add (LogHead);
		
		FileContextMenu = new Menu ();
		
		StageMenuItem = MakeMenuItem ("Stage", "gtk-redo", new EventHandler (OnStage));
		FileContextMenu.Add (StageMenuItem);
		UnstageMenuItem = MakeMenuItem ("Unstage", "gtk-undo", new EventHandler (OnUnstage));
		FileContextMenu.Add (UnstageMenuItem);
		FileContextMenu.Add (MakeMenuItem ("Edit", "gtk-edit", new EventHandler (OnEdit)));
		FileContextMenu.Add (MakeMenuItem ("Revert to staged", "gtk-refresh", new EventHandler (OnRevertStaged)));
		FileContextMenu.Add (MakeMenuItem ("Revert to commited", "gtk-refresh", new EventHandler (OnRevertCommited)));
		
		stageAllAction.Activated += new EventHandler (OnStageAll);
		unstageAllAction.Activated += new EventHandler (OnUnstageAll);
	}

	MenuItem MakeMenuItem (string n, string i, EventHandler h)
	{
		ImageMenuItem mi = new ImageMenuItem (n, new AccelGroup ());
		Gtk.Image img = new Gtk.Image ();
		img.SetFromStock (i, IconSize.Menu);
		mi.Image = img;
		mi.Activated += h;
		return mi;
	}

	public void OnProgress (bool a)
	{
		pbrStatus.Sensitive = a;
		if (a)
			pbrStatus.Pulse ();
		else
			pbrStatus.Fraction = 0;
	}

	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}

	protected virtual void OnQuit (object sender, System.EventArgs e)
	{
		Application.Quit ();
	}

	protected virtual void OnRefresh (object sender, System.EventArgs e)
	{
		Controller.Refresh ();
	}

	protected virtual void OnStage (object sender, System.EventArgs e)
	{
		Controller.Stage (SelectedFile);
	}

	protected virtual void OnUnstage (object sender, System.EventArgs e)
	{
		Controller.Unstage (SelectedFile);
	}

	protected virtual void OnEdit (object sender, System.EventArgs e)
	{
		Controller.Edit (SelectedFile);
	}

	protected virtual void OnRevertStaged (object sender, System.EventArgs e)
	{
		Controller.RevertStaged (SelectedFile);
	}

	protected virtual void OnRevertCommited (object sender, System.EventArgs e)
	{
		Controller.RevertCommited (SelectedFile);
	}

	protected virtual void OnStageAll (object sender, System.EventArgs e)
	{
		Controller.StageAll ();
	}

	protected virtual void OnUnstageAll (object sender, System.EventArgs e)
	{
		Controller.UnstageAll ();
	}

	public void OnLog (string h, string b)
	{
		TextIter ti = outputView.Buffer.EndIter;
		outputView.Buffer.InsertWithTagsByName (ref ti, h + "\n", "head");
		outputView.Buffer.Insert (ref ti, b + "\n");
		outputView.ScrollMarkOnscreen (outputView.Buffer.CreateMark ("end", outputView.Buffer.EndIter, false));
		outputView.Buffer.DeleteMark (outputView.Buffer.GetMark ("end"));
	}

	[GLib.ConnectBeforeAttribute]
	protected virtual void OnSourceTreeButtonReleaseEvent (object o, Gtk.ButtonReleaseEventArgs args)
	{
		TreeStore t = (TreeStore)SourceTree.Model;
		TreePath p;
		TreeViewColumn c;
		TreeIter ti;
		
		sourceTree.GetCursor (out p, out c);
		if (p == null || p.Depth == 1) {
			codeView.Buffer.Clear ();
			return;
		}
		
		t.GetIter (out ti, p);
		SelectedFile = (string)t.GetValue (ti, 1);
		
		StageMenuItem.Sensitive = !Controller.Status[SelectedFile].Staged;
		UnstageMenuItem.Sensitive = Controller.Status[SelectedFile].Staged;
		
		
		Controller.Diff (SelectedFile);
		
		if (args.Event.Button == 3) {
			FileContextMenu.ShowAll ();
			FileContextMenu.Popup ();
		}
	}

	public void AppendDiff (string f, string d)
	{
		string[] ss = d.Split ('\n');
		
		TextIter ti = codeView.Buffer.EndIter;
		if (f != "")
			codeView.Buffer.InsertWithTagsByName (ref ti, f + "\n\n", "diffhead");
		
		try {
			for (int i = 0; i <= ss.Length; i++) {
				string s = ss[i];
				if (s.StartsWith ("+"))
					codeView.Buffer.InsertWithTagsByName (ref ti, ' ' + s + '\n', "diffplus"); else if (s.StartsWith ("-") && s != "---")
					codeView.Buffer.InsertWithTagsByName (ref ti, ' ' + s + '\n', "diffminus");
				else
					codeView.Buffer.Insert (ref ti, s + '\n');
			}
		} catch {
		}
	}

	protected virtual void OnCommitActionActivated (object sender, System.EventArgs e)
	{
		Controller.Commit ();
	}

	protected virtual void OnCheckoutActionActivated (object sender, System.EventArgs e)
	{
		Controller.Checkout ();
	}

	protected virtual void OnOpenActionActivated (object sender, System.EventArgs e)
	{
		Controller.Open ();
	}

	protected virtual void OnNewActionActivated (object sender, System.EventArgs e)
	{
		Controller.CreateBranch ();
	}

	protected virtual void OnMergeActionActivated (object sender, System.EventArgs e)
	{
		Controller.Merge ();
	}

	[GLib.ConnectBeforeAttribute]
	protected virtual void OnLogTreeButtonReleaseEvent (object o, Gtk.ButtonReleaseEventArgs args)
	{
		ListStore t = (ListStore)LogTree.Model;
		TreePath p;
		TreeViewColumn c;
		TreeIter ti;
		
		LogTree.GetCursor (out p, out c);
		if (p == null || p.Depth == 0) {
			codeView.Buffer.Clear ();
			return;
		}
		
		t.GetIter (out ti, p);
		string cid = (string)t.GetValue (ti, 1);
		
		Controller.CommitDiff (cid);
	}

	protected virtual void OnPushActionActivated (object sender, System.EventArgs e)
	{
		Controller.Push ();
	}

	protected virtual void OnPullActionActivated (object sender, System.EventArgs e)
	{
		Controller.Pull ();
	}

	protected virtual void OnFetchActionActivated (object sender, System.EventArgs e)
	{
		Controller.Fetch ();
	}
}


public class MainWindowController
{
	public Git Repository = null;
	public MainWindow Window = null;
	public Git.StatusList Status;

	public MainWindowController (MainWindow wnd, Git rep)
	{
		Window = wnd;
		Window.Controller = this;
		Repository = rep;
		Repository.Log += new Git.LogHandler (Window.OnLog);
		Repository.Progress += new Git.ProgressHandler (Window.OnProgress);
		Refresh ();
	}

	public void Refresh ()
	{
		RefreshTree ();
		RefreshTitle ();
		RefreshLog ();
	}

	public void RefreshTree ()
	{
		TreeStore model = (TreeStore)Window.SourceTree.Model;
		model.Clear ();
		TreeIter staged = model.AppendValues (null, "Staged");
		TreeIter unstaged = model.AppendValues (null, "Unstaged");
		
		Status = Repository.GetStatus ();
		foreach (string f in Status.Keys) {
			Pixbuf icon = null;
			if (Status[f].Status == Git.Status.Untracked)
				icon = Window.IconUntracked;
			if (Status[f].Status == Git.Status.Deleted)
				icon = Window.IconDeleted;
			if (Status[f].Status == Git.Status.Modified)
				icon = Window.IconModified;
			if (Status[f].Status == Git.Status.Unmerged)
				icon = Window.IconUnmerged;
			if (Status[f].Status == Git.Status.New)
				icon = Window.IconNew;
			if (Status[f].Staged)
				model.AppendValues (staged, icon, f);
			else
				model.AppendValues (unstaged, icon, f);
		}
		
		Window.SourceTree.ExpandAll ();
	}

	public void RefreshLog ()
	{
		ListStore model = (ListStore)Window.LogTree.Model;
		model.Clear ();
		Git.CommitLog log = Repository.GetCommitLog ();
		foreach (string s in log.Keys) {
			Console.WriteLine (s + log[s]);
			model.AppendValues (log[s], s);
		}
	}


	public void RefreshTitle ()
	{
		Window.Title = "RGit - " + Repository.Path + " at " + Repository.GetCurrentBranch ();
	}

	public void Diff (string f)
	{
		Window.CodeView.Buffer.Clear ();
		Window.AppendDiff (f, Repository.Diff (f));
	}

	public void Edit (string f)
	{
		try {
			System.Diagnostics.Process.Start ("xdg-open", System.IO.Path.Combine (Repository.Path, f));
		} catch {
		}
	}

	public void Stage (string f)
	{
		Repository.Stage (f);
		RefreshTree ();
	}

	public void RevertStaged (string f)
	{
		Repository.RevertStaged (f);
		RefreshTree ();
	}

	public void RevertCommited (string f)
	{
		Repository.RevertCommited (f);
		RefreshTree ();
	}


	public void Unstage (string f)
	{
		Repository.Unstage (f);
		RefreshTree ();
	}

	public void StageAll ()
	{
		Repository.StageAll ();
		RefreshTree ();
	}

	public void UnstageAll ()
	{
		Repository.UnstageAll ();
		RefreshTree ();
	}

	public void Commit ()
	{
		CommitDialog dlg = new CommitDialog ();
		new CommitDialogController (dlg, Repository, this);
		dlg.ShowAll ();
	}

	public void Checkout ()
	{
		BranchSelectionDialog d = new BranchSelectionDialog (Repository);
		if (d.Run () == (int)ResponseType.Ok) {
			Repository.Checkout (d.Branch);
			Refresh ();
		}
	}

	public void CreateBranch ()
	{
		BranchCreationDialog d = new BranchCreationDialog ();
		if (d.Run () == (int)ResponseType.Ok) {
			Repository.CreateBranch (d.Branch);
			Refresh ();
		}
	}

	public void Open ()
	{
		Window.HideAll ();
		new OpenRepoWindow ().Show ();
	}

	public void CommitDiff (string cid)
	{
		Window.CodeView.Buffer.Clear ();
		string[] ss = Repository.GetCommitDiff (cid).Split ('\n');
		int i = 1;
		string d = "";
		while (i < ss.Length && ss[i] != "---")
			d += ss[i++] + '\n';
		while (i < ss.Length && ss[i] != "")
			d += ss[i++] + '\n';
		Window.AppendDiff (ss[0], d);
		i++;
		
		while (i < ss.Length) {
			string n = ss[i].Substring (ss[i++].IndexOf ("a/") + 2);
			n = n.Substring (0, n.IndexOf (" b/"));
			string dd = "";
			while (i < ss.Length && !ss[i].StartsWith ("diff"))
				dd += ss[i++] + '\n';
			Window.AppendDiff (n, dd);
		}
	}


	public void Merge ()
	{
		BranchSelectionDialog d = new BranchSelectionDialog (Repository);
		if (d.Run () == (int)ResponseType.Ok) {
			Repository.Merge (d.Branch);
			Refresh ();
		}
	}

	public void Push ()
	{
		RemoteSelectionDialog d = new RemoteSelectionDialog (Repository);
		if (d.Run () == (int)ResponseType.Ok) {
			Repository.Push (d.Remote);
		}
	}

	public void Pull ()
	{
		RemoteSelectionDialog d = new RemoteSelectionDialog (Repository);
		if (d.Run () == (int)ResponseType.Ok) {
			Repository.Pull (d.Remote);
		}
	}

	public void Fetch ()
	{
		RemoteSelectionDialog d = new RemoteSelectionDialog (Repository);
		if (d.Run () == (int)ResponseType.Ok) {
			Repository.Fetch (d.Remote);
		}
	}
}
