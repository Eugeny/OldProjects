using System;
namespace RGit
{
	public partial class BranchCreationDialog : Gtk.Dialog
	{
		public string Branch;

		public BranchCreationDialog ()
		{
			this.Build ();
		}

		protected virtual void OnResponse (object o, Gtk.ResponseArgs args)
		{
			Branch = txtName.Text;
		}
	}
}

