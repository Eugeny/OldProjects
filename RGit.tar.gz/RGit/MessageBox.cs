using System;
using Gtk;

namespace RGit
{
	public class MessageBox : MessageDialog
	{
		public MessageBox (Window owner, string msg, MessageType t, ButtonsType b) : base(owner, DialogFlags.Modal, t, b, false, msg)
		{
			Response += HandleResponse;
		}

		void HandleResponse (object o, ResponseArgs args)
		{
			HideAll ();
		}
	}
}

