using System;
using Gtk;
namespace RGit
{
	public partial class RemoteSelectionDialog : Gtk.Dialog
	{
		public string Remote = "";

		public RemoteSelectionDialog (Git repo)
		{
			this.Build ();
			ListStore s = new ListStore (typeof(string));
			foreach (string b in repo.GetRemotes ())
				s.AppendValues (b);
			cbxRemote.Model = s;
		}

		protected virtual void OnResponse (object o, Gtk.ResponseArgs args)
		{
			TreeIter ti;
			cbxRemote.GetActiveIter (out ti);
			Remote = (string)(((ListStore)cbxRemote.Model).GetValue (ti, 0));
			HideAll ();
		}
	}
}

