using System;
using Gtk;

namespace RGit
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Application.Init ();
			Config.Load ();
			new OpenRepoWindow ().Show();
			Application.Run ();
		}
	}
}

