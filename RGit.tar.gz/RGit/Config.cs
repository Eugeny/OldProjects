using System;
using System.IO;
using System.Collections.Generic;

namespace RGit
{
	public static class Config
	{
		public static List<string> Recent = new List<string>();
		public static string ConfigFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), ".rgit");
		
		public static void Load ()
		{
			try {
				string[] cfg = File.ReadAllText (ConfigFile).Split ('\n');
				foreach (string s in cfg) {
					string k = s.Split ('=')[0].Trim ();
					string v = s.Split ('=')[1].Trim ();
					if (k=="recent")
						Recent.Add(v);
				}
			} catch {
			}
		}
		
		public static void Save ()
		{
			string cfg = "";
			foreach (string s in Recent)
				cfg += "recent = " + s + "\n";
			File.WriteAllText (ConfigFile, cfg);
		}
	}
}

