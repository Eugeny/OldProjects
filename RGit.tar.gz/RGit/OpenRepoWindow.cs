using System;
using Gtk;
using System.IO;

namespace RGit
{
	public partial class OpenRepoWindow : Gtk.Window
	{
		public OpenRepoWindow () : base(Gtk.WindowType.Toplevel)
		{
			this.Build ();
			ListStore s = new ListStore (typeof(string));
			cbxRecent.Model = s;
			cbxRecent.SetActiveIter (s.AppendValues ("Recent"));
			
			foreach (string r in Config.Recent)
				s.AppendValues (r);
		}

		protected virtual void OnCbxRecentChanged (object sender, System.EventArgs e)
		{
			TreeIter ti;
			cbxRecent.GetActiveIter (out ti);
			string s = (string)((ListStore)cbxRecent.Model).GetValue (ti, 0);
			Open (s);
		}


		void HandleDResponse (object o, ResponseArgs args)
		{
			((FileChooserDialog)o).HideAll ();
			if (args.ResponseId == ResponseType.Ok) {
				string s = ((FileChooserDialog)o).CurrentFolder;
				Open (s);
			}
		}

		void HandleDResponseCreate (object o, ResponseArgs args)
		{
			((FileChooserDialog)o).HideAll ();
			if (args.ResponseId == ResponseType.Ok) {
				string s = ((FileChooserDialog)o).CurrentFolder;
				if (!Directory.Exists (System.IO.Path.Combine (s, ".git")))
					Git.CreateRepo (s);
				Open (s);
			}
		}

		void Open (string s)
		{
			if (Git.TestRepo (s)) {
				HideAll ();
				if (!Config.Recent.Contains (s)) {
					Config.Recent.Add (s);
					if (Config.Recent.Count > 10)
						Config.Recent.RemoveAt (0);
					Config.Save ();
				}
				MainWindow w = new MainWindow ();
				new MainWindowController (w, new Git (s));
				w.ShowAll ();
			}
		}

		protected virtual void OnDeleteEvent (object o, Gtk.DeleteEventArgs args)
		{
			Application.Quit ();
		}

		protected virtual void OnBtnOpenClicked (object sender, System.EventArgs e)
		{
			FileChooserDialog d = new FileChooserDialog ("Select repository", this, FileChooserAction.SelectFolder, "Ok");
			d.AddButton ("Cancel", ResponseType.Cancel);
			d.AddButton ("Ok", ResponseType.Ok);
			d.Response += HandleDResponse;
			d.ShowAll ();
		}

		protected virtual void OnBtnQuitClicked (object sender, System.EventArgs e)
		{
			Application.Quit ();
		}

		protected virtual void OnBtnCreateClicked (object sender, System.EventArgs e)
		{
			FileChooserDialog d = new FileChooserDialog ("Select folder", this, FileChooserAction.SelectFolder, "Ok");
			d.AddButton ("Cancel", ResponseType.Cancel);
			d.AddButton ("Ok", ResponseType.Ok);
			d.Response += HandleDResponseCreate;
			d.ShowAll ();
		}
		
		
	}
}

