using System;
using System.Collections.Generic;
using System.Diagnostics;
using Gtk;
using System.IO;
using System.Threading;

namespace RGit
{
	public class Git
	{
		public LogHandler Log;
		public ProgressHandler Progress;
		public string Path = "";

		public Git (string path)
		{
			Path = path;
		}

		public StatusList GetStatus ()
		{
			StatusList r = new StatusList ();
			foreach (string s in Run ("status --porcelain", false).Split ('\n')) {
				try {
					FileStatus fs;
					fs.Staged = s[0] != '?' && s[0] != ' ' && s[0] != 'U' && s[1] == ' ';
					fs.Status = Git.Status.None;
					if (s.Substring (0, 2).Contains ("M"))
						fs.Status = Git.Status.Modified;
					if (s.Substring (0, 2).Contains ("D"))
						fs.Status = Git.Status.Deleted;
					if (s.Substring (0, 2).Contains ("A"))
						fs.Status = Git.Status.New;
					if (s.Substring (0, 2).Contains ("U"))
						fs.Status = Git.Status.Unmerged;
					if (s.Substring (0, 2).Contains ("?"))
						fs.Status = Git.Status.Untracked;
					r[s.Substring (3)] = fs;
				} catch {
				}
			}
			return r;
		}

		public string Diff (string f)
		{
			return Run ("diff HEAD " + f, false);
		}

		public void Stage (string f)
		{
			Run ("add " + f, true);
		}

		public void Unstage (string f)
		{
			Run ("reset HEAD " + f, true);
		}

		public void StageAll ()
		{
			Run ("add -A", true);
		}

		public void UnstageAll ()
		{
			Run ("reset HEAD", true);
		}

		public void Commit (string msg, bool signoff, bool amend)
		{
			File.WriteAllText ("/tmp/rgit-commit", msg);
			string cmd = "commit -F /tmp/rgit-commit";
			if (signoff)
				cmd += " -s";
			if (amend)
				cmd += " --amend";
			Run (cmd, true);
			File.Delete ("/tmp/rgit-commit");
		}

		public List<string> GetBranches ()
		{
			string[] s = Run ("branch -a", false).Split ('\n');
			List<string> r = new List<string> ();
			foreach (string x in s)
				r.Add (x.Trim (' ', '*'));
			return r;
		}

		public string GetCurrentBranch ()
		{
			string[] s = Run ("branch -a", false).Split ('\n');
			try {
				foreach (string x in s)
					if (x[0] == '*')
						return x.Trim (' ', '*');
			} catch {
			}
			return "master";
		}

		public string[] GetRemotes ()
		{
			return Run ("remote", false).Split ('\n');
		}

		public void Checkout (string branch)
		{
			Run ("checkout " + branch, true);
		}

		public void CreateBranch (string branch)
		{
			Run ("checkout -b " + branch, true);
		}

		public void Merge (string branch)
		{
			Run ("merge " + branch, true);
		}

		public void RevertStaged (string file)
		{
			Run ("checkout -- " + file, true);
		}

		public void RevertCommited (string file)
		{
			Run ("checkout HEAD -- " + file, true);
		}

		public CommitLog GetCommitLog ()
		{
			string[] ss = Run ("log", false).Split ('\n');
			CommitLog l = new CommitLog ();
			int i = 0;
			while (i < ss.Length) {
				string c = "";
				while (i < ss.Length && (ss[i] == "" || ss[i][0] != ' ')) {
					if (ss[i].StartsWith ("commit"))
						c = ss[i].Substring (ss[i].IndexOf (' '));
					i++;
				}
				if (i < ss.Length) {
					l[c] = ss[i];
				}
				while (i < ss.Length && !(ss[i] == "" || ss[i][0] != ' '))
					i++;
			}
			return l;
		}

		public string GetCommitDiff (string cid)
		{
			return Run ("log -1 -p --stat " + cid, false);
		}

		public void Push (string remote)
		{
			Run ("push " + remote, true);
		}

		public void Pull (string remote)
		{
			Run ("pull " + remote, true);
		}

		public void Fetch (string remote)
		{
			Run ("fetch " + remote, true);
		}

		public static bool TestRepo (string path)
		{
			Process p = new Process ();
			p.StartInfo.WorkingDirectory = path;
			p.StartInfo.FileName = "git";
			p.StartInfo.Arguments = "status";
			p.Start ();
			p.WaitForExit ();
			return p.ExitCode == 0;
		}

		public static Git CreateRepo (string path)
		{
			Git g = new Git (path);
			g.Run ("init", false);
			return g;
		}

		/* Types */

		public delegate void LogHandler (string h, string b);
		public delegate void ProgressHandler (bool active);

		public class StatusList : Dictionary<string, FileStatus>
		{
		}

		public class CommitLog : Dictionary<string, string>
		{
		}

		public struct FileStatus
		{
			public bool Staged;
			public Status Status;
		}

		public enum Status
		{
			Modified,
			Deleted,
			New,
			Untracked,
			Unmerged,
			None
		}

		/* Inner */

		public string Run (string args, bool log)
		{
			Process p = new Process ();
			p.StartInfo.WorkingDirectory = Path;
			p.StartInfo.FileName = "git";
			p.StartInfo.Arguments = args;
			p.StartInfo.UseShellExecute = false;
			p.StartInfo.RedirectStandardOutput = true;
			p.StartInfo.RedirectStandardError = true;
			p.Start ();
			while (!p.HasExited) {
				if (Progress != null)
					Progress.Invoke (true);
				Application.RunIteration ();
				Thread.Sleep (50);
			}
			if (Progress != null)
				Progress.Invoke (false);
			
			string r = p.StandardOutput.ReadToEnd ();
			r += '\n' + p.StandardError.ReadToEnd ();
			if (Log != null && log)
				Log.Invoke ("git " + args, r);
			return r;
		}
	}
}

