using System;
using Gtk;

namespace RGit
{
	public partial class BranchSelectionDialog : Gtk.Dialog
	{
		public string Branch = "";

		public BranchSelectionDialog (Git repo)
		{
			this.Build ();
			ListStore s = new ListStore (typeof(string));
			foreach (string b in repo.GetBranches ())
				s.AppendValues (b);
			cbxBranch.Model = s;
		}

		protected virtual void OnResponse (object o, Gtk.ResponseArgs args)
		{
			TreeIter ti;
			cbxBranch.GetActiveIter (out ti);
			Branch = (string)(((ListStore)cbxBranch.Model).GetValue (ti, 0));
			HideAll ();
		}
	}
}

